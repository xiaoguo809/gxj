#!/bin/bash

source /etc/profile
CurrentPath=`pwd`
echo "Current path=${CurrentPath}"
mkdir -p ${CurrentPath}/../applogs/cloud/
nohup java -Xms800m -Xmx800m -XX:PermSize=256m -XX:MaxPermSize=512m -XX:MaxNewSize=512m \
           -DCONFIG_SERVER_HOST=127.0.0.1 -DEUREKA_SERVER_HOST=127.0.0.1 -DGATEWAY_SERVER_HOST=127.0.0.1 \
           -DMYSQL_HOST=10.8.202.131 -DMYSQL_PORT=31306 -DREDIS_HOST=redis-g.ift.bzl.com.cn -DREDIS_PORT=30686 -DREDIS_PASSWD=redis2019@  \
           -jar ${CurrentPath}/../jar/node-service.jar > ${CurrentPath}/../applogs/cloud/node-service.log &
echo "Node service start finished."
