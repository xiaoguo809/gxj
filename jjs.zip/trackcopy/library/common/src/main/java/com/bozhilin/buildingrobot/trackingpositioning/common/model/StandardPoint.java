package com.bozhilin.buildingrobot.trackingpositioning.common.model;/**
 * @author :  pengjunming
 * @date :   11:06
 */


import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;

import org.springframework.util.StringUtils;

import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author: pengjunming
 * @Date:2019/8/31 11:06
 * @Description: 基准点
 */
@Data
public class StandardPoint extends BaseModel {

    @ApiModelProperty(value = "经度", required = true)
    private BigDecimal longitude;

    @ApiModelProperty(value = "纬度", required = true)
    private BigDecimal latitude;

    @ApiModelProperty(value = "区域码", required = true)
    private String areaCode;

    @ApiModelProperty(value = "区域描述", required = false)
    private String areaDesc;

    public StandardPoint(){
    }

    public StandardPoint(BigDecimal longitude, BigDecimal latitude, String areaCode, String areaDesc) {
        this.longitude = longitude;
        this.latitude = latitude;
        this.areaCode = areaCode;
        this.areaDesc = areaDesc;
    }

    public StandardPoint(BigDecimal longitude, BigDecimal latitude, String areaCode) {
        this(longitude, latitude, areaCode, null);
    }

    @JsonIgnore
    public boolean isValid(){
        return this.getLatitude() != null &&
                this.getLongitude() != null &&
                !StringUtils.isEmpty(this.getAreaCode());
    }
}
