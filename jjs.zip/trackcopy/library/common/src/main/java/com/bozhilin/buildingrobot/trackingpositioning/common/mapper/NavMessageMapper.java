package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NavMessage;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NavMessageExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NavMessageMapper {
    int deleteByExample(NavMessageExample example);

    int deleteByPrimaryKey(String id);

    int insert(NavMessage record);

    int insertSelective(NavMessage record);

    List<NavMessage> selectByExample(NavMessageExample example);

    NavMessage selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") NavMessage record, @Param("example") NavMessageExample example);

    int updateByExample(@Param("record") NavMessage record, @Param("example") NavMessageExample example);

    int updateByPrimaryKeySelective(NavMessage record);

    int updateByPrimaryKey(NavMessage record);
}