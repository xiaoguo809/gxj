package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSum;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TrackSumMapper {
    int deleteByExample(TrackSumExample example);

    int deleteByPrimaryKey(Long id);

    int insert(TrackSum record);

    int insertSelective(TrackSum record);

    List<TrackSum> selectByExample(TrackSumExample example);

    TrackSum selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") TrackSum record, @Param("example") TrackSumExample example);

    int updateByExample(@Param("record") TrackSum record, @Param("example") TrackSumExample example);

    int updateByPrimaryKeySelective(TrackSum record);

    int updateByPrimaryKey(TrackSum record);
}