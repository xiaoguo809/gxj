package com.bozhilin.buildingrobot.trackingpositioning.common.model;

/**
 * 封装API的错误码
 * Created by chenang on 2019/7/28
 */
public interface IErrorCode {
    int getCode();

    String getMessage();
}
