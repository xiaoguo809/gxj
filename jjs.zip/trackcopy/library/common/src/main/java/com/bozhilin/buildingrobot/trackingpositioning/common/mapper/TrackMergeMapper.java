package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackMerge;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackMergeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TrackMergeMapper {
    int deleteByExample(TrackMergeExample example);

    int deleteByPrimaryKey(Long id);

    int insert(TrackMerge record);

    int insertSelective(TrackMerge record);

    List<TrackMerge> selectByExampleWithBLOBs(TrackMergeExample example);

    List<TrackMerge> selectByExample(TrackMergeExample example);

    TrackMerge selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") TrackMerge record, @Param("example") TrackMergeExample example);

    int updateByExampleWithBLOBs(@Param("record") TrackMerge record, @Param("example") TrackMergeExample example);

    int updateByExample(@Param("record") TrackMerge record, @Param("example") TrackMergeExample example);

    int updateByPrimaryKeySelective(TrackMerge record);

    int updateByPrimaryKeyWithBLOBs(TrackMerge record);

    int updateByPrimaryKey(TrackMerge record);
}