package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatistics;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatisticsExample;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatisticsKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeStatisticsMapper {
    int deleteByExample(NodeStatisticsExample example);

    int deleteByPrimaryKey(NodeStatisticsKey key);

    int insert(NodeStatistics record);

    int insertSelective(NodeStatistics record);

    List<NodeStatistics> selectByExample(NodeStatisticsExample example);

    NodeStatistics selectByPrimaryKey(NodeStatisticsKey key);

    int updateByExampleSelective(@Param("record") NodeStatistics record, @Param("example") NodeStatisticsExample example);

    int updateByExample(@Param("record") NodeStatistics record, @Param("example") NodeStatisticsExample example);

    int updateByPrimaryKeySelective(NodeStatistics record);

    int updateByPrimaryKey(NodeStatistics record);
}