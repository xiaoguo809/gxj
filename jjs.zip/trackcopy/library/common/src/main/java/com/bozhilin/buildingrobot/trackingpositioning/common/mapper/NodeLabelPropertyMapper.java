package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeLabelProperty;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeLabelPropertyExample;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeLabelPropertyKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeLabelPropertyMapper {
    int deleteByExample(NodeLabelPropertyExample example);

    int deleteByPrimaryKey(NodeLabelPropertyKey key);

    int insert(NodeLabelProperty record);

    int insertSelective(NodeLabelProperty record);

    List<NodeLabelProperty> selectByExample(NodeLabelPropertyExample example);

    NodeLabelProperty selectByPrimaryKey(NodeLabelPropertyKey key);

    int updateByExampleSelective(@Param("record") NodeLabelProperty record, @Param("example") NodeLabelPropertyExample example);

    int updateByExample(@Param("record") NodeLabelProperty record, @Param("example") NodeLabelPropertyExample example);

    int updateByPrimaryKeySelective(NodeLabelProperty record);

    int updateByPrimaryKey(NodeLabelProperty record);
}