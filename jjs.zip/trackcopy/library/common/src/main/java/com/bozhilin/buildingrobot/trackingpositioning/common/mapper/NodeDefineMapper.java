package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefine;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefineExample;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefineKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeDefineMapper {
    int deleteByExample(NodeDefineExample example);

    int deleteByPrimaryKey(NodeDefineKey key);

    int insert(NodeDefine record);

    int insertSelective(NodeDefine record);

    List<NodeDefine> selectByExample(NodeDefineExample example);

    NodeDefine selectByPrimaryKey(NodeDefineKey key);

    int updateByExampleSelective(@Param("record") NodeDefine record, @Param("example") NodeDefineExample example);

    int updateByExample(@Param("record") NodeDefine record, @Param("example") NodeDefineExample example);

    int updateByPrimaryKeySelective(NodeDefine record);

    int updateByPrimaryKey(NodeDefine record);
}