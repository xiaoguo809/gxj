package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconData;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconDataExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface IconDataMapper {
    int deleteByExample(IconDataExample example);

    int deleteByPrimaryKey(Long id);

    int insert(IconData record);

    int insertSelective(IconData record);

    List<IconData> selectByExample(IconDataExample example);

    IconData selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") IconData record, @Param("example") IconDataExample example);

    int updateByExample(@Param("record") IconData record, @Param("example") IconDataExample example);

    int updateByPrimaryKeySelective(IconData record);

    int updateByPrimaryKey(IconData record);
}