package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessage;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessageExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeMessageMapper {
    int deleteByExample(NodeMessageExample example);

    int deleteByPrimaryKey(Long id);

    int insert(NodeMessage record);

    int insertSelective(NodeMessage record);

    List<NodeMessage> selectByExample(NodeMessageExample example);

    NodeMessage selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") NodeMessage record, @Param("example") NodeMessageExample example);

    int updateByExample(@Param("record") NodeMessage record, @Param("example") NodeMessageExample example);

    int updateByPrimaryKeySelective(NodeMessage record);

    int updateByPrimaryKey(NodeMessage record);
}