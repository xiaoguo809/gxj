package com.bozhilin.buildingrobot.trackingpositioning.common.inf;

/**
 * @Author pengjunming
 * @Date  2019/8/26 16:24
 * @Description 业务处理器
 **/
public interface Processor {

    void process();
}
