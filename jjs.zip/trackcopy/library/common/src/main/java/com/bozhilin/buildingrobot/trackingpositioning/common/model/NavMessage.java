package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;

public class NavMessage implements Serializable {
    @ApiModelProperty(value = "航道消息id")
    private String id;

    @ApiModelProperty(value = "航道id")
    private Integer navLineId;

    @ApiModelProperty(value = "航道消息发送状态1.已发送2.接受成功 3.接受失败")
    private String navStatus;

    @ApiModelProperty(value = "航道状态：0->空闲；1->航行中")
    private String navLineStatus;

    @ApiModelProperty(value = "创建时间")
    private String createTime;

    @ApiModelProperty(value = "修改时间")
    private String updateTime;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getNavLineId() {
        return navLineId;
    }

    public void setNavLineId(Integer navLineId) {
        this.navLineId = navLineId;
    }

    public String getNavStatus() {
        return navStatus;
    }

    public void setNavStatus(String navStatus) {
        this.navStatus = navStatus == null ? null : navStatus.trim();
    }

    public String getNavLineStatus() {
        return navLineStatus;
    }

    public void setNavLineStatus(String navLineStatus) {
        this.navLineStatus = navLineStatus == null ? null : navLineStatus.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", navLineId=").append(navLineId);
        sb.append(", navStatus=").append(navStatus);
        sb.append(", navLineStatus=").append(navLineStatus);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}