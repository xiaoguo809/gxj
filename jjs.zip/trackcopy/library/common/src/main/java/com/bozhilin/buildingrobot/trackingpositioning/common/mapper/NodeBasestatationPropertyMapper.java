package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestatationProperty;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestatationPropertyExample;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestatationPropertyKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeBasestatationPropertyMapper {
    int deleteByExample(NodeBasestatationPropertyExample example);

    int deleteByPrimaryKey(NodeBasestatationPropertyKey key);

    int insert(NodeBasestatationProperty record);

    int insertSelective(NodeBasestatationProperty record);

    List<NodeBasestatationProperty> selectByExample(NodeBasestatationPropertyExample example);

    NodeBasestatationProperty selectByPrimaryKey(NodeBasestatationPropertyKey key);

    int updateByExampleSelective(@Param("record") NodeBasestatationProperty record, @Param("example") NodeBasestatationPropertyExample example);

    int updateByExample(@Param("record") NodeBasestatationProperty record, @Param("example") NodeBasestatationPropertyExample example);

    int updateByPrimaryKeySelective(NodeBasestatationProperty record);

    int updateByPrimaryKey(NodeBasestatationProperty record);
}