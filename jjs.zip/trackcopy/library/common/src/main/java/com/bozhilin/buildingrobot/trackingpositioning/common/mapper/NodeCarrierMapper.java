package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCarrier;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCarrierExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeCarrierMapper {
    int deleteByExample(NodeCarrierExample example);

    int deleteByPrimaryKey(Long id);

    int insert(NodeCarrier record);

    int insertSelective(NodeCarrier record);

    List<NodeCarrier> selectByExample(NodeCarrierExample example);

    NodeCarrier selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") NodeCarrier record, @Param("example") NodeCarrierExample example);

    int updateByExample(@Param("record") NodeCarrier record, @Param("example") NodeCarrierExample example);

    int updateByPrimaryKeySelective(NodeCarrier record);

    int updateByPrimaryKey(NodeCarrier record);
}