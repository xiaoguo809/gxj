package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTree;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTreeExample;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTreeKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeTreeMapper {
    int deleteByExample(NodeTreeExample example);

    int deleteByPrimaryKey(NodeTreeKey key);

    int insert(NodeTree record);

    int insertSelective(NodeTree record);

    List<NodeTree> selectByExample(NodeTreeExample example);

    NodeTree selectByPrimaryKey(NodeTreeKey key);

    int updateByExampleSelective(@Param("record") NodeTree record, @Param("example") NodeTreeExample example);

    int updateByExample(@Param("record") NodeTree record, @Param("example") NodeTreeExample example);

    int updateByPrimaryKeySelective(NodeTree record);

    int updateByPrimaryKey(NodeTree record);
}