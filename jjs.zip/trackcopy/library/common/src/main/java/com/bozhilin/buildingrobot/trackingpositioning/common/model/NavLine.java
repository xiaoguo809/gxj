package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class NavLine implements Serializable {
    @ApiModelProperty(value = "航线id")
    private Integer id;

    @ApiModelProperty(value = "航线名称")
    private String name;

    @ApiModelProperty(value = "航行次数")
    private Integer usedTimes;

    @ApiModelProperty(value = "状态：0->空闲；1->航行中")
    private Integer state;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date modifyTime;

    @ApiModelProperty(value = "是否闭合:0->不闭合，1->闭合")
    private Integer circleOrNot;

    @ApiModelProperty(value = "锚点,字符串数组，数组长度固定为2")
    private String anchorPoint;

    @ApiModelProperty(value = "航点数组信息,包含x和y的点的数组")
    private String navPoint;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getUsedTimes() {
        return usedTimes;
    }

    public void setUsedTimes(Integer usedTimes) {
        this.usedTimes = usedTimes;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Integer getCircleOrNot() {
        return circleOrNot;
    }

    public void setCircleOrNot(Integer circleOrNot) {
        this.circleOrNot = circleOrNot;
    }

    public String getAnchorPoint() {
        return anchorPoint;
    }

    public void setAnchorPoint(String anchorPoint) {
        this.anchorPoint = anchorPoint == null ? null : anchorPoint.trim();
    }

    public String getNavPoint() {
        return navPoint;
    }

    public void setNavPoint(String navPoint) {
        this.navPoint = navPoint == null ? null : navPoint.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", name=").append(name);
        sb.append(", usedTimes=").append(usedTimes);
        sb.append(", state=").append(state);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", circleOrNot=").append(circleOrNot);
        sb.append(", anchorPoint=").append(anchorPoint);
        sb.append(", navPoint=").append(navPoint);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}