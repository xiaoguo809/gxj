package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
@Api(tags = "IconData")
@Getter
@Setter
public class IconData implements Serializable {
    private Long id;

    @ApiModelProperty(value = "图标的名称")
    private String name;

    @ApiModelProperty(value = "图标类型")
    private Integer iconType;

    @ApiModelProperty(value = "文件的大小单位B")
    private Integer size;

    @ApiModelProperty(value = "图标文件的类型")
    private String iconFileType;

    @ApiModelProperty(value = "图标文件的id")
    private Long iconFileId;

    private static final long serialVersionUID = 1L;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", name=").append(name);
        sb.append(", iconType=").append(iconType);
        sb.append(", size=").append(size);
        sb.append(", iconFileType=").append(iconFileType);
        sb.append(", iconFileId=").append(iconFileId);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}