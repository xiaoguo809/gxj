package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class NodeSynchronizerProperty extends NodeSynchronizerPropertyKey implements Serializable {
    @ApiModelProperty(value = "基站容量")
    private Integer baseStationCapacity;

    @ApiModelProperty(value = "标签容量")
    private Integer labelCapacity;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date modifyTime;

    @ApiModelProperty(value = "修改标志，0->未修改，1->已修改，待服务端读取")
    private Integer modifyFlag;

    private static final long serialVersionUID = 1L;

    public Integer getBaseStationCapacity() {
        return baseStationCapacity;
    }

    public void setBaseStationCapacity(Integer baseStationCapacity) {
        this.baseStationCapacity = baseStationCapacity;
    }

    public Integer getLabelCapacity() {
        return labelCapacity;
    }

    public void setLabelCapacity(Integer labelCapacity) {
        this.labelCapacity = labelCapacity;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Integer getModifyFlag() {
        return modifyFlag;
    }

    public void setModifyFlag(Integer modifyFlag) {
        this.modifyFlag = modifyFlag;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", baseStationCapacity=").append(baseStationCapacity);
        sb.append(", labelCapacity=").append(labelCapacity);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", modifyFlag=").append(modifyFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}