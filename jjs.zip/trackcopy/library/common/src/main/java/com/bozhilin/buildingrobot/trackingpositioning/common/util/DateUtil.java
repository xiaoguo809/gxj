package com.bozhilin.buildingrobot.trackingpositioning.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 日期工具类
 * Created by TanJY on 2019/8/15.
 */
public class DateUtil {

	// 默认日期格式
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	// 默认时间格式
	public static final String DEFAULT_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	// excel时间格式
	public static final String EXCEL_DATETIME_FORMAT = "yyyy/MM/dd";
	
	public static final String NEW_EXCEL_DATETIME_FORMAT = "yyyy/MM/dd HH:mm:ss";

	public static final String ZD_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";

	public static final String TZ_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
	
	public static final String SQL_DATETIME_FORMAT = "yyyy_MM_dd_HH_mm_ss";
	// excel时间格式
	public static final String EXCEL_DATETIME_FORMAT_SHORT = "yyyy/MM";
	
	public static final String DATETIME_FORMAT_SHORT = "yyyy-MM";
	// 时分秒
	public static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";

	public static final String DATETIME_NUMBER_FORMAT = "yyyyMMddHHmmss";

	public static final String DATE_NUMBER_FORMAT = "yyyyMMdd";

	public static final String DATE_HOUR_NUMBER_FORMAT = "yyyyMMddHH";

	private static Calendar gregorianCalendar = null;
	/**一小时的秒数
	 */
	private static final int second_num = 3600;
	/**一天的小时数
	 */
	private static final int second_day = 24;
	/**一小时的分钟数
	 */
	private static final int second_min = 60;

	/** 锁对象 */
	private static final Object lockObj = new Object();
	/** 存放不同的日期模板格式的sdf的Map */
	private static Map<String, ThreadLocal<SimpleDateFormat>> sdfMap = new HashMap<String, ThreadLocal<SimpleDateFormat>>();

	static {
		gregorianCalendar = new GregorianCalendar();
	}

	/**
	 * 返回一个ThreadLocal的sdf,每个线程只会new一次sdf
	 * @param pattern
	 * @return
	 */
	private static SimpleDateFormat getFormat(final String pattern) {
		ThreadLocal<SimpleDateFormat> tl = sdfMap.get(pattern);
		if (tl == null) {
			synchronized (lockObj) {
				tl = sdfMap.get(pattern);
				if (tl == null) {
					// 使用ThreadLocal<SimpleDateFormat>替代原来直接new SimpleDateFormat
					tl = new ThreadLocal<SimpleDateFormat>() {
						@Override
						protected SimpleDateFormat initialValue() {
							return new SimpleDateFormat(pattern);
						}
					};
					sdfMap.put(pattern, tl);
				}
			}
		}
		return tl.get();
	}
	
	/**
	 * 
	 * @Description 比较天数
	 * @date 2017年8月3日 下午11:37:55
	 * @param date1
	 * @param date2
	 * @return
	 * @lastModifier
	 */
	public static int compareDays(Date date1, Date date2) {
		if (date1 == null || date2 == null) return 0;
		return (int)((getDate(date2).getTime() - getDate(date1).getTime())/ (24 * 60 * 60 * 1000));
	}

	/**
	 * 日期格式化yyyy-MM-dd
	 * @param date
	 * @return
	 */
	public static Date formatDate(String date, String format) {
		if (StringUtil.isEmpty(date) || StringUtil.isEmpty(format)) {
			return null;
		}

		try {
			return new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 日期格式化yyyy-MM-dd
	 * @param date
	 * @return
	 */
	public static String getDateFormat(Date date) {
		if (date == null) {
			return null;
		}
		return getFormat(DEFAULT_DATE_FORMAT).format(date);
	}

	/**
	 * 日期格式化yyyy-MM-dd HH:mm:ss
	 * @param date
	 * @return
	 */
	public static String getDateTimeFormat(Date date) {
		if (date == null) {
			return null;
		}
		return getFormat(DEFAULT_DATETIME_FORMAT).format(date);
	}

	/**
	 * 时间格式化
	 * 
	 * @param date
	 * @return HH:mm:ss
	 */
	public static String getTimeFormat(Date date) {
		if (date == null) {
			return null;
		}
		return getFormat(DEFAULT_TIME_FORMAT).format(date);
	}

	/**
	 * 日期格式化
	 * 
	 * @param date
	 * @param formatStr 格式类型
	 * @return
	 */
	public static String getDateFormat(Date date, String formatStr) {
		if (date == null || StringUtil.isEmpty(formatStr)) {
			return null;
		}
		if (!StringUtil.isEmpty(formatStr)) {
			return getFormat(formatStr).format(date);
		}
		return null;
	}

	/**
	 * 日期格式化
	 * 
	 * @param date
	 * @return
	 */
	public static Date getDateFormat(String date,String type) {
		if (date == null ||type==null) {
			return null;
		}
		try {
			return getFormat(type).parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 日期格式化
	 * 
	 * @param date
	 * @return
	 */
	public static Date getDateFormat(String date) {
		if (date == null) {
			return null;
		}
		try {
			return getFormat(DEFAULT_DATE_FORMAT).parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 时间格式化
	 * 
	 * @param date
	 * @return
	 */
	public static Date getDateTimeFormat(String date) {
		if (date == null) {
			return null;
		}
		try {
			return getFormat(DEFAULT_DATETIME_FORMAT).parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}


	public static Date getZdDateTimeFormat(String date) {
		if (date == null) {
			return null;
		}
		try {
			return getFormat(ZD_DATETIME_FORMAT).parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getZdDateTimeStr(String date) {
		if (date == null) {
			return null;
		}
		try {
			Date parse = getFormat(ZD_DATETIME_FORMAT).parse(date);
			return  getDateTimeFormat(parse);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 
	 * @Description 获取日期（零点）
	 * @date 2017年8月3日 下午11:48:39
	 * @param date
	 * @return
	 * @lastModifier
	 */
	public static Date getDate(Date date) {
		if (date == null) return null;
		return DateUtil.getDateFormat(getFormat(DEFAULT_DATE_FORMAT).format(date));
	}
	
	/**
	 * 获取当前日期(yyyy-MM-dd)
	 * @return
	 */
	public static Date getNowDate() {
		return DateUtil.getDateFormat(getFormat(DEFAULT_DATE_FORMAT).format(new Date()));
	}

	/**
	 * 获取当前时间(yyyy-MM-dd HH:mm:ss)
	 * @return
	 */
	public static Date getNowTime() {
		return DateUtil.getDateTimeFormat(getFormat(DEFAULT_DATETIME_FORMAT).format(new Date()));
	}

	/**
	 * 获取当前日期星期一日期
	 * @return date
	 */
	public static Date getFirstDayOfWeek() {
		gregorianCalendar.setFirstDayOfWeek(Calendar.MONDAY);
		gregorianCalendar.setTime(new Date());
		gregorianCalendar.set(Calendar.DAY_OF_WEEK, gregorianCalendar.getFirstDayOfWeek()); // Monday
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取当前日期星期日日期
	 * @return date
	 */
	public static Date getLastDayOfWeek() {
		gregorianCalendar.setFirstDayOfWeek(Calendar.MONDAY);
		gregorianCalendar.setTime(new Date());
		gregorianCalendar.set(Calendar.DAY_OF_WEEK, gregorianCalendar.getFirstDayOfWeek() + 6); // Monday
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取日期星期一日期
	 * @param date 指定日期
	 * @return date
	 */
	public static Date getFirstDayOfWeek(Date date) {
		if (date == null) {
			return null;
		}
		gregorianCalendar.setFirstDayOfWeek(Calendar.MONDAY);
		gregorianCalendar.setTime(date);
		gregorianCalendar.set(Calendar.DAY_OF_WEEK, gregorianCalendar.getFirstDayOfWeek()); // Monday
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取日期星期一日期
	 * @param date 指定日期
	 * @return date
	 */
	public static Date getLastDayOfWeek(Date date) {
		if (date == null) {
			return null;
		}
		gregorianCalendar.setFirstDayOfWeek(Calendar.MONDAY);
		gregorianCalendar.setTime(date);
		gregorianCalendar.set(Calendar.DAY_OF_WEEK, gregorianCalendar.getFirstDayOfWeek() + 6); // Monday
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取当前月的第一天
	 * @return date
	 */
	public static Date getFirstDayOfMonth() {
		gregorianCalendar.setTime(new Date());
		gregorianCalendar.set(Calendar.DAY_OF_MONTH, 1);
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取当前月的最后一天
	 * @return
	 */
	public static Date getLastDayOfMonth() {
		gregorianCalendar.setTime(new Date());
		gregorianCalendar.set(Calendar.DAY_OF_MONTH, 1);
		gregorianCalendar.add(Calendar.MONTH, 1);
		gregorianCalendar.add(Calendar.DAY_OF_MONTH, -1);
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取指定月的第一天
	 * @param date
	 * @return
	 */
	public static Date getFirstDayOfMonth(Date date) {
		gregorianCalendar.setTime(date);
		gregorianCalendar.set(Calendar.DAY_OF_MONTH, 1);
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取指定月的最后一天
	 * @param date
	 * @return
	 */
	public static Date getLastDayOfMonth(Date date) {
		if (date == null) {
			return null;
		}
		gregorianCalendar.setTime(date);
		gregorianCalendar.set(Calendar.DAY_OF_MONTH, 1);
		gregorianCalendar.add(Calendar.MONTH, 1);
		gregorianCalendar.add(Calendar.DAY_OF_MONTH, -1);
		return gregorianCalendar.getTime();
	}

	/**
	 * @Description 获取当年第一天 00:00:00
	 * @date 2017年4月26日 上午9:58:24
	 * @return
	 * @lastModifier
	 */
	public static Date getCurrYearFirstDay() {
		return getYearFirstDay(new Date());
	}

	/**
	 * @Description 获取指定年第一天 00:00:00
	 * @date 2017年4月26日 上午10:01:49
	 * @param date
	 * @return
	 * @lastModifier
	 */
	public static Date getYearFirstDay(Date date) {
		gregorianCalendar.setTime(date);
		gregorianCalendar.set(Calendar.MONTH, 1);
		gregorianCalendar.set(Calendar.HOUR, 0);
		gregorianCalendar.set(Calendar.MINUTE, 0);
		gregorianCalendar.set(Calendar.DAY_OF_MONTH, 1);
		gregorianCalendar.set(Calendar.SECOND, 0);
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取日期前一天
	 * @param date
	 * @return
	 */
	public static Date getDayBefore(Date date) {
		if (date == null) {
			return null;
		}
		gregorianCalendar.setTime(date);
		int day = gregorianCalendar.get(Calendar.DATE);
		gregorianCalendar.set(Calendar.DATE, day - 1);
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取日期后一天
	 * @param date
	 * @return
	 */
	public static Date getDayAfter(Date date) {
		if (date == null) {
			return null;
		}
		gregorianCalendar.setTime(date);
		int day = gregorianCalendar.get(Calendar.DATE);
		gregorianCalendar.set(Calendar.DATE, day + 1);
		return gregorianCalendar.getTime();
	}

	/**
	 * 获取当前年
	 * @return
	 */
	public static int getNowYear() {
		Calendar d = Calendar.getInstance();
		return d.get(Calendar.YEAR);
	}

	/**
	 * 获取年
	 */
	public static int getYear(Date date) {
		Calendar d = Calendar.getInstance();
		d.setTime(date);
		return d.get(Calendar.YEAR);
	}

	/**
	 * 获取年
	 */
	public static int getMonth(Date date) {
		Calendar d = Calendar.getInstance();
		d.setTime(date);
		return d.get(Calendar.MONTH) + 1;
	}

	/**
	 * 获取当前月份
	 */
	public static int getNowMonth() {
		Calendar d = Calendar.getInstance();
		return d.get(Calendar.MONTH) + 1;
	}
	

	/**
	 * 获取当月的第几天
	 */
	public static int getNowMonDay() {
		Calendar d = Calendar.getInstance();
		return d.get(Calendar.DATE);
	}

	/**
	 * 获取当月天数
	 */
	public static int getNowMonthDay() {
		Calendar d = Calendar.getInstance();
		return d.getActualMaximum(Calendar.DATE);
	}

	/**
	 * 获取时间段的每一天
	 * @param startDate 开始日期
	 * @param endDate 结算日期
	 * @return 日期列表
	 */
	public static List<Date> getEveryDay(Date startDate, Date endDate) {
		if (startDate == null || endDate == null) {
			return null;
		}
		// 格式化日期(yy-MM-dd)
		startDate = DateUtil.getDateFormat(DateUtil.getDateFormat(startDate));
		endDate = DateUtil.getDateFormat(DateUtil.getDateFormat(endDate));
		List<Date> dates = new ArrayList<Date>();
		gregorianCalendar.setTime(startDate);
		dates.add(gregorianCalendar.getTime());
		while (gregorianCalendar.getTime().compareTo(endDate) < 0) {
			// 加1天
			gregorianCalendar.add(Calendar.DAY_OF_MONTH, 1);
			dates.add(gregorianCalendar.getTime());
		}
		return dates;
	}

	/**
	 * 获取提前多少个月
	 */
	public static Date getFirstMonth(int monty) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.MONTH, -monty);
		return c.getTime();
	}

	/**
	 * 增加时间（秒）
	 */
	public static Date addSeconds(Date date, int seconds) {
		if (date == null) {
			return null;
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.SECOND, seconds);
		return c.getTime();
	}

	/**
	 * 增加时间（分）
	 */
	public static Date addMinutes(Date date, int minutes) {
		if (date == null) {
			return null;
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MINUTE, minutes);
		return c.getTime();
	}

	/**
	 * 增加时间（时）
	 * @param date
	 * @param hours
	 * @return
	 */
	public static Date addHours(Date date, int hours) {
		if (date == null) {
			return null;
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.HOUR_OF_DAY, hours);
		return c.getTime();
	}

	/**
	 * 增加时间（月）
	 */
	public static Date addMonth(Date date, int month) {
		if (date == null) {
			return null;
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MONTH, month);
		return c.getTime();
	}
	
	/**
	 * 增加日期（天）
	 */
	public static Date addDays(Date date, int days) {
		if (date == null) {
			return null;
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.DATE, days);
		return c.getTime();
	}
	
	
	/**
	 * 比较2个日期的大小
	 */
	public static int compare(Date dateA,Date dateB){
		Calendar calendarA  = Calendar.getInstance();
		calendarA.setTime(dateA);
		Calendar calendarB  = Calendar.getInstance();
		calendarB.setTime(dateB);
		return calendarA.compareTo(calendarB);
	}
	
	/**
	 * 添加时间显示名称获取
	 */
	public  static  String getTimeFormat(Integer _num){
		String _data_time_format = null;
		if(_num==null || _num <=0)
			return _data_time_format;
		long days = _num / (60 * 60 * 24);
		long hours = (_num % (60 * 60 * 24)) / (60 * 60);
		long minutes = (_num % (60 * 60)) / 60;
		long seconds = _num % 60;
		if (days > 0) {
			_data_time_format = days + "天" + hours + "小时" + minutes + "分钟" + seconds + "秒";
		} else if (hours > 0) {
			_data_time_format = hours + "小时" + minutes + "分钟" + seconds + "秒";
		} else if (minutes > 0) {
			_data_time_format = minutes + "分钟" + seconds + "秒";
		} else {
			_data_time_format = seconds + "秒";
		}
		return _data_time_format;
	}
	
	public static void main(String[] args) {
		System.out.println(getTimeFormat(1000));
	}
}
