package com.bozhilin.buildingrobot.trackingpositioning.common.model;

/**
 * 枚举了一些常用API操作码
 * Created by chenang on 2019/7/28
 */
public enum ResultCode implements IErrorCode {
    SUCCESS(200, "操作成功"),
    FAILED(500, "操作失败"),
    VALIDATE_FAILED(404, "参数检验失败"),
    UNAUTHORIZED(401, "暂未登录或token已经过期"),
    FORBIDDEN(403, "没有相关权限"),
    EMPTY_PARAMETER(400, "参数为空"),
    ERROR_PARAMETER(400, "参数错误"),
    RECORD_ALREADY_EXISTS(405, "记录已存在"),
    RECORD_NOT_EXISTS(406, "记录不存在");

    private int code;
    private String message;

    ResultCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
