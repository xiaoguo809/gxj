package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeSynchronizerProperty;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeSynchronizerPropertyExample;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeSynchronizerPropertyKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeSynchronizerPropertyMapper {
    int deleteByExample(NodeSynchronizerPropertyExample example);

    int deleteByPrimaryKey(NodeSynchronizerPropertyKey key);

    int insert(NodeSynchronizerProperty record);

    int insertSelective(NodeSynchronizerProperty record);

    List<NodeSynchronizerProperty> selectByExample(NodeSynchronizerPropertyExample example);

    NodeSynchronizerProperty selectByPrimaryKey(NodeSynchronizerPropertyKey key);

    int updateByExampleSelective(@Param("record") NodeSynchronizerProperty record, @Param("example") NodeSynchronizerPropertyExample example);

    int updateByExample(@Param("record") NodeSynchronizerProperty record, @Param("example") NodeSynchronizerPropertyExample example);

    int updateByPrimaryKeySelective(NodeSynchronizerProperty record);

    int updateByPrimaryKey(NodeSynchronizerProperty record);
}