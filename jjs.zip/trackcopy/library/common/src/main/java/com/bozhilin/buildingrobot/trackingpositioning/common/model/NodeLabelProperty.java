package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class NodeLabelProperty extends NodeLabelPropertyKey implements Serializable {
    @ApiModelProperty(value = "标签角色,取值1，2，3	1=A类标签 2=B类标签 3=C类标签")
    private Integer role;

    @ApiModelProperty(value = "光速，取值0，1	")
    private Integer lightVelocity;

    @ApiModelProperty(value = "天线延迟值Tx")
    private Integer antennaDelayTx;

    @ApiModelProperty(value = "天线延迟值Rx")
    private Integer antennaDelayRx;

    @ApiModelProperty(value = "信道")
    private Integer channel;

    @ApiModelProperty(value = "UWB速度，取值0，1	0=110K,1=6.8M")
    private Integer uwbVelocity;

    @ApiModelProperty(value = "UWB峰值重复频率，取值0，1	0=16,1=64")
    private Integer uwbPeakFrequency;

    @ApiModelProperty(value = "前导码，取值0-23: 0=32,1=64,2=128,…")
    private Integer preamble;

    @ApiModelProperty(value = "标签刷新频率")
    private Integer refreshFrequency;

    @ApiModelProperty(value = "标签上传频率")
    private Integer uploadFrequency;

    @ApiModelProperty(value = "数据输出频率")
    private Integer dataOutputFrequency;

    @ApiModelProperty(value = "局域网id")
    private Integer lanId;

    @ApiModelProperty(value = "UWB最小测量时间单位")
    private Integer minTimeUnit;

    @ApiModelProperty(value = "载体ID")
    private Long carrierId;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date modifyTime;

    @ApiModelProperty(value = "修改标志，0->未修改，1->已修改，待服务端读取")
    private Integer modifyFlag;

    private static final long serialVersionUID = 1L;

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }

    public Integer getLightVelocity() {
        return lightVelocity;
    }

    public void setLightVelocity(Integer lightVelocity) {
        this.lightVelocity = lightVelocity;
    }

    public Integer getAntennaDelayTx() {
        return antennaDelayTx;
    }

    public void setAntennaDelayTx(Integer antennaDelayTx) {
        this.antennaDelayTx = antennaDelayTx;
    }

    public Integer getAntennaDelayRx() {
        return antennaDelayRx;
    }

    public void setAntennaDelayRx(Integer antennaDelayRx) {
        this.antennaDelayRx = antennaDelayRx;
    }

    public Integer getChannel() {
        return channel;
    }

    public void setChannel(Integer channel) {
        this.channel = channel;
    }

    public Integer getUwbVelocity() {
        return uwbVelocity;
    }

    public void setUwbVelocity(Integer uwbVelocity) {
        this.uwbVelocity = uwbVelocity;
    }

    public Integer getUwbPeakFrequency() {
        return uwbPeakFrequency;
    }

    public void setUwbPeakFrequency(Integer uwbPeakFrequency) {
        this.uwbPeakFrequency = uwbPeakFrequency;
    }

    public Integer getPreamble() {
        return preamble;
    }

    public void setPreamble(Integer preamble) {
        this.preamble = preamble;
    }

    public Integer getRefreshFrequency() {
        return refreshFrequency;
    }

    public void setRefreshFrequency(Integer refreshFrequency) {
        this.refreshFrequency = refreshFrequency;
    }

    public Integer getUploadFrequency() {
        return uploadFrequency;
    }

    public void setUploadFrequency(Integer uploadFrequency) {
        this.uploadFrequency = uploadFrequency;
    }

    public Integer getDataOutputFrequency() {
        return dataOutputFrequency;
    }

    public void setDataOutputFrequency(Integer dataOutputFrequency) {
        this.dataOutputFrequency = dataOutputFrequency;
    }

    public Integer getLanId() {
        return lanId;
    }

    public void setLanId(Integer lanId) {
        this.lanId = lanId;
    }

    public Integer getMinTimeUnit() {
        return minTimeUnit;
    }

    public void setMinTimeUnit(Integer minTimeUnit) {
        this.minTimeUnit = minTimeUnit;
    }

    public Long getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(Long carrierId) {
        this.carrierId = carrierId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Integer getModifyFlag() {
        return modifyFlag;
    }

    public void setModifyFlag(Integer modifyFlag) {
        this.modifyFlag = modifyFlag;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", role=").append(role);
        sb.append(", lightVelocity=").append(lightVelocity);
        sb.append(", antennaDelayTx=").append(antennaDelayTx);
        sb.append(", antennaDelayRx=").append(antennaDelayRx);
        sb.append(", channel=").append(channel);
        sb.append(", uwbVelocity=").append(uwbVelocity);
        sb.append(", uwbPeakFrequency=").append(uwbPeakFrequency);
        sb.append(", preamble=").append(preamble);
        sb.append(", refreshFrequency=").append(refreshFrequency);
        sb.append(", uploadFrequency=").append(uploadFrequency);
        sb.append(", dataOutputFrequency=").append(dataOutputFrequency);
        sb.append(", lanId=").append(lanId);
        sb.append(", minTimeUnit=").append(minTimeUnit);
        sb.append(", carrierId=").append(carrierId);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", modifyFlag=").append(modifyFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}