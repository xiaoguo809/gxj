package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

import lombok.Data;

/**
 * @Author: pengjunming
 * @Date:2019/8/21 10:46
 * @Description: 轨迹模块websocket相关属性配置类
 */
@Component
@ConfigurationProperties(prefix = "websocket.track")
@Data
public class TrackContext {

    // 订阅主题
    private String topic;

    // Client端发送的目的地前缀
    private String sendDestPreFix;

    // 订阅目的地址前缀
    private String subDestPreFix;

    // 广播地址
    private String broadcast;

    // Client连接的终端
    private String[] endPoints;

    // 同源策略
    private String[] allowedOrigins;

    // 通信通道拦截器
    private List<String> channelInterceptorBeans;

    // 缓存设置
    private CacheContext cache;


    @Data
    public static class CacheContext {

        // 区域跟session映射关系key前缀
        private String areaToSessionPrefix;

        // session跟区域映射关系key前缀
        private String sessionToAreaPrefix;

        // 标签的全局分布式锁
        private String areaSessionLockPrefix;

        // 根据标签关联区域
        private String labelToArea;

        // 根据区域关联标签
        private String areaToLabelsPrefix;

        // 区域关联负载集合的key
        private String areaToPayloadsPrefix;

        // 缓存有效期
        private long expireTime;

        // 数据采样数量key前缀
        private String sampleAmountPrefix;

        // 记录标签所有轨迹数据
        private String labelAllPayloadPrefix;

        // 记录标签每秒的轨迹
        private String labelPayloadPerSecondPrefix;

        // 保存所有标签的key
        private String allLabelsKey;
    }

    // 获取区域key
    public String getAreaToSessionKey(String labelCode) {
        return this.cache.getAreaToSessionPrefix() + ":" + labelCode;
    }

    public String getSessionToAreaKey(String sessionId) {
        return this.cache.getSessionToAreaPrefix() + ":" + sessionId;
    }

    public long getExpireTime() {
        return this.cache.getExpireTime();
    }

    public String getAreaSessionLockKey(String areaCode) {
        return this.cache.getAreaSessionLockPrefix() + ":" + areaCode;
    }

    public String getLabelToArea() {
        return this.cache.getLabelToArea();
    }

    public String getAreaToLabelsKey(String areaCode) {
        return this.cache.getAreaToLabelsPrefix() + ":" + areaCode;
    }

    public String getAreaToPayloadKey(String areaCode) {
        return this.cache.getAreaToPayloadsPrefix() + ":" + areaCode;
    }

    public String getAreaSampleAmoutKey(String areaCode) {
        return this.cache.getSampleAmountPrefix() + ":" + areaCode;
    }

    public String getLabelAllPayloadKey(String serverId, String labelCode) {
        return this.cache.getLabelAllPayloadPrefix() + ":" + serverId + ":" +labelCode;
    }

    public String getLabelPayloadPerSecondKey(String serverId, String nodeCode, long currentSeconds) {
        return this.cache.getLabelPayloadPerSecondPrefix() + ":" + serverId + ":" + nodeCode + ":" + currentSeconds;
    }

    public String getAllLabelsKey() {
        return this.cache.getAllLabelsKey();
    }
}
