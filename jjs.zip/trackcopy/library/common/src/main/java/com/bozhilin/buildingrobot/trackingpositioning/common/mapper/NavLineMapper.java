package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NavLine;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NavLineExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NavLineMapper {
    int deleteByExample(NavLineExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(NavLine record);

    int insertSelective(NavLine record);

    List<NavLine> selectByExampleWithBLOBs(NavLineExample example);

    List<NavLine> selectByExample(NavLineExample example);

    NavLine selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") NavLine record, @Param("example") NavLineExample example);

    int updateByExampleWithBLOBs(@Param("record") NavLine record, @Param("example") NavLineExample example);

    int updateByExample(@Param("record") NavLine record, @Param("example") NavLineExample example);

    int updateByPrimaryKeySelective(NavLine record);

    int updateByPrimaryKeyWithBLOBs(NavLine record);

    int updateByPrimaryKey(NavLine record);
}