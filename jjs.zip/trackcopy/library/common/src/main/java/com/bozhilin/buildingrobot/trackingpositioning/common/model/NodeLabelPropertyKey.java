package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;

public class NodeLabelPropertyKey implements Serializable {
    @ApiModelProperty(value = "服务器id")
    private Integer serverId;

    @ApiModelProperty(value = "节点id")
    private Integer id;

    private static final long serialVersionUID = 1L;

    public Integer getServerId() {
        return serverId;
    }

    public void setServerId(Integer serverId) {
        this.serverId = serverId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", serverId=").append(serverId);
        sb.append(", id=").append(id);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}