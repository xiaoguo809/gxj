package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumDm;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumDmExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TrackSumDmMapper {
    int deleteByExample(TrackSumDmExample example);

    int deleteByPrimaryKey(Long id);

    int insert(TrackSumDm record);

    int insertSelective(TrackSumDm record);

    List<TrackSumDm> selectByExample(TrackSumDmExample example);

    TrackSumDm selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") TrackSumDm record, @Param("example") TrackSumDmExample example);

    int updateByExample(@Param("record") TrackSumDm record, @Param("example") TrackSumDmExample example);

    int updateByPrimaryKeySelective(TrackSumDm record);

    int updateByPrimaryKey(TrackSumDm record);
}