package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class NodeBasestatationProperty extends NodeBasestatationPropertyKey implements Serializable {
    @ApiModelProperty(value = "基站角色，取值1，2，3	1=一级基站 2=二级基站 3=三级基站")
    private Integer role;

    @ApiModelProperty(value = "从基站跟随主基站ID，从基站跟随主基站ID进行时钟同步")
    private Integer followMainId;

    @ApiModelProperty(value = "时隙长度")
    private Integer slotLength;

    @ApiModelProperty(value = "总时隙数目")
    private Integer slotNumber;

    @ApiModelProperty(value = "预留时隙数")
    private Integer slotReserve;

    @ApiModelProperty(value = "天线延迟值Tx")
    private Integer antennaDelayTx;

    @ApiModelProperty(value = "天线延迟值Rx")
    private Integer antennaDelayRx;

    @ApiModelProperty(value = "信道：1/2/3/4/5/7")
    private Integer channel;

    @ApiModelProperty(value = "光速，取值0，1	")
    private Integer lightVelocity;

    @ApiModelProperty(value = "UWB速度，取值0，1	0=110K,1=850K,2=6.8M,3=27M")
    private Integer uwbVelocity;

    @ApiModelProperty(value = "UWB峰值重复频率，取值0，1	0=16,1=64")
    private Integer uwbPeakFrequency;

    @ApiModelProperty(value = "前导码，取值0-23	0=32,1=64,2=128,…")
    private Integer preamble;

    @ApiModelProperty(value = "基站发送功率大小")
    private Integer transmissionPower;

    @ApiModelProperty(value = "x坐标")
    private Integer x;

    @ApiModelProperty(value = "y坐标")
    private Integer y;

    @ApiModelProperty(value = "z坐标")
    private Integer z;

    @ApiModelProperty(value = "RTK经度")
    private Integer longitude;

    @ApiModelProperty(value = "RTK纬度")
    private Integer latitude;

    @ApiModelProperty(value = "RTK高度")
    private Integer height;

    @ApiModelProperty(value = "基站侧TOF补偿值，各基站与参考基站之间的飞行时间")
    private Integer tofCompensation;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date modifyTime;

    @ApiModelProperty(value = "修改标志，0->未修改，1->已修改，待服务端读取")
    private Integer modifyFlag;

    private static final long serialVersionUID = 1L;

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }

    public Integer getFollowMainId() {
        return followMainId;
    }

    public void setFollowMainId(Integer followMainId) {
        this.followMainId = followMainId;
    }

    public Integer getSlotLength() {
        return slotLength;
    }

    public void setSlotLength(Integer slotLength) {
        this.slotLength = slotLength;
    }

    public Integer getSlotNumber() {
        return slotNumber;
    }

    public void setSlotNumber(Integer slotNumber) {
        this.slotNumber = slotNumber;
    }

    public Integer getSlotReserve() {
        return slotReserve;
    }

    public void setSlotReserve(Integer slotReserve) {
        this.slotReserve = slotReserve;
    }

    public Integer getAntennaDelayTx() {
        return antennaDelayTx;
    }

    public void setAntennaDelayTx(Integer antennaDelayTx) {
        this.antennaDelayTx = antennaDelayTx;
    }

    public Integer getAntennaDelayRx() {
        return antennaDelayRx;
    }

    public void setAntennaDelayRx(Integer antennaDelayRx) {
        this.antennaDelayRx = antennaDelayRx;
    }

    public Integer getChannel() {
        return channel;
    }

    public void setChannel(Integer channel) {
        this.channel = channel;
    }

    public Integer getLightVelocity() {
        return lightVelocity;
    }

    public void setLightVelocity(Integer lightVelocity) {
        this.lightVelocity = lightVelocity;
    }

    public Integer getUwbVelocity() {
        return uwbVelocity;
    }

    public void setUwbVelocity(Integer uwbVelocity) {
        this.uwbVelocity = uwbVelocity;
    }

    public Integer getUwbPeakFrequency() {
        return uwbPeakFrequency;
    }

    public void setUwbPeakFrequency(Integer uwbPeakFrequency) {
        this.uwbPeakFrequency = uwbPeakFrequency;
    }

    public Integer getPreamble() {
        return preamble;
    }

    public void setPreamble(Integer preamble) {
        this.preamble = preamble;
    }

    public Integer getTransmissionPower() {
        return transmissionPower;
    }

    public void setTransmissionPower(Integer transmissionPower) {
        this.transmissionPower = transmissionPower;
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public Integer getZ() {
        return z;
    }

    public void setZ(Integer z) {
        this.z = z;
    }

    public Integer getLongitude() {
        return longitude;
    }

    public void setLongitude(Integer longitude) {
        this.longitude = longitude;
    }

    public Integer getLatitude() {
        return latitude;
    }

    public void setLatitude(Integer latitude) {
        this.latitude = latitude;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getTofCompensation() {
        return tofCompensation;
    }

    public void setTofCompensation(Integer tofCompensation) {
        this.tofCompensation = tofCompensation;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Integer getModifyFlag() {
        return modifyFlag;
    }

    public void setModifyFlag(Integer modifyFlag) {
        this.modifyFlag = modifyFlag;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", role=").append(role);
        sb.append(", followMainId=").append(followMainId);
        sb.append(", slotLength=").append(slotLength);
        sb.append(", slotNumber=").append(slotNumber);
        sb.append(", slotReserve=").append(slotReserve);
        sb.append(", antennaDelayTx=").append(antennaDelayTx);
        sb.append(", antennaDelayRx=").append(antennaDelayRx);
        sb.append(", channel=").append(channel);
        sb.append(", lightVelocity=").append(lightVelocity);
        sb.append(", uwbVelocity=").append(uwbVelocity);
        sb.append(", uwbPeakFrequency=").append(uwbPeakFrequency);
        sb.append(", preamble=").append(preamble);
        sb.append(", transmissionPower=").append(transmissionPower);
        sb.append(", x=").append(x);
        sb.append(", y=").append(y);
        sb.append(", z=").append(z);
        sb.append(", longitude=").append(longitude);
        sb.append(", latitude=").append(latitude);
        sb.append(", height=").append(height);
        sb.append(", tofCompensation=").append(tofCompensation);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", modifyFlag=").append(modifyFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}