package com.bozhilin.buildingrobot.trackingpositioning.common.component;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.ServiceException;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class DefaultExceptionHandler {

    @ExceptionHandler(ServiceException.class)
    @ResponseBody
    public CommonResult<Object> handleServiceException(ServiceException e) {
        return CommonResult.failed(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public CommonResult<Object> handleException(Exception e) {
        return CommonResult.failed(e.getMessage());
    }
}
