package com.bozhilin.buildingrobot.trackingpositioning.common.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @Author: pengjunming
 * @Date:2019/9/23 15:32
 * @Description:
 */
@Component
public class BeanUtils {

    private static ApplicationContext context;

    @Autowired
    private ApplicationContext injectContext;

    @PostConstruct
    public void init(){
        context = injectContext;
    }

    public static <T> T getBean(Class<T> clz) {
        return context.getBean(clz);
    }

    public static Object getBean(String beanName) {
        return context.getBean(beanName);
    }
}
