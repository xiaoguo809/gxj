package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCategory;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCategoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeCategoryMapper {
    int deleteByExample(NodeCategoryExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(NodeCategory record);

    int insertSelective(NodeCategory record);

    List<NodeCategory> selectByExample(NodeCategoryExample example);

    NodeCategory selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") NodeCategory record, @Param("example") NodeCategoryExample example);

    int updateByExample(@Param("record") NodeCategory record, @Param("example") NodeCategoryExample example);

    int updateByPrimaryKeySelective(NodeCategory record);

    int updateByPrimaryKey(NodeCategory record);
}