package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import java.util.ArrayList;
import java.util.List;

public class NavMessageExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public NavMessageExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("id like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("id not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andNavLineIdIsNull() {
            addCriterion("nav_line_id is null");
            return (Criteria) this;
        }

        public Criteria andNavLineIdIsNotNull() {
            addCriterion("nav_line_id is not null");
            return (Criteria) this;
        }

        public Criteria andNavLineIdEqualTo(Integer value) {
            addCriterion("nav_line_id =", value, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdNotEqualTo(Integer value) {
            addCriterion("nav_line_id <>", value, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdGreaterThan(Integer value) {
            addCriterion("nav_line_id >", value, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("nav_line_id >=", value, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdLessThan(Integer value) {
            addCriterion("nav_line_id <", value, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdLessThanOrEqualTo(Integer value) {
            addCriterion("nav_line_id <=", value, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdIn(List<Integer> values) {
            addCriterion("nav_line_id in", values, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdNotIn(List<Integer> values) {
            addCriterion("nav_line_id not in", values, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdBetween(Integer value1, Integer value2) {
            addCriterion("nav_line_id between", value1, value2, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavLineIdNotBetween(Integer value1, Integer value2) {
            addCriterion("nav_line_id not between", value1, value2, "navLineId");
            return (Criteria) this;
        }

        public Criteria andNavStatusIsNull() {
            addCriterion("nav_status is null");
            return (Criteria) this;
        }

        public Criteria andNavStatusIsNotNull() {
            addCriterion("nav_status is not null");
            return (Criteria) this;
        }

        public Criteria andNavStatusEqualTo(String value) {
            addCriterion("nav_status =", value, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusNotEqualTo(String value) {
            addCriterion("nav_status <>", value, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusGreaterThan(String value) {
            addCriterion("nav_status >", value, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusGreaterThanOrEqualTo(String value) {
            addCriterion("nav_status >=", value, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusLessThan(String value) {
            addCriterion("nav_status <", value, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusLessThanOrEqualTo(String value) {
            addCriterion("nav_status <=", value, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusLike(String value) {
            addCriterion("nav_status like", value, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusNotLike(String value) {
            addCriterion("nav_status not like", value, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusIn(List<String> values) {
            addCriterion("nav_status in", values, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusNotIn(List<String> values) {
            addCriterion("nav_status not in", values, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusBetween(String value1, String value2) {
            addCriterion("nav_status between", value1, value2, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavStatusNotBetween(String value1, String value2) {
            addCriterion("nav_status not between", value1, value2, "navStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusIsNull() {
            addCriterion("nav_line_status is null");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusIsNotNull() {
            addCriterion("nav_line_status is not null");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusEqualTo(String value) {
            addCriterion("nav_line_status =", value, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusNotEqualTo(String value) {
            addCriterion("nav_line_status <>", value, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusGreaterThan(String value) {
            addCriterion("nav_line_status >", value, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusGreaterThanOrEqualTo(String value) {
            addCriterion("nav_line_status >=", value, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusLessThan(String value) {
            addCriterion("nav_line_status <", value, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusLessThanOrEqualTo(String value) {
            addCriterion("nav_line_status <=", value, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusLike(String value) {
            addCriterion("nav_line_status like", value, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusNotLike(String value) {
            addCriterion("nav_line_status not like", value, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusIn(List<String> values) {
            addCriterion("nav_line_status in", values, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusNotIn(List<String> values) {
            addCriterion("nav_line_status not in", values, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusBetween(String value1, String value2) {
            addCriterion("nav_line_status between", value1, value2, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andNavLineStatusNotBetween(String value1, String value2) {
            addCriterion("nav_line_status not between", value1, value2, "navLineStatus");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(String value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(String value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(String value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(String value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(String value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(String value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLike(String value) {
            addCriterion("create_time like", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotLike(String value) {
            addCriterion("create_time not like", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<String> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<String> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(String value1, String value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(String value1, String value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(String value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(String value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(String value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(String value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(String value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(String value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLike(String value) {
            addCriterion("update_time like", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotLike(String value) {
            addCriterion("update_time not like", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<String> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<String> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(String value1, String value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(String value1, String value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}