package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconFileData;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconFileDataExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface IconFileDataMapper {
    int deleteByExample(IconFileDataExample example);

    int deleteByPrimaryKey(Long id);

    int insert(IconFileData record);

    int insertSelective(IconFileData record);

    List<IconFileData> selectByExampleWithBLOBs(IconFileDataExample example);

    List<IconFileData> selectByExample(IconFileDataExample example);

    IconFileData selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") IconFileData record, @Param("example") IconFileDataExample example);

    int updateByExampleWithBLOBs(@Param("record") IconFileData record, @Param("example") IconFileDataExample example);

    int updateByExample(@Param("record") IconFileData record, @Param("example") IconFileDataExample example);

    int updateByPrimaryKeySelective(IconFileData record);

    int updateByPrimaryKeyWithBLOBs(IconFileData record);

    int updateByPrimaryKey(IconFileData record);
}