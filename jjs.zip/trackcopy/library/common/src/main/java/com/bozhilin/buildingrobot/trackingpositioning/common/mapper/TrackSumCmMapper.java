package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumCm;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumCmExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TrackSumCmMapper {
    int deleteByExample(TrackSumCmExample example);

    int deleteByPrimaryKey(Long id);

    int insert(TrackSumCm record);

    int insertSelective(TrackSumCm record);

    List<TrackSumCm> selectByExample(TrackSumCmExample example);

    TrackSumCm selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") TrackSumCm record, @Param("example") TrackSumCmExample example);

    int updateByExample(@Param("record") TrackSumCm record, @Param("example") TrackSumCmExample example);

    int updateByPrimaryKeySelective(TrackSumCm record);

    int updateByPrimaryKey(TrackSumCm record);
}