package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumM;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumMExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TrackSumMMapper {
    int deleteByExample(TrackSumMExample example);

    int deleteByPrimaryKey(Long id);

    int insert(TrackSumM record);

    int insertSelective(TrackSumM record);

    List<TrackSumM> selectByExample(TrackSumMExample example);

    TrackSumM selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") TrackSumM record, @Param("example") TrackSumMExample example);

    int updateByExample(@Param("record") TrackSumM record, @Param("example") TrackSumMExample example);

    int updateByPrimaryKeySelective(TrackSumM record);

    int updateByPrimaryKey(TrackSumM record);
}