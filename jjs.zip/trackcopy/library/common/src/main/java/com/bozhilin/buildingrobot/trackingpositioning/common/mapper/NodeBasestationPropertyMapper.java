package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestationProperty;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestationPropertyExample;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestationPropertyKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeBasestationPropertyMapper {
    int deleteByExample(NodeBasestationPropertyExample example);

    int deleteByPrimaryKey(NodeBasestationPropertyKey key);

    int insert(NodeBasestationProperty record);

    int insertSelective(NodeBasestationProperty record);

    List<NodeBasestationProperty> selectByExample(NodeBasestationPropertyExample example);

    NodeBasestationProperty selectByPrimaryKey(NodeBasestationPropertyKey key);

    int updateByExampleSelective(@Param("record") NodeBasestationProperty record, @Param("example") NodeBasestationPropertyExample example);

    int updateByExample(@Param("record") NodeBasestationProperty record, @Param("example") NodeBasestationPropertyExample example);

    int updateByPrimaryKeySelective(NodeBasestationProperty record);

    int updateByPrimaryKey(NodeBasestationProperty record);
}