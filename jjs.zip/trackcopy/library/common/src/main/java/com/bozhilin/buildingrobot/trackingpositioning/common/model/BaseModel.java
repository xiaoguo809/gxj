package com.bozhilin.buildingrobot.trackingpositioning.common.model;/**
 * @author :  pengjunming
 * @date :   11:09
 */

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 *@Author: pengjunming
 *@Date:2019/8/31 11:09
 *@Description: 基础模型信息
 *
 */
@Data
public class BaseModel {

    @ApiModelProperty(value = "主键id", required = true)
    private Long id;

    @ApiModelProperty(value = "新建的时间戳", required = true)
    private Date createdTimestamp;

    @ApiModelProperty(value = "修改的时间戳", required = true)
    private Date modifiedTimestamp;
}
