package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class NodeStatistics extends NodeStatisticsKey implements Serializable {
    @ApiModelProperty(value = "修改时间")
    private Date modifyTime;

    @ApiModelProperty(value = "节点上行数据量")
    private String upstreamTraffic;

    @ApiModelProperty(value = "节点下行数据量")
    private String downstreamTraffic;

    @ApiModelProperty(value = "A类标签数量")
    private String classAQuantity;

    @ApiModelProperty(value = "B类标签数量")
    private String classBQuantity;

    @ApiModelProperty(value = "C类标签数量")
    private String classCQuantity;

    private static final long serialVersionUID = 1L;

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getUpstreamTraffic() {
        return upstreamTraffic;
    }

    public void setUpstreamTraffic(String upstreamTraffic) {
        this.upstreamTraffic = upstreamTraffic == null ? null : upstreamTraffic.trim();
    }

    public String getDownstreamTraffic() {
        return downstreamTraffic;
    }

    public void setDownstreamTraffic(String downstreamTraffic) {
        this.downstreamTraffic = downstreamTraffic == null ? null : downstreamTraffic.trim();
    }

    public String getClassAQuantity() {
        return classAQuantity;
    }

    public void setClassAQuantity(String classAQuantity) {
        this.classAQuantity = classAQuantity == null ? null : classAQuantity.trim();
    }

    public String getClassBQuantity() {
        return classBQuantity;
    }

    public void setClassBQuantity(String classBQuantity) {
        this.classBQuantity = classBQuantity == null ? null : classBQuantity.trim();
    }

    public String getClassCQuantity() {
        return classCQuantity;
    }

    public void setClassCQuantity(String classCQuantity) {
        this.classCQuantity = classCQuantity == null ? null : classCQuantity.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", upstreamTraffic=").append(upstreamTraffic);
        sb.append(", downstreamTraffic=").append(downstreamTraffic);
        sb.append(", classAQuantity=").append(classAQuantity);
        sb.append(", classBQuantity=").append(classBQuantity);
        sb.append(", classCQuantity=").append(classCQuantity);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}