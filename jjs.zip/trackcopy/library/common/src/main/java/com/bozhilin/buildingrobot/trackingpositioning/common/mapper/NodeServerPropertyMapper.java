package com.bozhilin.buildingrobot.trackingpositioning.common.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeServerProperty;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeServerPropertyExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NodeServerPropertyMapper {
    int deleteByExample(NodeServerPropertyExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(NodeServerProperty record);

    int insertSelective(NodeServerProperty record);

    List<NodeServerProperty> selectByExample(NodeServerPropertyExample example);

    NodeServerProperty selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") NodeServerProperty record, @Param("example") NodeServerPropertyExample example);

    int updateByExample(@Param("record") NodeServerProperty record, @Param("example") NodeServerPropertyExample example);

    int updateByPrimaryKeySelective(NodeServerProperty record);

    int updateByPrimaryKey(NodeServerProperty record);
}