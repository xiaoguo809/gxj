package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NodeBasestationPropertyExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public NodeBasestationPropertyExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andServerIdIsNull() {
            addCriterion("server_id is null");
            return (Criteria) this;
        }

        public Criteria andServerIdIsNotNull() {
            addCriterion("server_id is not null");
            return (Criteria) this;
        }

        public Criteria andServerIdEqualTo(Integer value) {
            addCriterion("server_id =", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdNotEqualTo(Integer value) {
            addCriterion("server_id <>", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdGreaterThan(Integer value) {
            addCriterion("server_id >", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("server_id >=", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdLessThan(Integer value) {
            addCriterion("server_id <", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdLessThanOrEqualTo(Integer value) {
            addCriterion("server_id <=", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdIn(List<Integer> values) {
            addCriterion("server_id in", values, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdNotIn(List<Integer> values) {
            addCriterion("server_id not in", values, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdBetween(Integer value1, Integer value2) {
            addCriterion("server_id between", value1, value2, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdNotBetween(Integer value1, Integer value2) {
            addCriterion("server_id not between", value1, value2, "serverId");
            return (Criteria) this;
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andRoleIsNull() {
            addCriterion("role is null");
            return (Criteria) this;
        }

        public Criteria andRoleIsNotNull() {
            addCriterion("role is not null");
            return (Criteria) this;
        }

        public Criteria andRoleEqualTo(Integer value) {
            addCriterion("role =", value, "role");
            return (Criteria) this;
        }

        public Criteria andRoleNotEqualTo(Integer value) {
            addCriterion("role <>", value, "role");
            return (Criteria) this;
        }

        public Criteria andRoleGreaterThan(Integer value) {
            addCriterion("role >", value, "role");
            return (Criteria) this;
        }

        public Criteria andRoleGreaterThanOrEqualTo(Integer value) {
            addCriterion("role >=", value, "role");
            return (Criteria) this;
        }

        public Criteria andRoleLessThan(Integer value) {
            addCriterion("role <", value, "role");
            return (Criteria) this;
        }

        public Criteria andRoleLessThanOrEqualTo(Integer value) {
            addCriterion("role <=", value, "role");
            return (Criteria) this;
        }

        public Criteria andRoleIn(List<Integer> values) {
            addCriterion("role in", values, "role");
            return (Criteria) this;
        }

        public Criteria andRoleNotIn(List<Integer> values) {
            addCriterion("role not in", values, "role");
            return (Criteria) this;
        }

        public Criteria andRoleBetween(Integer value1, Integer value2) {
            addCriterion("role between", value1, value2, "role");
            return (Criteria) this;
        }

        public Criteria andRoleNotBetween(Integer value1, Integer value2) {
            addCriterion("role not between", value1, value2, "role");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdIsNull() {
            addCriterion("follow_main_id is null");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdIsNotNull() {
            addCriterion("follow_main_id is not null");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdEqualTo(Integer value) {
            addCriterion("follow_main_id =", value, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdNotEqualTo(Integer value) {
            addCriterion("follow_main_id <>", value, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdGreaterThan(Integer value) {
            addCriterion("follow_main_id >", value, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("follow_main_id >=", value, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdLessThan(Integer value) {
            addCriterion("follow_main_id <", value, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdLessThanOrEqualTo(Integer value) {
            addCriterion("follow_main_id <=", value, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdIn(List<Integer> values) {
            addCriterion("follow_main_id in", values, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdNotIn(List<Integer> values) {
            addCriterion("follow_main_id not in", values, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdBetween(Integer value1, Integer value2) {
            addCriterion("follow_main_id between", value1, value2, "followMainId");
            return (Criteria) this;
        }

        public Criteria andFollowMainIdNotBetween(Integer value1, Integer value2) {
            addCriterion("follow_main_id not between", value1, value2, "followMainId");
            return (Criteria) this;
        }

        public Criteria andSlotLengthIsNull() {
            addCriterion("slot_length is null");
            return (Criteria) this;
        }

        public Criteria andSlotLengthIsNotNull() {
            addCriterion("slot_length is not null");
            return (Criteria) this;
        }

        public Criteria andSlotLengthEqualTo(Integer value) {
            addCriterion("slot_length =", value, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthNotEqualTo(Integer value) {
            addCriterion("slot_length <>", value, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthGreaterThan(Integer value) {
            addCriterion("slot_length >", value, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthGreaterThanOrEqualTo(Integer value) {
            addCriterion("slot_length >=", value, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthLessThan(Integer value) {
            addCriterion("slot_length <", value, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthLessThanOrEqualTo(Integer value) {
            addCriterion("slot_length <=", value, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthIn(List<Integer> values) {
            addCriterion("slot_length in", values, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthNotIn(List<Integer> values) {
            addCriterion("slot_length not in", values, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthBetween(Integer value1, Integer value2) {
            addCriterion("slot_length between", value1, value2, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotLengthNotBetween(Integer value1, Integer value2) {
            addCriterion("slot_length not between", value1, value2, "slotLength");
            return (Criteria) this;
        }

        public Criteria andSlotNumberIsNull() {
            addCriterion("slot_number is null");
            return (Criteria) this;
        }

        public Criteria andSlotNumberIsNotNull() {
            addCriterion("slot_number is not null");
            return (Criteria) this;
        }

        public Criteria andSlotNumberEqualTo(Integer value) {
            addCriterion("slot_number =", value, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberNotEqualTo(Integer value) {
            addCriterion("slot_number <>", value, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberGreaterThan(Integer value) {
            addCriterion("slot_number >", value, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("slot_number >=", value, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberLessThan(Integer value) {
            addCriterion("slot_number <", value, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberLessThanOrEqualTo(Integer value) {
            addCriterion("slot_number <=", value, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberIn(List<Integer> values) {
            addCriterion("slot_number in", values, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberNotIn(List<Integer> values) {
            addCriterion("slot_number not in", values, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberBetween(Integer value1, Integer value2) {
            addCriterion("slot_number between", value1, value2, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotNumberNotBetween(Integer value1, Integer value2) {
            addCriterion("slot_number not between", value1, value2, "slotNumber");
            return (Criteria) this;
        }

        public Criteria andSlotReserveIsNull() {
            addCriterion("slot_reserve is null");
            return (Criteria) this;
        }

        public Criteria andSlotReserveIsNotNull() {
            addCriterion("slot_reserve is not null");
            return (Criteria) this;
        }

        public Criteria andSlotReserveEqualTo(Integer value) {
            addCriterion("slot_reserve =", value, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveNotEqualTo(Integer value) {
            addCriterion("slot_reserve <>", value, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveGreaterThan(Integer value) {
            addCriterion("slot_reserve >", value, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveGreaterThanOrEqualTo(Integer value) {
            addCriterion("slot_reserve >=", value, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveLessThan(Integer value) {
            addCriterion("slot_reserve <", value, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveLessThanOrEqualTo(Integer value) {
            addCriterion("slot_reserve <=", value, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveIn(List<Integer> values) {
            addCriterion("slot_reserve in", values, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveNotIn(List<Integer> values) {
            addCriterion("slot_reserve not in", values, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveBetween(Integer value1, Integer value2) {
            addCriterion("slot_reserve between", value1, value2, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andSlotReserveNotBetween(Integer value1, Integer value2) {
            addCriterion("slot_reserve not between", value1, value2, "slotReserve");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxIsNull() {
            addCriterion("antenna_delay_tx is null");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxIsNotNull() {
            addCriterion("antenna_delay_tx is not null");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxEqualTo(Integer value) {
            addCriterion("antenna_delay_tx =", value, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxNotEqualTo(Integer value) {
            addCriterion("antenna_delay_tx <>", value, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxGreaterThan(Integer value) {
            addCriterion("antenna_delay_tx >", value, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxGreaterThanOrEqualTo(Integer value) {
            addCriterion("antenna_delay_tx >=", value, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxLessThan(Integer value) {
            addCriterion("antenna_delay_tx <", value, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxLessThanOrEqualTo(Integer value) {
            addCriterion("antenna_delay_tx <=", value, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxIn(List<Integer> values) {
            addCriterion("antenna_delay_tx in", values, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxNotIn(List<Integer> values) {
            addCriterion("antenna_delay_tx not in", values, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxBetween(Integer value1, Integer value2) {
            addCriterion("antenna_delay_tx between", value1, value2, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayTxNotBetween(Integer value1, Integer value2) {
            addCriterion("antenna_delay_tx not between", value1, value2, "antennaDelayTx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxIsNull() {
            addCriterion("antenna_delay_rx is null");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxIsNotNull() {
            addCriterion("antenna_delay_rx is not null");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxEqualTo(Integer value) {
            addCriterion("antenna_delay_rx =", value, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxNotEqualTo(Integer value) {
            addCriterion("antenna_delay_rx <>", value, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxGreaterThan(Integer value) {
            addCriterion("antenna_delay_rx >", value, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxGreaterThanOrEqualTo(Integer value) {
            addCriterion("antenna_delay_rx >=", value, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxLessThan(Integer value) {
            addCriterion("antenna_delay_rx <", value, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxLessThanOrEqualTo(Integer value) {
            addCriterion("antenna_delay_rx <=", value, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxIn(List<Integer> values) {
            addCriterion("antenna_delay_rx in", values, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxNotIn(List<Integer> values) {
            addCriterion("antenna_delay_rx not in", values, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxBetween(Integer value1, Integer value2) {
            addCriterion("antenna_delay_rx between", value1, value2, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andAntennaDelayRxNotBetween(Integer value1, Integer value2) {
            addCriterion("antenna_delay_rx not between", value1, value2, "antennaDelayRx");
            return (Criteria) this;
        }

        public Criteria andChannelIsNull() {
            addCriterion("channel is null");
            return (Criteria) this;
        }

        public Criteria andChannelIsNotNull() {
            addCriterion("channel is not null");
            return (Criteria) this;
        }

        public Criteria andChannelEqualTo(Integer value) {
            addCriterion("channel =", value, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelNotEqualTo(Integer value) {
            addCriterion("channel <>", value, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelGreaterThan(Integer value) {
            addCriterion("channel >", value, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelGreaterThanOrEqualTo(Integer value) {
            addCriterion("channel >=", value, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelLessThan(Integer value) {
            addCriterion("channel <", value, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelLessThanOrEqualTo(Integer value) {
            addCriterion("channel <=", value, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelIn(List<Integer> values) {
            addCriterion("channel in", values, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelNotIn(List<Integer> values) {
            addCriterion("channel not in", values, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelBetween(Integer value1, Integer value2) {
            addCriterion("channel between", value1, value2, "channel");
            return (Criteria) this;
        }

        public Criteria andChannelNotBetween(Integer value1, Integer value2) {
            addCriterion("channel not between", value1, value2, "channel");
            return (Criteria) this;
        }

        public Criteria andLightVelocityIsNull() {
            addCriterion("light_velocity is null");
            return (Criteria) this;
        }

        public Criteria andLightVelocityIsNotNull() {
            addCriterion("light_velocity is not null");
            return (Criteria) this;
        }

        public Criteria andLightVelocityEqualTo(Integer value) {
            addCriterion("light_velocity =", value, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityNotEqualTo(Integer value) {
            addCriterion("light_velocity <>", value, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityGreaterThan(Integer value) {
            addCriterion("light_velocity >", value, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityGreaterThanOrEqualTo(Integer value) {
            addCriterion("light_velocity >=", value, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityLessThan(Integer value) {
            addCriterion("light_velocity <", value, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityLessThanOrEqualTo(Integer value) {
            addCriterion("light_velocity <=", value, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityIn(List<Integer> values) {
            addCriterion("light_velocity in", values, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityNotIn(List<Integer> values) {
            addCriterion("light_velocity not in", values, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityBetween(Integer value1, Integer value2) {
            addCriterion("light_velocity between", value1, value2, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andLightVelocityNotBetween(Integer value1, Integer value2) {
            addCriterion("light_velocity not between", value1, value2, "lightVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityIsNull() {
            addCriterion("uwb_velocity is null");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityIsNotNull() {
            addCriterion("uwb_velocity is not null");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityEqualTo(Integer value) {
            addCriterion("uwb_velocity =", value, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityNotEqualTo(Integer value) {
            addCriterion("uwb_velocity <>", value, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityGreaterThan(Integer value) {
            addCriterion("uwb_velocity >", value, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityGreaterThanOrEqualTo(Integer value) {
            addCriterion("uwb_velocity >=", value, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityLessThan(Integer value) {
            addCriterion("uwb_velocity <", value, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityLessThanOrEqualTo(Integer value) {
            addCriterion("uwb_velocity <=", value, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityIn(List<Integer> values) {
            addCriterion("uwb_velocity in", values, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityNotIn(List<Integer> values) {
            addCriterion("uwb_velocity not in", values, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityBetween(Integer value1, Integer value2) {
            addCriterion("uwb_velocity between", value1, value2, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbVelocityNotBetween(Integer value1, Integer value2) {
            addCriterion("uwb_velocity not between", value1, value2, "uwbVelocity");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyIsNull() {
            addCriterion("uwb_peak_frequency is null");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyIsNotNull() {
            addCriterion("uwb_peak_frequency is not null");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyEqualTo(Integer value) {
            addCriterion("uwb_peak_frequency =", value, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyNotEqualTo(Integer value) {
            addCriterion("uwb_peak_frequency <>", value, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyGreaterThan(Integer value) {
            addCriterion("uwb_peak_frequency >", value, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyGreaterThanOrEqualTo(Integer value) {
            addCriterion("uwb_peak_frequency >=", value, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyLessThan(Integer value) {
            addCriterion("uwb_peak_frequency <", value, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyLessThanOrEqualTo(Integer value) {
            addCriterion("uwb_peak_frequency <=", value, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyIn(List<Integer> values) {
            addCriterion("uwb_peak_frequency in", values, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyNotIn(List<Integer> values) {
            addCriterion("uwb_peak_frequency not in", values, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyBetween(Integer value1, Integer value2) {
            addCriterion("uwb_peak_frequency between", value1, value2, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andUwbPeakFrequencyNotBetween(Integer value1, Integer value2) {
            addCriterion("uwb_peak_frequency not between", value1, value2, "uwbPeakFrequency");
            return (Criteria) this;
        }

        public Criteria andPreambleIsNull() {
            addCriterion("preamble is null");
            return (Criteria) this;
        }

        public Criteria andPreambleIsNotNull() {
            addCriterion("preamble is not null");
            return (Criteria) this;
        }

        public Criteria andPreambleEqualTo(Integer value) {
            addCriterion("preamble =", value, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleNotEqualTo(Integer value) {
            addCriterion("preamble <>", value, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleGreaterThan(Integer value) {
            addCriterion("preamble >", value, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleGreaterThanOrEqualTo(Integer value) {
            addCriterion("preamble >=", value, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleLessThan(Integer value) {
            addCriterion("preamble <", value, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleLessThanOrEqualTo(Integer value) {
            addCriterion("preamble <=", value, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleIn(List<Integer> values) {
            addCriterion("preamble in", values, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleNotIn(List<Integer> values) {
            addCriterion("preamble not in", values, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleBetween(Integer value1, Integer value2) {
            addCriterion("preamble between", value1, value2, "preamble");
            return (Criteria) this;
        }

        public Criteria andPreambleNotBetween(Integer value1, Integer value2) {
            addCriterion("preamble not between", value1, value2, "preamble");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerIsNull() {
            addCriterion("transmission_power is null");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerIsNotNull() {
            addCriterion("transmission_power is not null");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerEqualTo(Integer value) {
            addCriterion("transmission_power =", value, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerNotEqualTo(Integer value) {
            addCriterion("transmission_power <>", value, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerGreaterThan(Integer value) {
            addCriterion("transmission_power >", value, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerGreaterThanOrEqualTo(Integer value) {
            addCriterion("transmission_power >=", value, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerLessThan(Integer value) {
            addCriterion("transmission_power <", value, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerLessThanOrEqualTo(Integer value) {
            addCriterion("transmission_power <=", value, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerIn(List<Integer> values) {
            addCriterion("transmission_power in", values, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerNotIn(List<Integer> values) {
            addCriterion("transmission_power not in", values, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerBetween(Integer value1, Integer value2) {
            addCriterion("transmission_power between", value1, value2, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andTransmissionPowerNotBetween(Integer value1, Integer value2) {
            addCriterion("transmission_power not between", value1, value2, "transmissionPower");
            return (Criteria) this;
        }

        public Criteria andLongitudeIsNull() {
            addCriterion("longitude is null");
            return (Criteria) this;
        }

        public Criteria andLongitudeIsNotNull() {
            addCriterion("longitude is not null");
            return (Criteria) this;
        }

        public Criteria andLongitudeEqualTo(Long value) {
            addCriterion("longitude =", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotEqualTo(Long value) {
            addCriterion("longitude <>", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeGreaterThan(Long value) {
            addCriterion("longitude >", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeGreaterThanOrEqualTo(Long value) {
            addCriterion("longitude >=", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLessThan(Long value) {
            addCriterion("longitude <", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLessThanOrEqualTo(Long value) {
            addCriterion("longitude <=", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeIn(List<Long> values) {
            addCriterion("longitude in", values, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotIn(List<Long> values) {
            addCriterion("longitude not in", values, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeBetween(Long value1, Long value2) {
            addCriterion("longitude between", value1, value2, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotBetween(Long value1, Long value2) {
            addCriterion("longitude not between", value1, value2, "longitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNull() {
            addCriterion("latitude is null");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNotNull() {
            addCriterion("latitude is not null");
            return (Criteria) this;
        }

        public Criteria andLatitudeEqualTo(Long value) {
            addCriterion("latitude =", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotEqualTo(Long value) {
            addCriterion("latitude <>", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThan(Long value) {
            addCriterion("latitude >", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThanOrEqualTo(Long value) {
            addCriterion("latitude >=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThan(Long value) {
            addCriterion("latitude <", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThanOrEqualTo(Long value) {
            addCriterion("latitude <=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeIn(List<Long> values) {
            addCriterion("latitude in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotIn(List<Long> values) {
            addCriterion("latitude not in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeBetween(Long value1, Long value2) {
            addCriterion("latitude between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotBetween(Long value1, Long value2) {
            addCriterion("latitude not between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andHeightIsNull() {
            addCriterion("height is null");
            return (Criteria) this;
        }

        public Criteria andHeightIsNotNull() {
            addCriterion("height is not null");
            return (Criteria) this;
        }

        public Criteria andHeightEqualTo(Long value) {
            addCriterion("height =", value, "height");
            return (Criteria) this;
        }

        public Criteria andHeightNotEqualTo(Long value) {
            addCriterion("height <>", value, "height");
            return (Criteria) this;
        }

        public Criteria andHeightGreaterThan(Long value) {
            addCriterion("height >", value, "height");
            return (Criteria) this;
        }

        public Criteria andHeightGreaterThanOrEqualTo(Long value) {
            addCriterion("height >=", value, "height");
            return (Criteria) this;
        }

        public Criteria andHeightLessThan(Long value) {
            addCriterion("height <", value, "height");
            return (Criteria) this;
        }

        public Criteria andHeightLessThanOrEqualTo(Long value) {
            addCriterion("height <=", value, "height");
            return (Criteria) this;
        }

        public Criteria andHeightIn(List<Long> values) {
            addCriterion("height in", values, "height");
            return (Criteria) this;
        }

        public Criteria andHeightNotIn(List<Long> values) {
            addCriterion("height not in", values, "height");
            return (Criteria) this;
        }

        public Criteria andHeightBetween(Long value1, Long value2) {
            addCriterion("height between", value1, value2, "height");
            return (Criteria) this;
        }

        public Criteria andHeightNotBetween(Long value1, Long value2) {
            addCriterion("height not between", value1, value2, "height");
            return (Criteria) this;
        }

        public Criteria andTofCompensationIsNull() {
            addCriterion("tof_compensation is null");
            return (Criteria) this;
        }

        public Criteria andTofCompensationIsNotNull() {
            addCriterion("tof_compensation is not null");
            return (Criteria) this;
        }

        public Criteria andTofCompensationEqualTo(Integer value) {
            addCriterion("tof_compensation =", value, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationNotEqualTo(Integer value) {
            addCriterion("tof_compensation <>", value, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationGreaterThan(Integer value) {
            addCriterion("tof_compensation >", value, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationGreaterThanOrEqualTo(Integer value) {
            addCriterion("tof_compensation >=", value, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationLessThan(Integer value) {
            addCriterion("tof_compensation <", value, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationLessThanOrEqualTo(Integer value) {
            addCriterion("tof_compensation <=", value, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationIn(List<Integer> values) {
            addCriterion("tof_compensation in", values, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationNotIn(List<Integer> values) {
            addCriterion("tof_compensation not in", values, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationBetween(Integer value1, Integer value2) {
            addCriterion("tof_compensation between", value1, value2, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andTofCompensationNotBetween(Integer value1, Integer value2) {
            addCriterion("tof_compensation not between", value1, value2, "tofCompensation");
            return (Criteria) this;
        }

        public Criteria andLanIdIsNull() {
            addCriterion("lan_id is null");
            return (Criteria) this;
        }

        public Criteria andLanIdIsNotNull() {
            addCriterion("lan_id is not null");
            return (Criteria) this;
        }

        public Criteria andLanIdEqualTo(Integer value) {
            addCriterion("lan_id =", value, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdNotEqualTo(Integer value) {
            addCriterion("lan_id <>", value, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdGreaterThan(Integer value) {
            addCriterion("lan_id >", value, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("lan_id >=", value, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdLessThan(Integer value) {
            addCriterion("lan_id <", value, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdLessThanOrEqualTo(Integer value) {
            addCriterion("lan_id <=", value, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdIn(List<Integer> values) {
            addCriterion("lan_id in", values, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdNotIn(List<Integer> values) {
            addCriterion("lan_id not in", values, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdBetween(Integer value1, Integer value2) {
            addCriterion("lan_id between", value1, value2, "lanId");
            return (Criteria) this;
        }

        public Criteria andLanIdNotBetween(Integer value1, Integer value2) {
            addCriterion("lan_id not between", value1, value2, "lanId");
            return (Criteria) this;
        }

        public Criteria andDelayTxIsNull() {
            addCriterion("delay_tx is null");
            return (Criteria) this;
        }

        public Criteria andDelayTxIsNotNull() {
            addCriterion("delay_tx is not null");
            return (Criteria) this;
        }

        public Criteria andDelayTxEqualTo(Integer value) {
            addCriterion("delay_tx =", value, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxNotEqualTo(Integer value) {
            addCriterion("delay_tx <>", value, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxGreaterThan(Integer value) {
            addCriterion("delay_tx >", value, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxGreaterThanOrEqualTo(Integer value) {
            addCriterion("delay_tx >=", value, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxLessThan(Integer value) {
            addCriterion("delay_tx <", value, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxLessThanOrEqualTo(Integer value) {
            addCriterion("delay_tx <=", value, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxIn(List<Integer> values) {
            addCriterion("delay_tx in", values, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxNotIn(List<Integer> values) {
            addCriterion("delay_tx not in", values, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxBetween(Integer value1, Integer value2) {
            addCriterion("delay_tx between", value1, value2, "delayTx");
            return (Criteria) this;
        }

        public Criteria andDelayTxNotBetween(Integer value1, Integer value2) {
            addCriterion("delay_tx not between", value1, value2, "delayTx");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitIsNull() {
            addCriterion("min_time_unit is null");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitIsNotNull() {
            addCriterion("min_time_unit is not null");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitEqualTo(Integer value) {
            addCriterion("min_time_unit =", value, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitNotEqualTo(Integer value) {
            addCriterion("min_time_unit <>", value, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitGreaterThan(Integer value) {
            addCriterion("min_time_unit >", value, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitGreaterThanOrEqualTo(Integer value) {
            addCriterion("min_time_unit >=", value, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitLessThan(Integer value) {
            addCriterion("min_time_unit <", value, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitLessThanOrEqualTo(Integer value) {
            addCriterion("min_time_unit <=", value, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitIn(List<Integer> values) {
            addCriterion("min_time_unit in", values, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitNotIn(List<Integer> values) {
            addCriterion("min_time_unit not in", values, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitBetween(Integer value1, Integer value2) {
            addCriterion("min_time_unit between", value1, value2, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andMinTimeUnitNotBetween(Integer value1, Integer value2) {
            addCriterion("min_time_unit not between", value1, value2, "minTimeUnit");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIsNull() {
            addCriterion("modify_time is null");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIsNotNull() {
            addCriterion("modify_time is not null");
            return (Criteria) this;
        }

        public Criteria andModifyTimeEqualTo(Date value) {
            addCriterion("modify_time =", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotEqualTo(Date value) {
            addCriterion("modify_time <>", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeGreaterThan(Date value) {
            addCriterion("modify_time >", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("modify_time >=", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeLessThan(Date value) {
            addCriterion("modify_time <", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeLessThanOrEqualTo(Date value) {
            addCriterion("modify_time <=", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIn(List<Date> values) {
            addCriterion("modify_time in", values, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotIn(List<Date> values) {
            addCriterion("modify_time not in", values, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeBetween(Date value1, Date value2) {
            addCriterion("modify_time between", value1, value2, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotBetween(Date value1, Date value2) {
            addCriterion("modify_time not between", value1, value2, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyFlagIsNull() {
            addCriterion("modify_flag is null");
            return (Criteria) this;
        }

        public Criteria andModifyFlagIsNotNull() {
            addCriterion("modify_flag is not null");
            return (Criteria) this;
        }

        public Criteria andModifyFlagEqualTo(Integer value) {
            addCriterion("modify_flag =", value, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagNotEqualTo(Integer value) {
            addCriterion("modify_flag <>", value, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagGreaterThan(Integer value) {
            addCriterion("modify_flag >", value, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagGreaterThanOrEqualTo(Integer value) {
            addCriterion("modify_flag >=", value, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagLessThan(Integer value) {
            addCriterion("modify_flag <", value, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagLessThanOrEqualTo(Integer value) {
            addCriterion("modify_flag <=", value, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagIn(List<Integer> values) {
            addCriterion("modify_flag in", values, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagNotIn(List<Integer> values) {
            addCriterion("modify_flag not in", values, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagBetween(Integer value1, Integer value2) {
            addCriterion("modify_flag between", value1, value2, "modifyFlag");
            return (Criteria) this;
        }

        public Criteria andModifyFlagNotBetween(Integer value1, Integer value2) {
            addCriterion("modify_flag not between", value1, value2, "modifyFlag");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}