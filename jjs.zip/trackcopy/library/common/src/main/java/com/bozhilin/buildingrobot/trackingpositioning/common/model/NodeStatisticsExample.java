package com.bozhilin.buildingrobot.trackingpositioning.common.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class NodeStatisticsExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public NodeStatisticsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andServerIdIsNull() {
            addCriterion("server_id is null");
            return (Criteria) this;
        }

        public Criteria andServerIdIsNotNull() {
            addCriterion("server_id is not null");
            return (Criteria) this;
        }

        public Criteria andServerIdEqualTo(Integer value) {
            addCriterion("server_id =", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdNotEqualTo(Integer value) {
            addCriterion("server_id <>", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdGreaterThan(Integer value) {
            addCriterion("server_id >", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("server_id >=", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdLessThan(Integer value) {
            addCriterion("server_id <", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdLessThanOrEqualTo(Integer value) {
            addCriterion("server_id <=", value, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdIn(List<Integer> values) {
            addCriterion("server_id in", values, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdNotIn(List<Integer> values) {
            addCriterion("server_id not in", values, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdBetween(Integer value1, Integer value2) {
            addCriterion("server_id between", value1, value2, "serverId");
            return (Criteria) this;
        }

        public Criteria andServerIdNotBetween(Integer value1, Integer value2) {
            addCriterion("server_id not between", value1, value2, "serverId");
            return (Criteria) this;
        }

        public Criteria andNodeIdIsNull() {
            addCriterion("node_id is null");
            return (Criteria) this;
        }

        public Criteria andNodeIdIsNotNull() {
            addCriterion("node_id is not null");
            return (Criteria) this;
        }

        public Criteria andNodeIdEqualTo(Integer value) {
            addCriterion("node_id =", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotEqualTo(Integer value) {
            addCriterion("node_id <>", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdGreaterThan(Integer value) {
            addCriterion("node_id >", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("node_id >=", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdLessThan(Integer value) {
            addCriterion("node_id <", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdLessThanOrEqualTo(Integer value) {
            addCriterion("node_id <=", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdIn(List<Integer> values) {
            addCriterion("node_id in", values, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotIn(List<Integer> values) {
            addCriterion("node_id not in", values, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdBetween(Integer value1, Integer value2) {
            addCriterion("node_id between", value1, value2, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotBetween(Integer value1, Integer value2) {
            addCriterion("node_id not between", value1, value2, "nodeId");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("create_date is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("create_date is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterionForJDBCDate("create_date =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterionForJDBCDate("create_date <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterionForJDBCDate("create_date >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("create_date >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterionForJDBCDate("create_date <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("create_date <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterionForJDBCDate("create_date in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterionForJDBCDate("create_date not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("create_date between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("create_date not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIsNull() {
            addCriterion("modify_time is null");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIsNotNull() {
            addCriterion("modify_time is not null");
            return (Criteria) this;
        }

        public Criteria andModifyTimeEqualTo(Date value) {
            addCriterion("modify_time =", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotEqualTo(Date value) {
            addCriterion("modify_time <>", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeGreaterThan(Date value) {
            addCriterion("modify_time >", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("modify_time >=", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeLessThan(Date value) {
            addCriterion("modify_time <", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeLessThanOrEqualTo(Date value) {
            addCriterion("modify_time <=", value, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeIn(List<Date> values) {
            addCriterion("modify_time in", values, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotIn(List<Date> values) {
            addCriterion("modify_time not in", values, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeBetween(Date value1, Date value2) {
            addCriterion("modify_time between", value1, value2, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andModifyTimeNotBetween(Date value1, Date value2) {
            addCriterion("modify_time not between", value1, value2, "modifyTime");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficIsNull() {
            addCriterion("upstream_traffic is null");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficIsNotNull() {
            addCriterion("upstream_traffic is not null");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficEqualTo(String value) {
            addCriterion("upstream_traffic =", value, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficNotEqualTo(String value) {
            addCriterion("upstream_traffic <>", value, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficGreaterThan(String value) {
            addCriterion("upstream_traffic >", value, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficGreaterThanOrEqualTo(String value) {
            addCriterion("upstream_traffic >=", value, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficLessThan(String value) {
            addCriterion("upstream_traffic <", value, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficLessThanOrEqualTo(String value) {
            addCriterion("upstream_traffic <=", value, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficLike(String value) {
            addCriterion("upstream_traffic like", value, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficNotLike(String value) {
            addCriterion("upstream_traffic not like", value, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficIn(List<String> values) {
            addCriterion("upstream_traffic in", values, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficNotIn(List<String> values) {
            addCriterion("upstream_traffic not in", values, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficBetween(String value1, String value2) {
            addCriterion("upstream_traffic between", value1, value2, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andUpstreamTrafficNotBetween(String value1, String value2) {
            addCriterion("upstream_traffic not between", value1, value2, "upstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficIsNull() {
            addCriterion("downstream_traffic is null");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficIsNotNull() {
            addCriterion("downstream_traffic is not null");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficEqualTo(String value) {
            addCriterion("downstream_traffic =", value, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficNotEqualTo(String value) {
            addCriterion("downstream_traffic <>", value, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficGreaterThan(String value) {
            addCriterion("downstream_traffic >", value, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficGreaterThanOrEqualTo(String value) {
            addCriterion("downstream_traffic >=", value, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficLessThan(String value) {
            addCriterion("downstream_traffic <", value, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficLessThanOrEqualTo(String value) {
            addCriterion("downstream_traffic <=", value, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficLike(String value) {
            addCriterion("downstream_traffic like", value, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficNotLike(String value) {
            addCriterion("downstream_traffic not like", value, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficIn(List<String> values) {
            addCriterion("downstream_traffic in", values, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficNotIn(List<String> values) {
            addCriterion("downstream_traffic not in", values, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficBetween(String value1, String value2) {
            addCriterion("downstream_traffic between", value1, value2, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andDownstreamTrafficNotBetween(String value1, String value2) {
            addCriterion("downstream_traffic not between", value1, value2, "downstreamTraffic");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityIsNull() {
            addCriterion("class_a_quantity is null");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityIsNotNull() {
            addCriterion("class_a_quantity is not null");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityEqualTo(String value) {
            addCriterion("class_a_quantity =", value, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityNotEqualTo(String value) {
            addCriterion("class_a_quantity <>", value, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityGreaterThan(String value) {
            addCriterion("class_a_quantity >", value, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityGreaterThanOrEqualTo(String value) {
            addCriterion("class_a_quantity >=", value, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityLessThan(String value) {
            addCriterion("class_a_quantity <", value, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityLessThanOrEqualTo(String value) {
            addCriterion("class_a_quantity <=", value, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityLike(String value) {
            addCriterion("class_a_quantity like", value, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityNotLike(String value) {
            addCriterion("class_a_quantity not like", value, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityIn(List<String> values) {
            addCriterion("class_a_quantity in", values, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityNotIn(List<String> values) {
            addCriterion("class_a_quantity not in", values, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityBetween(String value1, String value2) {
            addCriterion("class_a_quantity between", value1, value2, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassAQuantityNotBetween(String value1, String value2) {
            addCriterion("class_a_quantity not between", value1, value2, "classAQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityIsNull() {
            addCriterion("class_b_quantity is null");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityIsNotNull() {
            addCriterion("class_b_quantity is not null");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityEqualTo(String value) {
            addCriterion("class_b_quantity =", value, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityNotEqualTo(String value) {
            addCriterion("class_b_quantity <>", value, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityGreaterThan(String value) {
            addCriterion("class_b_quantity >", value, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityGreaterThanOrEqualTo(String value) {
            addCriterion("class_b_quantity >=", value, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityLessThan(String value) {
            addCriterion("class_b_quantity <", value, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityLessThanOrEqualTo(String value) {
            addCriterion("class_b_quantity <=", value, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityLike(String value) {
            addCriterion("class_b_quantity like", value, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityNotLike(String value) {
            addCriterion("class_b_quantity not like", value, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityIn(List<String> values) {
            addCriterion("class_b_quantity in", values, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityNotIn(List<String> values) {
            addCriterion("class_b_quantity not in", values, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityBetween(String value1, String value2) {
            addCriterion("class_b_quantity between", value1, value2, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassBQuantityNotBetween(String value1, String value2) {
            addCriterion("class_b_quantity not between", value1, value2, "classBQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityIsNull() {
            addCriterion("class_c_quantity is null");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityIsNotNull() {
            addCriterion("class_c_quantity is not null");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityEqualTo(String value) {
            addCriterion("class_c_quantity =", value, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityNotEqualTo(String value) {
            addCriterion("class_c_quantity <>", value, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityGreaterThan(String value) {
            addCriterion("class_c_quantity >", value, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityGreaterThanOrEqualTo(String value) {
            addCriterion("class_c_quantity >=", value, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityLessThan(String value) {
            addCriterion("class_c_quantity <", value, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityLessThanOrEqualTo(String value) {
            addCriterion("class_c_quantity <=", value, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityLike(String value) {
            addCriterion("class_c_quantity like", value, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityNotLike(String value) {
            addCriterion("class_c_quantity not like", value, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityIn(List<String> values) {
            addCriterion("class_c_quantity in", values, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityNotIn(List<String> values) {
            addCriterion("class_c_quantity not in", values, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityBetween(String value1, String value2) {
            addCriterion("class_c_quantity between", value1, value2, "classCQuantity");
            return (Criteria) this;
        }

        public Criteria andClassCQuantityNotBetween(String value1, String value2) {
            addCriterion("class_c_quantity not between", value1, value2, "classCQuantity");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}