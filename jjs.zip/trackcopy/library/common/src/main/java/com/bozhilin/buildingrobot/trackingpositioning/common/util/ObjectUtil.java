package com.bozhilin.buildingrobot.trackingpositioning.common.util;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

/**
 * 基本对象工具类
 * Created by TanJY on 2019/8/15.
 */
public class ObjectUtil {

	public static String object2String(Object obj) {
		if(obj == null || "".equals(obj)) {
			return "";
		}
		return obj.toString();
	}
	
	public static Object setObj(Object obj) {
		if(obj == null || "".equals(obj)) {
			return "";
		}
		return obj;
	}
	
	public static boolean isNull(Object obj) {
		if(obj==null) {
			return true;
		}
		return false;
	}
	
	public static boolean isNoNull(Object obj) {
		return !isNull(obj);
	}

	public static boolean isEmpty(Object obj) {
		if (obj == null) {
			return true;
		} else if (obj instanceof CharSequence) {
			return ((CharSequence)obj).length() == 0;
		} else if (obj.getClass().isArray()) {
			return Array.getLength(obj) == 0;
		} else if (obj instanceof Collection) {
			return ((Collection)obj).isEmpty();
		} else {
			return obj instanceof Map ? ((Map)obj).isEmpty() : false;
		}
	}

	public static String nullSafeToString(Object obj) {
		if (obj == null) {
			return "null";
		} else if (obj instanceof String) {
			return (String)obj;
		} else if (obj instanceof Object[]) {
			return nullSafeToString((Object[])((Object[])obj));
		} else if (obj instanceof boolean[]) {
			return nullSafeToString((boolean[])((boolean[])obj));
		} else if (obj instanceof byte[]) {
			return nullSafeToString((byte[])((byte[])obj));
		} else if (obj instanceof char[]) {
			return nullSafeToString((char[])((char[])obj));
		} else if (obj instanceof double[]) {
			return nullSafeToString((double[])((double[])obj));
		} else if (obj instanceof float[]) {
			return nullSafeToString((float[])((float[])obj));
		} else if (obj instanceof int[]) {
			return nullSafeToString((int[])((int[])obj));
		} else if (obj instanceof long[]) {
			return nullSafeToString((long[])((long[])obj));
		} else if (obj instanceof short[]) {
			return nullSafeToString((short[])((short[])obj));
		} else {
			String str = obj.toString();
			return str != null ? str : "";
		}
	}
}
