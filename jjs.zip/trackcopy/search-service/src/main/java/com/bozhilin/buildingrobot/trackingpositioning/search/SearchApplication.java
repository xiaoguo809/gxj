package com.bozhilin.buildingrobot.trackingpositioning.search;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.bozhilin.buildingrobot.trackingpositioning.search",
                                         "com.bozhilin.buildingrobot.trackingpositioning.common"})
public class SearchApplication {
    private static final Logger LOGGER = LoggerFactory.getLogger(SearchApplication.class);

    public static void main(String[] args) {
        LOGGER.trace("This level is TRACE.");
        SpringApplication.run(SearchApplication.class, args);
    }

}
