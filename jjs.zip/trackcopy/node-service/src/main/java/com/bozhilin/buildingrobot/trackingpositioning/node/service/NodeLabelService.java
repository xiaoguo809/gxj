package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeLabelDto;
import org.springframework.transaction.annotation.Transactional;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
public interface NodeLabelService {
    @Transactional
    int create(NodeLabelDto nodeLabelDto);

    @Transactional
    int update(Integer serverId, Integer nodeId, NodeLabelDto nodeLabelDto);

    @Transactional
    int delete(Integer serverId, Integer nodeId);

    NodeLabelDto get(Integer serverId, Integer nodeId);
}
