package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeCategoryMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeDefineMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeTreeMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.*;
import com.bozhilin.buildingrobot.trackingpositioning.node.constant.Constants;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.NodeTreeRedisDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeTreeDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.NodeTreeHierarchy;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.protobuf.NodeTreeHierarchyMessage;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.protobuf.NodeTreeMessage;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeTreeService;
import com.bozhilin.buildingrobot.trackingpositioning.node.util.NodeUtil;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * NodeTreeService实现类
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeTreeServiceImpl implements NodeTreeService {

    @Autowired
    private NodeTreeMapper nodeTreeMapper;

    @Autowired
    private NodeDefineMapper nodeDefineMapper;

    @Autowired
    private NodeCategoryMapper nodeCategoryMapper;

    @Autowired
    private NodeTreeRedisDao nodeTreeRedisDao;

    @Override
    public List<NodeTree> listAll(Integer serverId) {
        NodeTreeExample example = new NodeTreeExample();
        example.createCriteria().andServerIdEqualTo(serverId);
        return nodeTreeMapper.selectByExample(example);
    }

    @Override
    public int create(NodeTree nodeTree) {
        return nodeTreeMapper.insertSelective(nodeTree);
    }

    @Override
    public int update(Integer serverId, Integer nodeId, NodeTree nodeTree) {
        nodeTree.setServerId(serverId);
        nodeTree.setNodeId(nodeId);
        return nodeTreeMapper.updateByPrimaryKeySelective(nodeTree);
    }

    @Override
    public int delete(NodeTreeKey nodeTreeKey) {
        return nodeTreeMapper.deleteByPrimaryKey(nodeTreeKey);
    }

    @Override
    public List<NodeTree> list(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        nodeTreeMapper.selectByExample(new NodeTreeExample());
        return nodeTreeMapper.selectByExample(new NodeTreeExample());
    }

    @Override
    public NodeTree get(NodeTreeKey nodeTreeKey) {
        return nodeTreeMapper.selectByPrimaryKey(nodeTreeKey);
    }

    @Override
    public NodeTreeDto getChildrens(Integer serverId, Integer nodeId) throws Exception {
        if (nodeId == null) {
            nodeId = serverId;
        }

        //从Redis获取节点树的实时拓扑结构
        NodeTreeDto result = new NodeTreeDto();
        NodeTreeMessage nodeTreeMessage = nodeTreeRedisDao.getNodeTree(serverId);
        if (nodeTreeMessage == null) {
            return  result;
        }

        //生成节点树
        List<NodeTreeHierarchyMessage> nodeTreeMessageList = new ArrayList<>(nodeTreeMessage.getEntryList());
        List<NodeTreeHierarchy> rootNodeTreeList = result.getNodeList();
        makeNodeTree(serverId, nodeId, nodeTreeMessageList, rootNodeTreeList);

        //深层次地进行排序
        deepSort(rootNodeTreeList);

        //获取节点配置信息
        getNodeConfigs(serverId, nodeTreeMessageList, result.getNodeDefineList(), result.getNodeCategoryList());

        return result;
    }

    private void makeNodeTree(Integer serverId, Integer nodeId, List<NodeTreeHierarchyMessage> hierarchyList,
                              List<NodeTreeHierarchy> rootNodeTreeList) {
        //节点树列表
        //如果节点id为空的话，从最顶层节点开始获取
        Map<Integer, NodeTreeHierarchy> nodeTreeHierarchyMap = new HashMap<>();
        for (NodeTreeHierarchyMessage entry : hierarchyList) {
            NodeTreeHierarchy nodeTreeHierarchy = new NodeTreeHierarchy();
            BeanUtils.copyProperties(entry, nodeTreeHierarchy);
            nodeTreeHierarchyMap.put(entry.getNodeId(), nodeTreeHierarchy);
        }

        //如果没有服务器这个节点，则构造一个服务器根节点
        if (serverId.equals(nodeId) && !nodeTreeHierarchyMap.containsKey(nodeId)) {
            NodeTreeHierarchyMessage.Builder builder = NodeTreeHierarchyMessage.newBuilder();
            builder.setServerId(serverId).setNodeId(nodeId).setParentNodeId(-1).setState(Constants.VALID_STATE);
            NodeTreeHierarchyMessage nodeServer = builder.build();
            hierarchyList.add(nodeServer);

            NodeTreeHierarchy nodeTreeHierarchy = new NodeTreeHierarchy();
            BeanUtils.copyProperties(nodeServer, nodeTreeHierarchy);
            nodeTreeHierarchyMap.put(nodeServer.getNodeId(), nodeTreeHierarchy);
        }

        //NodeTreeExample example = new NodeTreeExample();
        //example.createCriteria().andServerIdEqualTo(serverId).andStateEqualTo(1);
        //List<NodeTree> nodeTreeList = nodeTreeMapper.selectByExample(example);
        for (NodeTreeHierarchyMessage entry : hierarchyList) {
            NodeTreeHierarchy nodeTreeHierarchy= nodeTreeHierarchyMap.get(entry.getNodeId());
            NodeTreeHierarchy nodeTreeHierarchyParent= nodeTreeHierarchyMap.get(entry.getParentNodeId());
            if (nodeTreeHierarchyParent == null) {
                rootNodeTreeList.add(nodeTreeHierarchy);
            } else {
                if (nodeTreeHierarchyParent.getChildNodeList() == null) {
                    nodeTreeHierarchyParent.setChildNodeList(new ArrayList<>());
                }
                nodeTreeHierarchyParent.getChildNodeList().add(nodeTreeHierarchy);
            }
        }
    }

    private void deepSort(List<NodeTreeHierarchy> nodeTreeList) {
        if (nodeTreeList != null) {
            nodeTreeList.sort((o1, o2) -> Long.compare(o1.getNodeId(), o2.getNodeId()));
            nodeTreeList.forEach(one -> deepSort(one.getChildNodeList()));
        }
    }

    private void getNodeConfigs(Integer serverId, List<NodeTreeHierarchyMessage> hierarchyList,
                                List<NodeDefine> nodeDefineList, List<NodeCategory> nodeCategoryList) {
        //获取节点定义和分类信息
        Map<Integer, NodeDefine> nodeDefineMap = new HashMap<>();
        Map<Integer, NodeCategory> nodeCategoryMap = new HashMap<>();
        for (NodeTreeHierarchyMessage entry : hierarchyList) {
            //获取节点定义列表
            Integer nodeId = entry.getNodeId();
            NodeDefine nodeDefine = nodeDefineMap.get(nodeId);
            if (nodeDefine == null) {
                nodeDefine = nodeDefineMapper.selectByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));
                if (nodeDefine == null) {
                    nodeDefine = new NodeDefine();
                    nodeDefine.setServerId(entry.getServerId());
                    nodeDefine.setId(nodeId);
                    nodeDefine.setState(Constants.VALID_STATE);
                    nodeDefine.setName("");
                    nodeDefine.setCategoryId(0);
                }

                nodeDefineMap.put(nodeId, nodeDefine);
                nodeDefineList.add(nodeDefine);
            }

            //获取节点分类列表
            if (!nodeCategoryMap.containsKey(nodeId)) {
                NodeCategory nodeCategory = nodeCategoryMapper.selectByPrimaryKey(nodeDefine.getCategoryId());
                if (nodeCategory == null) {
                    nodeCategory = new NodeCategory();
                }
                nodeCategoryMap.put(nodeId, nodeCategory);
                nodeCategoryList.add(nodeCategory);
            }
        }
    }
}
