package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeSynchronizerDto;
import org.springframework.transaction.annotation.Transactional;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
public interface NodeSynchronizerService {
    @Transactional
    int create(NodeSynchronizerDto nodeSynchronizerDto);

    @Transactional
    int update(Integer serverId, Integer nodeId, NodeSynchronizerDto nodeSynchronizerDto);

    @Transactional
    int delete(Integer serverId, Integer nodeId);

    NodeSynchronizerDto get(Integer serverId, Integer nodeId);
}
