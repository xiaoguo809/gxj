package com.bozhilin.buildingrobot.trackingpositioning.node.model;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;

@Api(tags = "IconEnum")
@Getter
public enum IconEnum {

    ONE_M("1M", 1048576, -1),
    JPG_FILE("JPG", 0, 1),
    PNG_FILE("PNG", 0, 2);

    IconEnum(String name, int fileSize, int fileType) {
        this.name = name;
        this.size = fileSize;
        this.fileType = fileType;
    }

    @ApiModelProperty(value = "名称")
    private String name;
    @ApiModelProperty(value = "文件大小")
    private int size;
    @ApiModelProperty(value = "文件的类型编码")
    private int fileType;

    public static IconEnum getIconByType(String type) {
        for (IconEnum e : IconEnum.values()) {
            if (type.equalsIgnoreCase(e.getName())) {
                return e;
            }
        }
        return null;
    }

    public static IconEnum getIconByFileType(int fileType) {
        for (IconEnum e : IconEnum.values()) {
            if (fileType == e.getFileType()) {
                return e;
            }
        }
        return null;
    }
}
