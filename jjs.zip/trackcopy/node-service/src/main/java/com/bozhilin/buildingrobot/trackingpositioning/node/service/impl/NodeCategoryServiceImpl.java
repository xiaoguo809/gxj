package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeCategoryMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCategory;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCategoryExample;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeCategoryService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * NodeCategoryService实现类
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeCategoryServiceImpl implements NodeCategoryService {

    @Autowired
    private NodeCategoryMapper nodeCategoryMapper;

    @Override
    public List<NodeCategory> listAll() {
        return nodeCategoryMapper.selectByExample(new NodeCategoryExample());
    }

    @Override
    public int create(NodeCategory nodeCategory) {
        return nodeCategoryMapper.insertSelective(nodeCategory);
    }

    @Override
    public int update(Integer id, NodeCategory nodeCategory) {
        if ("".equals(nodeCategory.getId())) {
            nodeCategory.setId(id);
        }

        if (id.equals(nodeCategory.getId())) {
            return nodeCategoryMapper.updateByPrimaryKeySelective(nodeCategory);
        } else {
            delete(id);
            return create(nodeCategory);
        }
    }

    @Override
    public int delete(Integer id) {
        return nodeCategoryMapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<NodeCategory> list(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        nodeCategoryMapper.selectByExample(new NodeCategoryExample());
        return nodeCategoryMapper.selectByExample(new NodeCategoryExample());
    }

    @Override
    public NodeCategory get(Integer id) {
        return nodeCategoryMapper.selectByPrimaryKey(id);
    }
}
