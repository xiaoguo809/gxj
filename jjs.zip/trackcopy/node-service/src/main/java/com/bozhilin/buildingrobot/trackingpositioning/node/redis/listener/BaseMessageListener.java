package com.bozhilin.buildingrobot.trackingpositioning.node.redis.listener;/**
 * @author :  pengjunming
 * @date :   10:47
 */

import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 *@Author: pengjunming
 *@Date:2019/8/16 10:47
 *@Description: Redis监听器的基类，主要对消息体进行了序列化操作
 *
 */
public abstract class BaseMessageListener<T> implements MessageListener {

    private static final Logger logger = LoggerFactory.getLogger(BaseMessageListener.class);

    // 消息体类型
    private Class<T> modelClz;

    public BaseMessageListener(){
        // 1获取子类的class(在创建子类对象的时候,会返回父类的构造方法)
        Class<? extends BaseMessageListener> clazz = this.getClass();
        // 2获取当前类的带有泛型的父类类型
        ParameterizedType type = (ParameterizedType) clazz.getGenericSuperclass();
        // 3返回实际参数类型(泛型可以写多个)
        Type[] types = type.getActualTypeArguments();
        // 4 获取第一个参数(泛型的具体类)
        modelClz = (Class) types[0];
    }

    @Override
    public void onMessage(Message message, byte[] pattern) {
        handleMessage(JSON.parseObject(new String(message.getBody()), modelClz));
    }

    /**
     * @Author pengjunming
     * @Description 具体处理消息逻辑
     * @Date  2019/8/16 11:13
     * @Param 待处理的消息实体
     **/
    protected abstract void handleMessage(T t);
}
