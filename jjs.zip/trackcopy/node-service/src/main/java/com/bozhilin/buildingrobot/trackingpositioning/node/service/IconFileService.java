package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconFileData;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconFileDataExample;

/**
 * author guoxujie
 * date 2019-08-15
 **/
public interface IconFileService {
    IconFileData getIconFile(Long iconFileId);

    int deleteIconFile(Long iconFileId);

    int addIconFile(IconFileData icon);

    int updateIconFile(IconFileData icon, IconFileDataExample example);
}
