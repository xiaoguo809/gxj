package com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis;

import com.bozhilin.buildingrobot.trackingpositioning.node.constant.Constants;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointDTO;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Map;

/**
 * 标签最后定位RedisDao
 * Create by TanJY on 2019/08/23
 */
@Repository
public class TrackLastPositionRedisDao {

    @Resource(name="jsonRedisTemplate")
    private RedisTemplate redisTemplate;

    /**
     * 获取最后位置坐标
     * @Author TanJY
     * @CreateTime 2019/8/21
     */
    public Map<String, TagTrackPointDTO> getLastPosition(String tagCode) {
        String key = String.format(Constants.TAG_LAST_POSITION_KEY, tagCode);
        HashOperations<String, String, TagTrackPointDTO> hash = redisTemplate.opsForHash();
        return hash.entries(key);
    }

    /**
     * 保存最后位置坐标
     * @Author TanJY
     * @CreateTime 2019/8/21
     */
    public void saveLastPosition(String tagCode, Map<String, TagTrackPointDTO> map){
        String key = String.format(Constants.TAG_LAST_POSITION_KEY, tagCode);
        HashOperations<String, String, TagTrackPointDTO> hash = redisTemplate.opsForHash();
        hash.putAll(key, map);
    }
}
