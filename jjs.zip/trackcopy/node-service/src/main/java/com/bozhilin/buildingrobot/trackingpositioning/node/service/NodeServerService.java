package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeServerDto;
import org.springframework.transaction.annotation.Transactional;

/**
 * NodeServerService
 * Created by chenang on 2019/7/28
 */
public interface NodeServerService {
    @Transactional
    int create(NodeServerDto nodeServerDto);

    @Transactional
    int update(Integer serverId, NodeServerDto nodeServerDto);

    @Transactional
    int delete(Integer serverId);

    NodeServerDto get(Integer serverId);
}
