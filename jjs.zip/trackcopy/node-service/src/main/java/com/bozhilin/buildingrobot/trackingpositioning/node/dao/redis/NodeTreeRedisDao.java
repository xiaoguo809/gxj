package com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis;

import com.bozhilin.buildingrobot.trackingpositioning.node.model.protobuf.NodeTreeMessage;

import java.io.IOException;

/**
 * 后台用户与角色管理自定义Dao
 * Created by chenang on 2019/7/28.
 */
public interface NodeTreeRedisDao {

    /**
     * 获取用于所有角色
     */
    NodeTreeMessage getNodeTree(Integer serverId) throws IOException;
}
