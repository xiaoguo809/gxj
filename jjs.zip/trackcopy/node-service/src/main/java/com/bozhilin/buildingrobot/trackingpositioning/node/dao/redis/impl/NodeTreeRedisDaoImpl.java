package com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.impl;

import com.bozhilin.buildingrobot.trackingpositioning.node.component.ByteRedisTemplate;
import com.bozhilin.buildingrobot.trackingpositioning.node.constant.Constants;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.NodeTreeRedisDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.protobuf.NodeTreeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.io.IOException;

/**
 * 节点树Redis Dao
 * Created by chenang on 2019/7/28.
 */
@Repository
public class NodeTreeRedisDaoImpl implements NodeTreeRedisDao {

    @Autowired
    private ByteRedisTemplate byteRedisTemplate;

    /**
     * 根据服务器id查询节点树
     */
    public NodeTreeMessage getNodeTree(Integer serverId) throws IOException {
        byte[] nodeTreeBytes = byteRedisTemplate.opsForValue().get(Constants.REDIS_KEY_PREFIX_NODE_TREE + ":" + serverId);
        if (nodeTreeBytes == null) {
            return  null;
        }

        return NodeTreeMessage.parseFrom(nodeTreeBytes);
    }
}
