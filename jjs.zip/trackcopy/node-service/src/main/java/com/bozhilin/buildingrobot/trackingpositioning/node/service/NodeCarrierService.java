package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCarrier;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
public interface NodeCarrierService {
    List<NodeCarrier> listAll();

    @Transactional
    int create(NodeCarrier nodeCarrier);

    @Transactional
    int update(Long id, NodeCarrier nodeCarrier);

    @Transactional
    int delete(Long id);

    List<NodeCarrier> list(int pageNum, int pageSize);

    NodeCarrier get(Long id);

    int bindIcon(long nodeId,long iconid);
}
