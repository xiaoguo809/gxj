package com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis;

import com.bozhilin.buildingrobot.trackingpositioning.common.inf.Processor;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackContext;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;
import com.bozhilin.buildingrobot.trackingpositioning.node.constant.Constants;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointDTO;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.BoundSetOperations;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

/**
 * 轨迹RedisDao Create by TanJY on 2019/08/19
 */
@Slf4j
@Repository
public class TrackRealTimeRedisDao{

    private static final long DEFAULT_EXPIRE_TIME_FOR_LOCK = 1000L*10;

    @Resource(name="jsonRedisTemplate")
    private RedisTemplate redisTemplate;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private TrackContext context;

    private BoundSetOperations tagListBound;
    private Set<String> tagCodeSet = new HashSet<>();

    @PostConstruct
    public void init() {
        this.tagListBound = redisTemplate.boundSetOps(Constants.TAG_LIST_KEY);
    }

    /**
     * 保存标签轨迹数据到Redis
     *
     * @Author TanJY
     * @CreateTime 2019/8/20
     */
    public void saveTagTrack(TagTrackPointDTO tagTrackPointDTO) {
        if (!tagCodeSet.contains(tagTrackPointDTO.getTagCode())) {
            // 保存标签列表
            this.tagListBound.add(tagTrackPointDTO.getTagCode());
            this.tagCodeSet.add(tagTrackPointDTO.getTagCode());
        }
        String key = String.format(Constants.TAG_REALTIME_KEY, tagTrackPointDTO.getTagCode());
        Long timestamp = tagTrackPointDTO.getTime().getTime();
        String coordinate = new StringBuilder().append(tagTrackPointDTO.getX()).append(",").append(tagTrackPointDTO.getY()).append(",").append(tagTrackPointDTO.getZ()).toString();
        // 保存标签定位数据
        HashOperations<String, String, String> hash = redisTemplate.opsForHash();
        hash.put(key, timestamp.toString(), coordinate);
    }

    /**
     * 保存标签轨迹数据到Redis
     * @Author TanJY
     * @CreateTime 2019/8/30 0030
     */
    @Async
    public void saveTagTrack(List<TagTrackPointDTO> pointDTOList) {
        long startTime = System.currentTimeMillis();
        List<String> tagCodeList = new ArrayList<>();
        Map<String, Map<String, String>> tagMap = new HashMap<>();
        for (TagTrackPointDTO tagTrackPointDTO : pointDTOList) {
            if (!tagCodeSet.contains(tagTrackPointDTO.getTagCode())) {
                tagCodeList.add(tagTrackPointDTO.getTagCode());
                this.tagCodeSet.add(tagTrackPointDTO.getTagCode());
            }
            String key = String.format(Constants.TAG_REALTIME_KEY, tagTrackPointDTO.getTagCode());
            Long timestamp = tagTrackPointDTO.getTime().getTime();
            String coordinate = new StringBuilder().append(tagTrackPointDTO.getX()).append(",").append(tagTrackPointDTO.getY()).append(",").append(tagTrackPointDTO.getZ()).toString();
            if (tagMap.containsKey(key)) {
                tagMap.get(key).put(timestamp.toString(), coordinate);
            } else {
                Map<String, String> map = new HashMap<>();
                map.put(timestamp.toString(), coordinate);
                tagMap.put(key, map);
            }
        }
        // 保存标签列表
        Set<String> resutl = tagListBound.members();
        if (tagCodeList.size() > 0) {
            this.tagListBound.add(tagCodeList.toArray());
        }
        // 保存标签定位数据
        HashOperations<String, String, String> hash = redisTemplate.opsForHash();
        tagMap.forEach((k, v) -> hash.putAll(k, v));
        log.debug("saveTagTrack保存数据条数：{},用时：{}ms", pointDTOList.size(), System.currentTimeMillis() - startTime);
    }

    /**
     * 通过tagCode获取
     *
     * @Author TanJY
     * @CreateTime 2019/8/20
     */
    public Map<String, String> getByTagCode(String tagCode) {
        String key = String.format(Constants.TAG_REALTIME_KEY, tagCode);
        return getByKey(key);
    }

    /**
     * 通过key获取
     *
     * @Author TanJY
     * @CreateTime 2019/8/20
     */
    public Map<String, String> getByKey(String key) {
        HashOperations<String, String, String> hash = redisTemplate.opsForHash();
        return hash.entries(key);
    }

    /**
     * 获取所有标签列表
     *
     * @Author TanJY
     * @CreateTime 2019/8/20
     */
    public Set<String> getTagList() {
        ScanOptions scanOptions = new ScanOptions.ScanOptionsBuilder().count(50).match("*").build();
        Cursor<String> cursor = this.tagListBound.scan(scanOptions);
        Set<String> tagSet = new HashSet<>();
        try {
            while (cursor.hasNext()) {
                tagSet.add(cursor.next());
            }
            cursor.close();
        } catch (Exception e) {
            log.error("Redis游标出错:", e);
        }
        return tagSet;
    }

    /**
     * 从标签列表中移除
     *
     * @Author TanJY
     * @CreateTime 2019/8/20
     */
    public void removeFromTagList(String tagCode) {

        this.tagCodeSet.remove(tagCode);
        this.tagListBound.remove(tagCode);
    }

    /**
     * 移除实时定位缓存
     *
     * @Author TanJY
     * @CreateTime 2019/8/20
     */
    public void removeTagRealTime(String tagCode, List<String> hashKeys) {
        String key = String.format(Constants.TAG_REALTIME_KEY, tagCode);
        HashOperations<String, String, String> hash = redisTemplate.opsForHash();
        hash.delete(key, hashKeys.toArray(new String[hashKeys.size()]));
    }

    /**
     * @Author pengjunming
     * @Description 获取所有激活的标签
     * @Date 2019/8/26 16:58
     **/
    public Set<String> getAllActiveAreas() {
        return new HashSet(this.stringRedisTemplate.opsForHash().values(context.getLabelToArea()));
    }

    /**
     * @param key - 锁对应的key expireTime - 过期时间
     * @return boolean
     * @Author pengjunming
     * @Description 获取锁
     **/
    public boolean getLock(String key, long expireTime) {
        if (StringUtils.isBlank(key)) {
            log.error("Key should not be blank");
            throw new RuntimeException("Invalid parameter.");
        }
        return (boolean) redisTemplate.execute(new RedisCallback<Boolean>() {
            @Override
            public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
                return connection.setNX(key.getBytes(), String.valueOf(System.currentTimeMillis() + expireTime).getBytes());
            }
        });
    }

    /**
     * @Author pengjunming
     * @Description 获取锁
     * @Date 2019/8/22 14:47
     **/
    public boolean getLock(String key) {
        return getLock(key, DEFAULT_EXPIRE_TIME_FOR_LOCK);
    }

    /**
     * @return true:获取锁成功, false:获取锁失败
     * @Author pengjunming
     * @Description //TODO
     * @Date 2019/8/23 16:33
     * @Param key - 锁对应的键 retryTimes - 重试次数 intervalTime - 重试的间隔时间,单位毫秒
     **/
    public boolean getLock(String key, int retryTimes, long intervalTime) {
        boolean isLocked = false;
        if (retryTimes <= 0) {
            log.error("RetryTimes [{}] should be a positive integer.", retryTimes);
            throw new RuntimeException("Invalid retryTimes.");
        }
        if (intervalTime <= 0) {
            log.error("IntervalTime [{}] should be a positive integer.", intervalTime);
            throw new RuntimeException("Invalid intervalTime.");
        }

        for (int i = 0; i < retryTimes; i++) {
            isLocked = getLock(key);
            if (isLocked) {
                return true;
            }
            try {
                Thread.sleep(intervalTime);
            } catch (InterruptedException e) {
                log.error("Sleep [{}] ms failed.", intervalTime, e);
            }
        }
        return false;
    }

    public boolean delete(String key) {
        return redisTemplate.delete(key);
    }

    public boolean processWhileLock(String key, int retryTimes, long intervalTime, Processor processor) {
        boolean isLocked = getLock(key, retryTimes, intervalTime);
        if (isLocked) {
            processor.process();
        } else {
            //判断是否已经过期,防止死锁
            String exireTime = (String) redisTemplate.opsForValue().get(key);
            if (StringUtil.isEmpty(exireTime)) {
                return processWhileLock(key, retryTimes, intervalTime, processor);
            }
            //已经过期
            if (Long.valueOf(exireTime) < System.currentTimeMillis()) {
                //删除锁防止死锁
                delete(key);
                return processWhileLock(key, retryTimes, intervalTime, processor);
            }
            return false;
        }
        delete(key);
        return true;
    }

    public List<String> getAllList(String key) {
        if(StringUtils.isBlank(key)){
            throw new RuntimeException("Key should not be blank.");
        }
        return redisTemplate.opsForList().range(key, 0, -1);
    }

    public void setRedisTemplate(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }
}
