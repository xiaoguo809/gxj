package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeDefineMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeLabelPropertyMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefine;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeLabelProperty;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeLabelDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeLabelService;
import com.bozhilin.buildingrobot.trackingpositioning.node.util.NodeUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeLabelServiceImpl implements NodeLabelService {
    @Autowired
    private NodeDefineMapper nodeDefineMapper;

    @Autowired
    private NodeLabelPropertyMapper nodeLabelPropertyMapper;

    public int create(NodeLabelDto nodeLabelDto) {
        NodeDefine nodeDefine = new NodeDefine();
        BeanUtils.copyProperties(nodeLabelDto, nodeDefine);
        nodeDefine.setCreateTime(new Date());
        nodeDefine.setModifyTime(nodeDefine.getCreateTime());
        //nodeDefine.setCategoryId(4L);
        nodeDefine.setState(1);
        nodeDefineMapper.insertSelective(nodeDefine);
        return nodeLabelPropertyMapper.insertSelective(nodeLabelDto);
    }

    public int update(Integer serverId, Integer nodeId, NodeLabelDto nodeLabelDto) {
        nodeLabelDto.setServerId(serverId);
        if ("".equals(nodeLabelDto.getServerId())) {
            nodeLabelDto.setServerId(serverId);
        }

        if (nodeId.equals(nodeLabelDto.getId())) {
            NodeDefine nodeDefine = new NodeDefine();
            BeanUtils.copyProperties(nodeLabelDto, nodeDefine);
            nodeDefine.setModifyTime(new Date());
            nodeDefineMapper.updateByPrimaryKeySelective(nodeDefine);
            return nodeLabelPropertyMapper.updateByPrimaryKeySelective(nodeLabelDto);
        } else {
            delete(serverId, nodeId);
            return create(nodeLabelDto);
        }
    }

    public int delete(Integer serverId, Integer nodeId) {
        nodeDefineMapper.deleteByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));
        return nodeLabelPropertyMapper.deleteByPrimaryKey(NodeUtil.nodeLabelPropertyKey(serverId, nodeId));
    }

    public NodeLabelDto get(Integer serverId, Integer nodeId) {
        NodeLabelProperty nodeLabelProperty = nodeLabelPropertyMapper.selectByPrimaryKey(
                NodeUtil.nodeLabelPropertyKey(serverId, nodeId));
        NodeDefine nodeDefine = nodeDefineMapper.selectByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));

        NodeLabelDto nodeLabelDto = new NodeLabelDto();
        BeanUtils.copyProperties(nodeLabelProperty, nodeLabelDto);
        BeanUtils.copyProperties(nodeDefine, nodeLabelDto);
        return nodeLabelDto;
    }
}
