package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCategory;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefine;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.NodeTreeHierarchy;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class NodeTreeDto implements Serializable {
    @ApiModelProperty(value = "节点树列表")
    private List<NodeTreeHierarchy> nodeList = new ArrayList<>();

    @ApiModelProperty(value = "节点定义列表")
    private List<NodeDefine> nodeDefineList = new ArrayList<>();

    @ApiModelProperty(value = "节点分类列表")
    private List<NodeCategory> nodeCategoryList = new ArrayList<>();

    private static final long serialVersionUID = 1L;
}
