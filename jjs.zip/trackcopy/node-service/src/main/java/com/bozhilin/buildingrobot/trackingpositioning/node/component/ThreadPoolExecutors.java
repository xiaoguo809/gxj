package com.bozhilin.buildingrobot.trackingpositioning.node.component;/**
 * @author :  pengjunming
 * @date :   11:28
 */

import com.bozhilin.buildingrobot.trackingpositioning.node.model.QueueType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.*;

/**
 * @Author: pengjunming
 * @Date:2019/8/23 11:28
 * @Description: 线程池服务类
 */

@Component
public class ThreadPoolExecutors {

    private ThreadPoolExecutor executor;

    public ThreadPoolExecutors(@Value("${thread.pool.core-pool-size}") int corePoolSize,
                               @Value("${thread.pool.maximum-pool-size}") int maximumPoolSize,
                               @Value("${thread.pool.keep-alive-time}") long keepAliveTime,
                               @Value("${thread.pool.queue-type:LINKED}") QueueType type,
                               @Value("${thread.pool.capacity:10}") int capacity) {
        BlockingQueue queue;
        if (type == QueueType.ARRAY) {
            queue = new ArrayBlockingQueue(capacity);
        } else {
            queue = new LinkedBlockingQueue(capacity);
        }
        this.executor = new ThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, TimeUnit.SECONDS,
                queue);
    }

    public void execute(Runnable task) {
        executor.execute(task);
    }

    public Future<?> submit(Runnable task) {
        return executor.submit(task);
    }
}
