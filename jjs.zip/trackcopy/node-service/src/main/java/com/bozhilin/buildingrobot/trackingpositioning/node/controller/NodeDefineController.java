package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonPage;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefine;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeDefineService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 节点管理Controller
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeDefineController", description = "节点管理")
@RestController
@RequestMapping("/define")
@Slf4j
public class NodeDefineController {

    @Autowired
    private NodeDefineService nodeDefineService;

    @ApiOperation("获取所有节点列表")
    @GetMapping(value = "all")
    public CommonResult<List<NodeDefine>> listAll(@RequestParam("serverId") Integer serverId) {
        return CommonResult.success(nodeDefineService.listAll(serverId));
    }

    @ApiOperation("添加节点")
    @PostMapping(value = "/create")
    public CommonResult create(@RequestBody NodeDefine nodeDefine) {
        CommonResult commonResult;
        int count = nodeDefineService.create(nodeDefine);
        if (count == 1) {
            commonResult = CommonResult.success(nodeDefine);
            log.debug("create node define success:{}", nodeDefine);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node define failed:{}", nodeDefine);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id节点信息")
    @PostMapping(value = "/update")
    public CommonResult update(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId,
                               @RequestBody NodeDefine nodeDefine) {
        CommonResult commonResult;
        int count = nodeDefineService.update(serverId, nodeId, nodeDefine);
        if (count == 1) {
            commonResult = CommonResult.success(nodeDefine);
            log.debug("update node define success:{}", nodeDefine);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node define failed:{}", nodeDefine);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的节点")
    @GetMapping(value = "/delete")
    public CommonResult delete(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId) {
        int count = nodeDefineService.delete(serverId, nodeId);
        if (count == 1) {
            log.debug("delete node define success: serverId={}, id={}", serverId, nodeId);
            return CommonResult.success(null);
        } else {
            log.debug("delete node define failed: serverId={}, id={}", serverId, nodeId);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("分页查询节点列表")
    @GetMapping(value = "/list")
    public CommonResult<CommonPage<NodeDefine>> list(@RequestParam(name="页码", defaultValue = "1")Integer pageNum,
                                                     @RequestParam(name="每页数量", defaultValue = "10")Integer pageSize) {
        List<NodeDefine> NodeList = nodeDefineService.list(pageNum, pageSize);
        return CommonResult.success(CommonPage.restPage(NodeList));
    }

    @ApiOperation("获取指定id的节点详情")
    @GetMapping(value = "/get")
    public CommonResult<NodeDefine> get(@RequestParam("serverId") Integer serverId,
                                        @RequestParam("nodeId") Integer nodeId) {
        return CommonResult.success(nodeDefineService.get(serverId, nodeId));
    }

    @ApiOperation("根据关键字搜索节点")
    @GetMapping(value = "/search")
    public CommonResult<List<NodeDefine>> search(@RequestParam("key") String key) {
        return CommonResult.success(nodeDefineService.search(key));
    }
}
