package com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatistics;

/**
 * 节点统计Redis Dao
 * Created by chenang on 2019/7/28.
 */
public interface NodeStatisticsRedisDao {

    /**
     * 获取节点统计信息
     */
    NodeStatistics getStatistics(Integer serverId, Integer nodeId, String key) throws Exception;
}
