package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCarrier;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeCarrierService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * 载体管理
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeCarrierController", description = "载体管理")
@Controller
@RequestMapping("/carrier")
@Slf4j
@Validated
public class NodeCarrierController {

    @Autowired
    private NodeCarrierService nodeCarrierService;

    @ApiOperation("获取所有载体列表")
    @RequestMapping(value = "all", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<NodeCarrier>> listAll() {
        return CommonResult.success(nodeCarrierService.listAll());
    }

    @ApiOperation("添加载体")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult create(@RequestBody NodeCarrier nodeCarrier) {
        CommonResult commonResult;
        int count = nodeCarrierService.create(nodeCarrier);
        if (count == 1) {
            commonResult = CommonResult.success(nodeCarrier);
            log.debug("create node carrier success:{}", nodeCarrier);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node carrier failed:{}", nodeCarrier);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id载体信息")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult update(@RequestParam("id") @NotNull(message = "id不能为空") Long id,
                               @RequestBody NodeCarrier nodeCarrier) {
        CommonResult commonResult;
        int count = nodeCarrierService.update(id, nodeCarrier);
        if (count == 1) {
            commonResult = CommonResult.success(nodeCarrier);
            log.debug("update node carrier success:{}", nodeCarrier);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node carrier failed:{}", nodeCarrier);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的载体")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult delete(@RequestParam("id") Long id) {
        int count = nodeCarrierService.delete(id);
        if (count == 1) {
            log.debug("delete node carrier success: id={}", id);
            return CommonResult.success(null);
        } else {
            log.debug("delete node carrier failed: id={}", id);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("获取指定id的载体详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<NodeCarrier> getNodeCarrier(@RequestParam("id") Long id) {
        return CommonResult.success(nodeCarrierService.get(id));
    }

    @ApiOperation("绑定图标到载体")
    @RequestMapping(value = "/addIcon", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult<NodeCarrier> bindIconToNodeCarrier(long nodeId, long iconId) {
        int rs = nodeCarrierService.bindIcon(nodeId, iconId);
        if (rs > 0) {
            return CommonResult.success(nodeCarrierService.get(nodeId));
        }
        return CommonResult.failed("绑定失败");
    }

}
