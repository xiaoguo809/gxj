package com.bozhilin.buildingrobot.trackingpositioning.node.task;

import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackMerge;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper.TrackDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.TrackRealTimeRedisDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import lombok.extern.slf4j.Slf4j;

/**
 * 轨迹数据保存定时任务(Redis->DB)
 * Create by TanJY on 2019/08/20
 */
@Slf4j
@Component
public class TrackRedisDataToDBTask {
    @Autowired
    private TrackDao trackDao;

    @Autowired
    private TrackRealTimeRedisDao trackRealTimeRedisDao;

    /** 批量保存最大行数 */
    private final int BATCH_MAX = 500;

    private AtomicBoolean isRunning = new AtomicBoolean(false);

    /**
     * 定时从Redis取数据，汇聚，然后写入到数据库
     * （注：分布式环境不能使用Scheduled此调试方式，会导致重复执行）
     * @Author TanJY
     * @CreateTime 2019/8/20
     */
    @Scheduled(fixedRate = 10000)
    public void writeToDB() {
        // 判断是否正在运行，防止重复执行
        if (!isRunning.compareAndSet(false, true)) {
            return;
        }
        try {
            long startTime = System.currentTimeMillis();
            long step1 = 0l;
            long step2 = 0l;
            long step3 = 0l;
            long step4 = 0l;
            long step5 = 0l;
            long step6 = 0l;
            long step7 = 0l;
            long step8 = 0l;
            List<TrackMerge> trackMergeList = new ArrayList<>();
            Map<String, List<String>> tagRealTimeDataDelMap = new HashMap<>();

            long endTime = new Date().getTime() - 10000; // 取10秒前的所有定位数据
            // 获取所有标签编码
            long startTime1 = System.currentTimeMillis();
            Set<String> tagCodeList = trackRealTimeRedisDao.getTagList();
            step1 = System.currentTimeMillis() - startTime1;
            for (String tagCode : tagCodeList) {
                // 获取标签编码对应的缓存数据
                long startTime2 = System.currentTimeMillis();
                Map<String, String> trackMap = trackRealTimeRedisDao.getByTagCode(tagCode); // key是时间(毫秒),value是坐标
                step2 += System.currentTimeMillis() - startTime2;
                if (trackMap == null || trackMap.size() == 0) {
                    trackRealTimeRedisDao.removeFromTagList(tagCode);
                    continue;
                }
                trackMap = this.sortMap(trackMap); // 升序排序
                log.info("通过tagCode从redis获取轨迹数据 : {} => {}", tagCode, JSON.toJSONString(trackMap));
                // 按秒分组汇聚数据
                long startTime3 = System.currentTimeMillis();
                Map<Long, StringBuilder> trackMergeMap = new HashMap<>(); // key是秒,value是坐标列表,用#号分隔
                tagRealTimeDataDelMap.put(tagCode, new ArrayList<>());
                trackMap.forEach((k, v) -> {
                    long time = Long.valueOf(k);
                    if (time < endTime) {
                        long secondTime = time / 1000;
                        if (trackMergeMap.containsKey(secondTime)) {
                            trackMergeMap.get(secondTime).append(v).append("#");
                        } else {
                            StringBuilder coordinates = new StringBuilder().append(v).append("#");
                            trackMergeMap.put(secondTime, coordinates);
                        }
                        tagRealTimeDataDelMap.get(tagCode).add(k);
                    }
                });
                step3 += System.currentTimeMillis() - startTime3;

                // 组装数据对象
                long startTime4 = System.currentTimeMillis();
                if (trackMergeMap.size() > 0) {
                    trackMergeMap.forEach((k, v) -> {
                        TrackMerge trackMerge = new TrackMerge();
                        trackMerge.setTagCode(tagCode);
                        trackMerge.setTime(new Date(Long.valueOf(k + "000")));
                        trackMerge.setCoordinateList(v.toString());
                        trackMergeList.add(trackMerge);
                    });
                }
                step4 += System.currentTimeMillis() - startTime4;

            }

            if (trackMergeList.size() > 0) {
                // 保存至DB
                long startTime5 = System.currentTimeMillis();
                this.saveTrackMerge(trackMergeList);
                step5 = System.currentTimeMillis() - startTime5;
                // 清理已入库的实时轨迹缓存
                this.delTagRealTimeData(tagRealTimeDataDelMap);
                // 保存最后定位缓存
                long startTime8 = System.currentTimeMillis();
                //this.saveLastPosition();
                step8 = System.currentTimeMillis() - startTime8;

                log.info("执行定时任务TrackRedisDataToDBTask总用时:{}ms", System.currentTimeMillis() - startTime);
                log.info("其中,获取所有标签编码用时:{}ms", step1);
                log.info("获取标签编码对应的缓存数据用时:{}ms", step2);
                log.info("按秒分组汇聚数据用时:{}ms", step3);
                log.info("组装数据对象用时:{}ms", step4);
                log.info("保存至DB用时:{}ms", step5);
                log.info("清理已入库的实时轨迹缓存用时:{}ms", step6);
                log.info("保存精度轨迹用时:{}ms", step7);
                log.info("保存最后定位缓存用时:{}ms", step8);
            }
        } catch (Exception e) {
            log.error("执行定时任务TrackRedisDataToDBTask时出错：", e);
        } finally {
            isRunning.set(false);
        }
    }

    /**
     * 批量保存轨迹合并表
     * @Author TanJY
     * @CreateTime 2019/8/26 0026
     */
    private void saveTrackMerge(List<TrackMerge> trackMergeList) {
        if (trackMergeList == null || trackMergeList.size() == 0) {
            return;
        } else if (trackMergeList.size() < BATCH_MAX){
            trackDao.saveTrackMerge(trackMergeList);
        } else {
            for (int i = 0; i < trackMergeList.size(); i = i + BATCH_MAX) {
                List<TrackMerge> subList = trackMergeList.subList(i, i + BATCH_MAX > trackMergeList.size() ? trackMergeList.size() : i + BATCH_MAX);
                trackDao.saveTrackMerge(subList);
            }
        }
    }

    /**
     * 删除redis中的实时轨迹数据
     * @Author TanJY
     * @CreateTime 2019/8/26 0026
     */
    private void delTagRealTimeData(Map<String, List<String>> trackRealTimeDataDelMap) {
        if (trackRealTimeDataDelMap == null || trackRealTimeDataDelMap.size() == 0) {
            return;
        } else {
            trackRealTimeDataDelMap.forEach((k, list) -> {
                if (list.size() > 0) {
                    trackRealTimeRedisDao.removeTagRealTime(k, list);
                }
            });
        }
    }


    /**
     * 按key升序排序
     * @Author TanJY
     * @CreateTime 2019/8/26 0026
     */
    private Map<String, String> sortMap(Map<String, String> map) {
        List<Map.Entry<String, String>> list = new ArrayList<>(map.entrySet());
        // 按key升序排序
        Collections.sort(list, Comparator.comparing(o -> Long.valueOf(o.getKey())));
        Map result = new LinkedHashMap();
        for (Map.Entry<String, String> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

}
