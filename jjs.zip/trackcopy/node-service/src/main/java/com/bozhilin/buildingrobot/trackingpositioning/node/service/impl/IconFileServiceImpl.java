package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.IconFileDataMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconFileData;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconFileDataExample;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.IconFileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * author guoxujie
 * date 2019年8月16日
 */
@Service
public class IconFileServiceImpl implements IconFileService {

    @Autowired
    IconFileDataMapper iconFileDataMapper;

    @Override
    public IconFileData getIconFile(Long iconFileId) {
        return iconFileDataMapper.selectByPrimaryKey(iconFileId);
    }

    @Override
    public int deleteIconFile(Long iconFileId) {
        return iconFileDataMapper.deleteByPrimaryKey(iconFileId);
    }

    @Override
    public int addIconFile(IconFileData icon) {
        return iconFileDataMapper.insertSelective(icon);
    }

    @Override
    public int updateIconFile(IconFileData icon, IconFileDataExample example) {
        return iconFileDataMapper.updateByExampleSelective(icon, example);
    }
}
