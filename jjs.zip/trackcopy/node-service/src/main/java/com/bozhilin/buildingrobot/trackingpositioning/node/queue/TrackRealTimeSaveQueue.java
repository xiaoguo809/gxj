package com.bozhilin.buildingrobot.trackingpositioning.node.queue;

import com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.TrackRealTimeRedisDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointDTO;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 轨迹实时数据保存队列
 * Create by TanJY on 2019/08/30
 */
@Slf4j
@Component
public class TrackRealTimeSaveQueue {
    @Getter
    private LinkedBlockingQueue<TagTrackPointDTO> queue = new LinkedBlockingQueue();

    @Autowired
    private TrackRealTimeRedisDao trackRealTimeRedisDao;

    @PostConstruct
    private void execute() {
        ThreadPoolExecutor executor = new ThreadPoolExecutor(1, 1, 0l, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        executor.execute(new TrackRealTimeSaveThread());
    }

    class TrackRealTimeSaveThread implements Runnable {
        @Override
        public void run() {
            int initCapacity = 1024; // 指定list初始容量，减少扩容次数
            List<TagTrackPointDTO> pointDTOList = new ArrayList<>(initCapacity);
            while (true) {
                try {
                    TagTrackPointDTO point = queue.take();
                    pointDTOList.add(point);
                    if (queue.isEmpty() && pointDTOList.size() < initCapacity / 8) {
                        Thread.sleep(1); // 避免队列太短，停顿1ms再继续
                    }
                    if (queue.isEmpty() || pointDTOList.size() >= initCapacity) {
                        trackRealTimeRedisDao.saveTagTrack(pointDTOList);
                        pointDTOList = new ArrayList<>(initCapacity);
                    }
                } catch (Exception e) {
                    log.error("轨迹实时数据保存线程报错：", e);
                }
            }
        }
    }

}
