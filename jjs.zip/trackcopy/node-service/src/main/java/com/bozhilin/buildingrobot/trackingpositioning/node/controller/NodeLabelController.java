package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeLabelDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeLabelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * 标签管理
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeLabelController", description = "标签管理")
@Controller
@RequestMapping("/label")
@Slf4j
public class NodeLabelController {

    @Autowired
    private NodeLabelService nodeLabelService;

    @ApiOperation("添加标签")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult create(@RequestBody NodeLabelDto nodeLabelDto) {
        CommonResult commonResult;
        int count = nodeLabelService.create(nodeLabelDto);
        if (count == 1) {
            commonResult = CommonResult.success(nodeLabelDto);
            log.debug("create node label success:{}", nodeLabelDto);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node label failed:{}", nodeLabelDto);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id标签信息")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult update(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId,
                               @RequestBody NodeLabelDto nodeLabelDto) {
        CommonResult commonResult;
        int count = nodeLabelService.update(serverId, nodeId, nodeLabelDto);
        if (count == 1) {
            commonResult = CommonResult.success(nodeLabelDto);
            log.debug("update node label success:{}", nodeLabelDto);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node label failed:{}", nodeLabelDto);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的标签")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult delete(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId) {
        int count = nodeLabelService.delete(serverId, nodeId);
        if (count == 1) {
            log.debug("delete node label success: serverId={}, id={}", serverId, nodeId);
            return CommonResult.success(null);
        } else {
            log.debug("delete node label failed: serverId={}, id={}", serverId, nodeId);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("获取指定id的标签详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<NodeLabelDto> getNodeLabel(@RequestParam("serverId") Integer serverId,
                                                   @RequestParam("nodeId") Integer nodeId) {
        return CommonResult.success(nodeLabelService.get(serverId, nodeId));
    }
}
