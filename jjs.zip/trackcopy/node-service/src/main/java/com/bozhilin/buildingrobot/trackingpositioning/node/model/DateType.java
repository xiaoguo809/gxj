package com.bozhilin.buildingrobot.trackingpositioning.node.model;

public enum DateType {
    SECOND,
    MINUTE,
    HOUR,
    DAY;
}
