package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
public class SearchNodeByKeyDto implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "节点id")
    private Integer id;
    @ApiModelProperty(value = "节点名称")
    private String name;
    @ApiModelProperty(value = "节点分类id")
    private Integer categoryId;
    @ApiModelProperty(value = "载体id")
    private String carrierId;
    @ApiModelProperty(value = "经度")
    private Long longitude;
    @ApiModelProperty(value = "纬度")
    private Long latitude;
    @ApiModelProperty(value = "高度")
    private Long height;
    @ApiModelProperty(value = "设备最后位置的时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date time;
}
