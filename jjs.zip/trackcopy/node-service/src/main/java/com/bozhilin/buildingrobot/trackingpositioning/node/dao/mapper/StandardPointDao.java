package com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.StandardPoint;
import org.apache.ibatis.annotations.Param;

/**
 * @Author pengjunming
 * @Date 2019/8/31 11:14
 * @Description 基准点的Mybatis接口类
 **/
public interface StandardPointDao {

    void save(@Param("standardPoint") StandardPoint standardPoint);

    StandardPoint findByAreaCode(@Param("areaCode") String areaCode);

    int update(@Param("standardPoint") StandardPoint updatedRecord);

    int deleteByAreaCode(@Param("areaCode") String areaCode);
}
