package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeBasestationDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeBasestationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 基站管理Controller
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeBasestationController", description = "基站管理")
@RestController
@RequestMapping("/basestation")
@Slf4j
public class NodeBasestationController {

    @Autowired
    private NodeBasestationService nodeBasestationService;

    @ApiOperation("添加基站")
    @PostMapping(value = "/create")
    public CommonResult create(@RequestBody NodeBasestationDto nodeBasestationDto) {
        CommonResult commonResult;
        int count = nodeBasestationService.create(nodeBasestationDto);
        if (count == 1) {
            commonResult = CommonResult.success(nodeBasestationDto);
            log.debug("create node basestation success:{}", nodeBasestationDto);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node basestation failed:{}", nodeBasestationDto);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id基站信息")
    @PostMapping(value = "/update")
    public CommonResult update(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId,
                               @RequestBody NodeBasestationDto nodeBasestationDto) {
        CommonResult commonResult;
        int count = nodeBasestationService.update(serverId, nodeId, nodeBasestationDto);
        if (count == 1) {
            commonResult = CommonResult.success(nodeBasestationDto);
            log.debug("update node basestation success:{}", nodeBasestationDto);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node basestation failed:{}", nodeBasestationDto);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的基站")
    @GetMapping(value = "/delete")
    public CommonResult delete(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId) {
        int count = nodeBasestationService.delete(serverId, nodeId);
        if (count == 1) {
            log.debug("delete node basestation success: serverId={}, id={}", serverId, nodeId);
            return CommonResult.success(null);
        } else {
            log.debug("delete node basestation failed: serverId={}, id={}", serverId, nodeId);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("获取指定id的基站详情")
    @GetMapping(value = "/get")
    public CommonResult<NodeBasestationDto> get(@RequestParam("serverId") Integer serverId,
                                                @RequestParam("nodeId") Integer nodeId) {
        return CommonResult.success(nodeBasestationService.get(serverId, nodeId));
    }
}
