package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.SearchNodeByKeyDto;

import java.util.List;

/**
 * NodeSearchService
 * Created by chenang on 2019/7/28
 */
public interface NodeSearchService {

    List<SearchNodeByKeyDto> searchNodeByKey(String key, String isSearchBasestation, String carrierIds, String serverId) throws Exception;
}
