package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * 标签轨迹点
 * Create by TanJY on 2019/8/15
 */

@Getter
@Setter
public class TagTrackDTO implements Serializable {
    private String tagCode;
    private List positionList;
}
