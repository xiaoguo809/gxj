package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonPage;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessage;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeMessageService;
import com.bozhilin.buildingrobot.trackingpositioning.node.redis.listener.RedisSender;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.alibaba.fastjson.JSON;

import java.util.List;

/**
 * 节点消息管理Controller
 * Created by yutingyang on 2019/9/27
 */
@Api(tags = "NodeMessageController", description = "节点消息管理")
@Controller
@RequestMapping("/message")
@Slf4j
public class NodeMessageController {

    @Autowired
    private NodeMessageService nodeMessageService;

    @Autowired
    private RedisSender redisSender;

    @ApiOperation("获取所有节点消息列表")
    @RequestMapping(value = "all", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<NodeMessage>> listAll() {
        return CommonResult.success(nodeMessageService.listAll());
    }

    @ApiOperation("添加节点消息")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult create(@RequestBody NodeMessage nodeMessage) {
        CommonResult commonResult;
        int count = nodeMessageService.create(nodeMessage);
        if (count == 1) {
            commonResult = CommonResult.success(nodeMessage);
            String nodeMassageJson = JSON.toJSONString(commonResult);
            redisSender.sendChannelMess(nodeMassageJson);
            log.debug("create node command success:{}", nodeMessage);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node command failed:{}", nodeMessage);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id节点信息")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult update(@RequestParam("id") Long id,
                               @RequestBody NodeMessage nodeMessage) {
        CommonResult commonResult;
        int count = nodeMessageService.update(id, nodeMessage);
        if (count == 1) {
            commonResult = CommonResult.success(nodeMessage);
            log.debug("update node command success:{}", nodeMessage);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node command failed:{}", nodeMessage);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的节点消息")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult delete(@RequestParam("id") Long id) {
        int count = nodeMessageService.delete(id);
        if (count == 1) {
            log.debug("delete node command success :id={}", id);
            return CommonResult.success(null);
        } else {
            log.debug("delete node command failed :id={}", id);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("分页查询节点消息列表")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<CommonPage<NodeMessage>> list(@RequestParam(value = "pageNum", defaultValue = "1")
                                                           @ApiParam("页码") Integer pageNum,
                                                      @RequestParam(value = "pageSize", defaultValue = "10")
                                                           @ApiParam("每页数量") Integer pageSize) {
        List<NodeMessage> NodeList = nodeMessageService.list(pageNum, pageSize);
        return CommonResult.success(CommonPage.restPage(NodeList));
    }

    @ApiOperation("获取指定id的节点消息详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<NodeMessage> get(@RequestParam("id") Long id) {
        return CommonResult.success(nodeMessageService.get(id));
    }
}
