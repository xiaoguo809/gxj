package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonPage;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTree;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTreeKey;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeTreeDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeTreeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 节点树管理Controller
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeTreeController", description = "节点树管理")
@RestController
@RequestMapping("/tree")
@Slf4j
public class NodeTreeController {

    @Autowired
    private NodeTreeService nodeTreeService;

    @ApiOperation("获取所有节点树列表")
    @GetMapping(value = "all")
    public CommonResult<List<NodeTree>> listAll(@RequestParam("serverId") Integer serverId) {
        return CommonResult.success(nodeTreeService.listAll(serverId));
    }

    @ApiOperation("添加节点树")
    @PostMapping(value = "/create")
    public CommonResult create(@RequestBody NodeTree nodeTree) {
        CommonResult commonResult;
        int count = nodeTreeService.create(nodeTree);
        if (count == 1) {
            commonResult = CommonResult.success(nodeTree);
            log.debug("create node tree success:{}", nodeTree);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node tree failed:{}", nodeTree);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id节点树信息")
    @PostMapping(value = "/update")
    public CommonResult update(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId,
                               @RequestBody NodeTree nodeTree) {
        CommonResult commonResult;
        int count = nodeTreeService.update(serverId, nodeId, nodeTree);
        if (count == 1) {
            commonResult = CommonResult.success(nodeTree);
            log.debug("update node tree success:{}", nodeTree);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node tree failed:{}", nodeTree);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的节点树")
    @GetMapping(value = "/delete")
    public CommonResult delete(@RequestParam("serverId") Integer serverId, @RequestParam("nodeId") Integer nodeId) {
        NodeTreeKey nodeTreeKey = new NodeTreeKey();
        nodeTreeKey.setServerId(serverId);
        nodeTreeKey.setNodeId(nodeId);
        int count = nodeTreeService.delete(nodeTreeKey);
        if (count == 1) {
            log.debug("delete node tree success: serverId={}, id={}", serverId, nodeId);
            return CommonResult.success(null);
        } else {
            log.debug("delete node tree failed: serverId={}, id={}", serverId, nodeId);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("分页查询节点树列表")
    @GetMapping(value = "/list")
    public CommonResult<CommonPage<NodeTree>> list(@RequestParam(value = "pageNum", defaultValue = "1")
                                                       @ApiParam("页码") Integer pageNum,
                                                   @RequestParam(value = "pageSize", defaultValue = "10")
                                                       @ApiParam("每页数量") Integer pageSize) {
        List<NodeTree> NodeList = nodeTreeService.list(pageNum, pageSize);
        return CommonResult.success(CommonPage.restPage(NodeList));
    }

    @ApiOperation("获取指定id的节点树详情")
    @GetMapping(value = "/get")
    public CommonResult<NodeTree> get(@RequestParam("serverId") Integer serverId,
                                           @RequestParam("nodeId") Integer nodeId) {
        NodeTreeKey nodeTreeKey = new NodeTreeKey();
        nodeTreeKey.setServerId(serverId);
        nodeTreeKey.setNodeId(nodeId);
        return CommonResult.success(nodeTreeService.get(nodeTreeKey));
    }

    @ApiOperation("根据节点查询子节点树")
    @GetMapping(value = "/childrens")
    public CommonResult<NodeTreeDto> getChildrens(@RequestParam("serverId")
                                                      @ApiParam("服务器id") Integer serverId,
                                                  @RequestParam(value = "nodeId", required = false)
                                                      @ApiParam("节点id") Integer nodeId) throws Exception {
        return CommonResult.success(nodeTreeService.getChildrens(serverId, nodeId));
    }
}
