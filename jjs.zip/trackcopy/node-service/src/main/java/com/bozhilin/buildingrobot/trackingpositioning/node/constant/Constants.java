package com.bozhilin.buildingrobot.trackingpositioning.node.constant;

public final class Constants {

    // ========= 通用常量 =======
    public static final int VALID_STATE = 1; // 有效状态
    public static final int INVALID_STATE = 1; // 无效状态
    // ========= 修改标志 =======
    public static final int MODIFIED_FLAG = 1; // 已修改的标志
    public static final int NOT_MODIFIED_FLAG = 1; // 没有修改的标志

    // ========= Redis Key =========
    public static final String REDIS_KEY_PREFIX_NODE_TREE = "topologyTree";

    /** 标签最后位置坐标(用于计算位移量)，hashmap结构, %s填标签编码 */
    public static final String TAG_LAST_POSITION_KEY = "ROBOT_POSITIONING_TAG_LAST_POSITION_%s";

    /** 标签列表KEY，set结构 */
    public static final String TAG_LIST_KEY = "ROBOT_POSITIONING_TAG_LIST";

    /** 标签实时定位数据存储KEY，hashmap结构, %s填标签编码 */
    public static final String TAG_REALTIME_KEY = "ROBOT_POSITIONING_TAG_REALTIME_%s";




}
