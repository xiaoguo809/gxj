package com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatistics;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.NodeStatisticsRedisDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Repository;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * 节点统计Redis Dao Impl
 * Created by chenang on 2019/7/28.
 */
@Repository
public class NodeStatisticsRedisDaoImpl implements NodeStatisticsRedisDao {

    @Autowired
    private StringRedisTemplate redisTemplate;

    /**
     * 获取节点统计信息
     */
    public NodeStatistics getStatistics(Integer serverId, Integer nodeId, String key) throws Exception {
        HashOperations<String, String, String> hashOperations = redisTemplate.opsForHash();
        Map<String, String> nodeStatisticsMap = hashOperations.entries(key);
        if (nodeStatisticsMap == null || nodeStatisticsMap.size() == 0) {
            return null;
        }

        StringBuilder upstreamTraffic = new StringBuilder();
        StringBuilder downstreamTraffic = new StringBuilder();
        for (int i = 0; i < 24; ++i) {
            String upstreamTrafficHour = nvl(nodeStatisticsMap.get("up_packet_hour" + i), "0");
            String downstreamTrafficHour = nvl(nodeStatisticsMap.get("dn_packet_hour" + i), "0");
            if (i != 0) {
                upstreamTraffic.append(";");
                downstreamTraffic.append(";");
            }
            upstreamTraffic.append(upstreamTrafficHour);
            downstreamTraffic.append(downstreamTrafficHour);
        }

        NodeStatistics nodeStatistics = new NodeStatistics();
        nodeStatistics.setServerId(serverId);
        nodeStatistics.setNodeId(nodeId);
        nodeStatistics.setUpstreamTraffic(upstreamTraffic.toString());
        nodeStatistics.setDownstreamTraffic(downstreamTraffic.toString());
        nodeStatistics.setClassAQuantity(nvl(nodeStatisticsMap.get("tag_a"), "0"));
        nodeStatistics.setClassBQuantity(nvl(nodeStatisticsMap.get("tag_b"), "0"));
        nodeStatistics.setClassCQuantity(nvl(nodeStatisticsMap.get("tag_c"), "0"));
        String modifyTime = nodeStatisticsMap.get("updatetime");
        if (modifyTime != null) {
            nodeStatistics.setModifyTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(modifyTime));
        } else {
            nodeStatistics.setModifyTime(new Date());
        }
        return nodeStatistics;
    }

    private String nvl(String value, String defaultValue) {
        return value != null ? value : defaultValue;
    }
}
