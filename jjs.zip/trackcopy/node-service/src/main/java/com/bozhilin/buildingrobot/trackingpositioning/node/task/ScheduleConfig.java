package com.bozhilin.buildingrobot.trackingpositioning.node.task;/**
 * @author :  pengjunming
 * @date :   11:18
 */

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import java.util.concurrent.Executors;

/**
 *@Author: pengjunming
 *@Date:2019/8/23 11:18
 *@Description:
 *
 */
@Configuration
public class ScheduleConfig implements SchedulingConfigurer {

    @Value("${schedule.pool.core-size}")
    private int corePoolSize;

    @Override
    public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
        scheduledTaskRegistrar.setScheduler(Executors.newScheduledThreadPool(corePoolSize));
    }
}
