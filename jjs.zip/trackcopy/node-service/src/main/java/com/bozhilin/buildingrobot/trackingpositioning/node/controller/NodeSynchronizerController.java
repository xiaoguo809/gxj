package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeSynchronizerDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeSynchronizerService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * 同步器管理Controller
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeSynchronizerController", description = "同步器管理")
@Controller
@RequestMapping("/synchronizer")
@Slf4j
public class NodeSynchronizerController {

    @Autowired
    private NodeSynchronizerService nodeSynchronizerService;

    @ApiOperation("添加同步器")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult create(@RequestBody NodeSynchronizerDto nodeSynchronizerDto) {
        CommonResult commonResult;
        int count = nodeSynchronizerService.create(nodeSynchronizerDto);
        if (count == 1) {
            commonResult = CommonResult.success(nodeSynchronizerDto);
            log.debug("create node synchronizer success:{}", nodeSynchronizerDto);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node synchronizer failed:{}", nodeSynchronizerDto);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id同步器信息")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult update(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId,
                               @RequestBody NodeSynchronizerDto nodeSynchronizerDto) {
        CommonResult commonResult;
        int count = nodeSynchronizerService.update(serverId, nodeId, nodeSynchronizerDto);
        if (count == 1) {
            commonResult = CommonResult.success(nodeSynchronizerDto);
            log.debug("update node synchronizer success:{}", nodeSynchronizerDto);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node synchronizer failed:{}", nodeSynchronizerDto);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的同步器")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult delete(@RequestParam("serverId") Integer serverId,
                               @RequestParam("nodeId") Integer nodeId) {
        int count = nodeSynchronizerService.delete(serverId, nodeId);
        if (count == 1) {
            log.debug("delete node synchronizer success: serverId={}, id={}", serverId, nodeId);
            return CommonResult.success(null);
        } else {
            log.debug("delete node synchronizer failed: serverId={}, id={}", serverId, nodeId);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("获取指定id的同步器详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<NodeSynchronizerDto> getNodeSynchronizer(@RequestParam("serverId") Integer serverId,
                                                                 @RequestParam("nodeId") Integer nodeId) {
        return CommonResult.success(nodeSynchronizerService.get(serverId, nodeId));
    }
}
