package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeDefineMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeSynchronizerPropertyMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefine;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeSynchronizerProperty;
import com.bozhilin.buildingrobot.trackingpositioning.node.constant.Constants;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeSynchronizerDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeSynchronizerService;
import com.bozhilin.buildingrobot.trackingpositioning.node.util.NodeUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeSynchronizerServiceImpl implements NodeSynchronizerService {
    @Autowired
    private NodeDefineMapper nodeDefineMapper;

    @Autowired
    private NodeSynchronizerPropertyMapper nodeSynchronizerPropertyMapper;

    public int create(NodeSynchronizerDto nodeSynchronizerDto) {
        nodeSynchronizerDto.setCreateTime(new Date());
        NodeDefine nodeDefine = new NodeDefine();
        BeanUtils.copyProperties(nodeSynchronizerDto, nodeDefine);
        nodeDefine.setModifyTime(nodeSynchronizerDto.getCreateTime());
        nodeDefine.setState(Constants.VALID_STATE);
        nodeDefineMapper.insertSelective(nodeDefine);

        NodeSynchronizerProperty property = new NodeSynchronizerProperty();
        BeanUtils.copyProperties(nodeSynchronizerDto, property);
        property.setModifyTime(nodeSynchronizerDto.getCreateTime());
        property.setModifyFlag(Constants.MODIFIED_FLAG);
        return nodeSynchronizerPropertyMapper.insertSelective(property);
    }

    public int update(Integer serverId, Integer nodeId, NodeSynchronizerDto nodeSynchronizerDto) {
        nodeSynchronizerDto.setServerId(serverId);
        if ("".equals(nodeSynchronizerDto.getServerId())) {
            nodeSynchronizerDto.setServerId(serverId);
        }

        if (nodeId.equals(nodeSynchronizerDto.getId())) {
            NodeDefine nodeDefine = new NodeDefine();
            BeanUtils.copyProperties(nodeSynchronizerDto, nodeDefine);
            nodeDefineMapper.updateByPrimaryKeySelective(nodeDefine);

            NodeSynchronizerProperty property = new NodeSynchronizerProperty();
            BeanUtils.copyProperties(nodeSynchronizerDto, property);
            property.setModifyFlag(Constants.MODIFIED_FLAG);
            return nodeSynchronizerPropertyMapper.updateByPrimaryKeySelective(property);
        } else {
            delete(serverId, nodeId);
            return create(nodeSynchronizerDto);
        }
    }

    public int delete(Integer serverId, Integer nodeId) {
        nodeDefineMapper.deleteByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));
        return nodeSynchronizerPropertyMapper.deleteByPrimaryKey(NodeUtil.nodeSynchronizerPropertyKey(serverId, nodeId));
    }

    public NodeSynchronizerDto get(Integer serverId, Integer nodeId) {
        NodeSynchronizerProperty nodeSynchronizerProperty = nodeSynchronizerPropertyMapper.selectByPrimaryKey(
                NodeUtil.nodeSynchronizerPropertyKey(serverId, nodeId));
        NodeDefine nodeDefine = nodeDefineMapper.selectByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));

        NodeSynchronizerDto nodeSynchronizerDto = new NodeSynchronizerDto();
        BeanUtils.copyProperties(nodeSynchronizerProperty, nodeSynchronizerDto);
        BeanUtils.copyProperties(nodeDefine, nodeSynchronizerDto);
        return nodeSynchronizerDto;
    }
}
