package com.bozhilin.buildingrobot.trackingpositioning.node.component;

import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.SerializationException;
import org.springframework.lang.Nullable;

/**
 * Bytes Redis serializer
 * @author chenang on 2019/7/28
 */
public class ByteRedisSerializer implements RedisSerializer<byte[]> {

    public ByteRedisSerializer() {

    }

    @Override
    public byte[] deserialize(@Nullable byte[] bytes) throws SerializationException {
        return bytes;
    }

    @Override
    public byte[] serialize(@Nullable byte[] bytes) throws SerializationException {
        return bytes;
    }
}
