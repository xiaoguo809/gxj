package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeBasestationPropertyMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeDefineMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestationProperty;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefine;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeBasestationDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeBasestationService;
import com.bozhilin.buildingrobot.trackingpositioning.node.util.NodeUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeBasestationServiceImpl implements NodeBasestationService {
    @Autowired
    private NodeDefineMapper nodeDefineMapper;

    @Autowired
    private NodeBasestationPropertyMapper nodeBasestationPropertyMapper;

    public int create(NodeBasestationDto nodeBasestationDto) {
        NodeDefine nodeDefine = new NodeDefine();
        BeanUtils.copyProperties(nodeBasestationDto, nodeDefine);
        nodeDefine.setCreateTime(new Date());
        nodeDefine.setModifyTime(nodeDefine.getCreateTime());
        //nodeDefine.setCategoryId(3L);
        nodeDefine.setState(1);
        nodeDefineMapper.insertSelective(nodeDefine);
        return nodeBasestationPropertyMapper.insertSelective(nodeBasestationDto);
    }

    public int update(Integer serverId, Integer nodeId, NodeBasestationDto nodeBasestationDto) {
        nodeBasestationDto.setServerId(serverId);
        if ("".equals(nodeBasestationDto.getServerId())) {
            nodeBasestationDto.setServerId(serverId);
        }

        if (nodeId.equals(nodeBasestationDto.getId())) {
            NodeDefine nodeDefine = new NodeDefine();
            BeanUtils.copyProperties(nodeBasestationDto, nodeDefine);
            nodeDefine.setModifyTime(new Date());
            nodeDefineMapper.updateByPrimaryKeySelective(nodeDefine);
            return nodeBasestationPropertyMapper.updateByPrimaryKeySelective(nodeBasestationDto);
        } else {
            delete(serverId, nodeId);
            return create(nodeBasestationDto);
        }
    }

    public int delete(Integer serverId, Integer nodeId) {
        nodeDefineMapper.deleteByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));
        return nodeBasestationPropertyMapper.deleteByPrimaryKey(NodeUtil.nodeBasestationPropertyKey(serverId, nodeId));
    }

    public NodeBasestationDto get(Integer serverId, Integer nodeId) {
        NodeBasestationProperty nodeBasestationProperty = nodeBasestationPropertyMapper.selectByPrimaryKey(
                NodeUtil.nodeBasestationPropertyKey(serverId, nodeId));
        NodeDefine nodeDefine = nodeDefineMapper.selectByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));

        NodeBasestationDto nodeBasestationDto = new NodeBasestationDto();
        BeanUtils.copyProperties(nodeBasestationProperty, nodeBasestationDto);
        BeanUtils.copyProperties(nodeDefine, nodeBasestationDto);
        return nodeBasestationDto;
    }
}
