package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper.PositionDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.PositionDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.PositionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: pengjunming
 * @Date:2019/9/26 9:45
 * @Description:
 */
@Service
@Slf4j
public class PositionServiceImpl implements PositionService {

    @Autowired
    private PositionDao positionDao;

    @Override
    public List<PositionDTO> listPositions(List<String> ids) {
        log.debug("List position of tag:[{}]", JSON.toJSONString(ids));
        return positionDao.listRecentlyPositions(ids);
    }
}
