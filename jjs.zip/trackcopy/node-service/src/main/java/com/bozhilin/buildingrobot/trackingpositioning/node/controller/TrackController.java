package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.DateUtil;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.TrackQueryParam;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.TrackService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 轨迹接口
 * Created by TanJY on 2019/8/15.
 */
@Controller
@Api(tags = "TrackController", description = "轨迹查询接口")
@RequestMapping("/track")
public class TrackController {

    @Autowired
    private TrackService trackService;

    @ApiOperation(value = "轨迹查询接口")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult<List> list(@RequestBody TrackQueryParam trackQueryParam) {
        if (trackQueryParam.getStartTime() == null || trackQueryParam.getEndTime() == null) {
            trackQueryParam.setStartTime(DateUtil.getNowDate());
            trackQueryParam.setEndTime(DateUtil.addDays(trackQueryParam.getStartTime(), 1));
        }
        List<TagTrackDTO> list = trackService.listTagTrack(trackQueryParam);
        return CommonResult.success(list);
    }
}
