package com.bozhilin.buildingrobot.trackingpositioning.node.redis.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @Author lupeihui
 * @Date 2019/9/26 14:30
 * @Description 上行消息配置类
 **/
@Configuration
@Slf4j
public class UpMessageListenerConfig {

    @Value("${redis.up.topic}")
    private String topic;

    @Autowired
    private RedisMessageThreadPoolConfig poolConfig;


    @Bean
    public RedisMessageListenerContainer upMessageContainer(RedisConnectionFactory factory, MessageListenerAdapter upMessageListenerAdapter) {
        RedisMessageListenerContainer upMessageContainer = new RedisMessageListenerContainer();
        ThreadPoolExecutor executor =
                new ThreadPoolExecutor(poolConfig.getCorePoolSize(), poolConfig.getMaximumPoolSize(),
                        poolConfig.getKeepAliveTime(), TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        upMessageContainer.setConnectionFactory(factory);
        upMessageContainer.setTaskExecutor(executor);
        upMessageContainer.addMessageListener(upMessageListenerAdapter, new PatternTopic(topic));
        return upMessageContainer;
    }

    @Bean
    public MessageListenerAdapter upMessageListenerAdapter(StringRedisTemplate redisTemplate) {
        return new MessageListenerAdapter(new UpMessageListener(redisTemplate));
    }

    /**
     * @Author lupehui
     * @Date 2019/9/26 14:55
     * @Description 上行消息监听类
     **/
    public static class UpMessageListener extends com.bozhilin.buildingrobot.trackingpositioning.node.redis.listener.UpMessageListener {

        private final StringRedisTemplate redisTemplate;

        public UpMessageListener(StringRedisTemplate redisTemplate) {
            this.redisTemplate = redisTemplate;
        }

        @Override
        protected void handleMessage(String upMessage) {
            redisTemplate.opsForList().rightPush("upMessage", upMessage);
        }
    }
}
