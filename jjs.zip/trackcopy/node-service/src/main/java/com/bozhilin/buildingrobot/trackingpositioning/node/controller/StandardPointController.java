package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.StandardPoint;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.StandardPointService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: pengjunming
 * @Date:2019/8/31 10:50
 * @Description: 基准点相关接口
 */
@Slf4j
@Api(tags = "StandardPointController", description = "基准点接口")
@RestController
@RequestMapping("/standard-point")
public class StandardPointController {

    @Autowired
    private StandardPointService standardPointService;

    @ApiOperation(value = "保存基准点")
    @PostMapping
    public CommonResult<StandardPoint> save(@RequestBody StandardPoint standardPoint) {
        standardPointService.save(standardPoint);
        return CommonResult.success(null);
    }

    @ApiOperation(value = "更新基准点")
    @PatchMapping
    public CommonResult<StandardPoint> update(@RequestBody StandardPoint standardPoint) {
        standardPointService.update(standardPoint);
        return CommonResult.success(null);
    }

    @ApiOperation(value = "删除基准点")
    @DeleteMapping("/{areaCode}")
    public CommonResult<StandardPoint> delete(@PathVariable("areaCode") String areaCode) {
        standardPointService.delete(areaCode);
        return CommonResult.success(null);
    }

    @ApiOperation(value = "删除基准点")
    @GetMapping("/{areaCode}")
    public CommonResult<StandardPoint> find(@PathVariable("areaCode") String areaCode) {
        return CommonResult.success(standardPointService.find(areaCode));
    }
}
