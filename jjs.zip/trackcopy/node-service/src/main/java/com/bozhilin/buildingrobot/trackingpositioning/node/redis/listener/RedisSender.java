package com.bozhilin.buildingrobot.trackingpositioning.node.redis.listener;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;

@Service
public class RedisSender {

    @Value("${redis.down.topic}")
    private String downMsgTopic;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    //向通道发送消息的方法
    public void sendChannelMess(String message) {
        stringRedisTemplate.convertAndSend(downMsgTopic, message);
    }
}
