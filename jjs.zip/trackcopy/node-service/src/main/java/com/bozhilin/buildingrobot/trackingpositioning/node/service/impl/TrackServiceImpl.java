package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.util.ListUtil;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper.TrackDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointSimpleDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.TrackQueryParam;
import com.bozhilin.buildingrobot.trackingpositioning.node.queue.TrackRealTimeSaveQueue;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.TrackService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/**
 * 轨迹服务实现类
 * Create by TanJY on 2019/8/15
 */
@Slf4j
@Service
public class TrackServiceImpl implements TrackService {
    @Autowired
    private TrackDao trackDao;

    @Autowired
    private TrackRealTimeSaveQueue trackRealTimeSaveQueue;

    @Override
    public List<TagTrackDTO> listTagTrack(TrackQueryParam trackQueryParam) {
        String[] ids = trackQueryParam.getTagidList().split(",");
        List<String> idList = new ArrayList<>();
        for (String id : ids) {
            if (!StringUtil.isEmpty(id)) {
                idList.add(id);
            }
        }
        if (ListUtil.isNotNull(idList)) {
            List<TagTrackPointDTO> pointList = trackDao.listTagTrack(trackQueryParam.getStartTime(), trackQueryParam.getEndTime(),
                    trackQueryParam.getPostionAccuracy(), idList);
            if (ListUtil.isNotNull(pointList)) {
                pointList.sort(Comparator.comparing(o -> o.getTime()));
                /* 最多只取100个点
                 * 1. 按开始时间和结束时间等分100个时间区间，按顺序生成各个时间区间对应的坐标，每个时间区间取第一个坐标
                 * 2. 如果第一个时间取不到坐标，则取开始时间以前的前一个坐标
                 * 3. 除了第一个时间时区以外的任何区间，如果在区间范围内找不到坐标，则取前一个时间区间的坐标
                 */
                Map<String, List<TagTrackPointDTO>> tagTrackMap = convertToTagTrackMap(pointList);
                tagTrackMap.forEach((tagCode, trackList) -> {
                    if (trackList.size() > 100) {
                        List<TagTrackPointDTO> resultList = new ArrayList<>(100);
                        BigDecimal endTime = new BigDecimal(trackQueryParam.getEndTime().getTime());
                        BigDecimal startTime = new BigDecimal(trackQueryParam.getStartTime().getTime());
                        BigDecimal interval = endTime.subtract(startTime).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
                        BigDecimal nextTime = startTime.add(interval);
                        while (startTime.compareTo(endTime)<0) {
                            Iterator<TagTrackPointDTO> it = trackList.iterator();
                            boolean hasValue = false;
                            while(it.hasNext()){
                                TagTrackPointDTO tagTrackPointDTO = it.next();
                                BigDecimal thisTime = new BigDecimal(tagTrackPointDTO.getTime().getTime());
                                if (thisTime.compareTo(startTime) < 0){
                                    it.remove();
                                } else if (thisTime.compareTo(startTime) >= 0 && thisTime.compareTo(nextTime) < 0) {
                                    tagTrackPointDTO.setTime(new Date(startTime.longValue()));
                                    resultList.add(tagTrackPointDTO);
                                    hasValue = true;
                                    it.remove();
                                    break;
                                } else {
                                    break;
                                }
                            }
                            if (!hasValue) {
                                if (resultList.size() == 0) {
                                    TagTrackPointDTO point = trackDao.getLastTrack(trackQueryParam.getStartTime(), trackQueryParam.getEndTime(),
                                            trackQueryParam.getPostionAccuracy(), tagCode);
                                    if (point != null) {
                                        point.setTime(new Date(startTime.longValue()));
                                        resultList.add(point);
                                    } else {
                                        TagTrackPointDTO zero = new TagTrackPointDTO();
                                        zero.setTime(new Date(startTime.longValue()));
                                        zero.setTagCode(tagCode);
                                        zero.setX(BigDecimal.ZERO);
                                        zero.setY(BigDecimal.ZERO);
                                        zero.setZ(BigDecimal.ZERO);
                                        resultList.add(zero);
                                    }

                                } else {
                                    TagTrackPointDTO copy = new TagTrackPointDTO();
                                    BeanUtils.copyProperties(resultList.get(resultList.size()-1), copy);
                                    copy.setTime(new Date(startTime.longValue()));
                                    resultList.add(copy);
                                }
                            }
                            startTime = nextTime;
                            nextTime = nextTime.add(interval);
                        }
                        if (trackList.size() > 0) {
                            resultList.add(trackList.get(trackList.size() - 1));
                        }
                        tagTrackMap.put(tagCode, resultList);
                    }
                });
                return convertToTagTrackDto(tagTrackMap);
            }
        }
        return null;
    }

    @Override
    public void saveTagTrack(TagTrackPointDTO tagTrackPointDTO) {
//        log.debug("saveTagTrack传入参数：{}", tagTrackPointDTO.getTagCode());
        try {
            trackRealTimeSaveQueue.getQueue().put(tagTrackPointDTO);
        } catch (InterruptedException e) {
            log.error("保存轨迹实时数据，加入任务列表时出错：", e);
        }
    }

    private Map<String, List<TagTrackPointDTO>> convertToTagTrackMap(List<TagTrackPointDTO> pointList) {
        Map<String, List<TagTrackPointDTO>> tagTrackMap = new HashMap<>();
        if (pointList == null || pointList.size() == 0) {
            return tagTrackMap;
        }
        for (TagTrackPointDTO tagTrackPointDto : pointList) {
            if (tagTrackMap.containsKey(tagTrackPointDto.getTagCode())) {
                tagTrackMap.get(tagTrackPointDto.getTagCode()).add(tagTrackPointDto);
            } else {
                List<TagTrackPointDTO> dtoList = new ArrayList<>();
                dtoList.add(tagTrackPointDto);
                tagTrackMap.put(tagTrackPointDto.getTagCode(), dtoList);
            }
        }
        tagTrackMap.forEach((k, v) -> {
            v.sort(Comparator.comparing(o -> o.getTime()));
        });
        return tagTrackMap;
    }

    private List<TagTrackDTO> convertToTagTrackDto(Map<String, List<TagTrackPointDTO>> tagTrackMap) {
        List<TagTrackDTO> resultList = new ArrayList<>();
        if (tagTrackMap != null) {
            tagTrackMap.forEach((k,v)->{
                List<TagTrackPointSimpleDTO> simpleDTOList = new ArrayList<>();
                for (TagTrackPointDTO tagTrackPointDTO : v) {
                    TagTrackPointSimpleDTO tagTrackPointSimpleDto = new TagTrackPointSimpleDTO();
                    tagTrackPointSimpleDto.setTime(tagTrackPointDTO.getTime());
                    tagTrackPointSimpleDto.setX(tagTrackPointDTO.getX());
                    tagTrackPointSimpleDto.setY(tagTrackPointDTO.getY());
                    tagTrackPointSimpleDto.setZ(tagTrackPointDTO.getZ());
                    simpleDTOList.add(tagTrackPointSimpleDto);
                }
                TagTrackDTO tagTrackDto = new TagTrackDTO();
                tagTrackDto.setTagCode(k);
                tagTrackDto.setPositionList(simpleDTOList);
                resultList.add(tagTrackDto);
            });
        }
        return resultList;
    }
}
