package com.bozhilin.buildingrobot.trackingpositioning.node.util;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestationPropertyKey;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefineKey;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeLabelPropertyKey;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeSynchronizerPropertyKey;

public class NodeUtil {

    public static NodeDefineKey nodeDefineKey(Integer serverId, Integer id) {
        NodeDefineKey key = new NodeDefineKey();
        key.setServerId(serverId);
        key.setId(id);
        return key;
    }

    public static NodeSynchronizerPropertyKey nodeSynchronizerPropertyKey(Integer serverId, Integer id) {
        NodeSynchronizerPropertyKey key = new NodeSynchronizerPropertyKey();
        key.setServerId(serverId);
        key.setId(id);
        return key;
    }

    public static NodeBasestationPropertyKey nodeBasestationPropertyKey(Integer serverId, Integer id) {
        NodeBasestationPropertyKey key = new NodeBasestationPropertyKey();
        key.setServerId(serverId);
        key.setId(id);
        return key;
    }

    public static NodeLabelPropertyKey nodeLabelPropertyKey(Integer serverId, Integer id) {
        NodeLabelPropertyKey key = new NodeLabelPropertyKey();
        key.setServerId(serverId);
        key.setId(id);
        return key;
    }
}
