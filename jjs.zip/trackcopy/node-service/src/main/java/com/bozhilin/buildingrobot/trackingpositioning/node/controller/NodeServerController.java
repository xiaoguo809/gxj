package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeServerDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeServerService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 服务器管理Controller
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeServerController", description = "服务器管理")
@RestController
@RequestMapping("/server")
@Slf4j
public class NodeServerController {

    @Autowired
    private NodeServerService nodeServerService;

    @ApiOperation("添加服务器")
    @PostMapping(value = "/create")
    public CommonResult create(@RequestBody NodeServerDto nodeServerDto) {
        CommonResult commonResult;
        int count = nodeServerService.create(nodeServerDto);
        if (count == 1) {
            commonResult = CommonResult.success(nodeServerDto);
            log.debug("create node server success:{}", nodeServerDto);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node server failed:{}", nodeServerDto);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id服务器信息")
    @PostMapping(value = "/update")
    public CommonResult update(@RequestParam("serverId") Integer serverId,
                               @RequestBody NodeServerDto nodeServerDto) {
        CommonResult commonResult;
        int count = nodeServerService.update(serverId, nodeServerDto);
        if (count == 1) {
            commonResult = CommonResult.success(nodeServerDto);
            log.debug("update node server success:{}", nodeServerDto);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node server failed:{}", nodeServerDto);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的服务器")
    @GetMapping(value = "/delete")
    public CommonResult delete(@RequestParam("serverId") Integer serverId) {
        int count = nodeServerService.delete(serverId);
        if (count == 1) {
            log.debug("delete node server success: serverId={}", serverId);
            return CommonResult.success(null);
        } else {
            log.debug("delete node server failed: serverId={}", serverId);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("获取指定id的服务器详情")
    @GetMapping(value = "/get")
    public CommonResult<NodeServerDto> get(@RequestParam("serverId") Integer serverId) {
        return CommonResult.success(nodeServerService.get(serverId));
    }
}
