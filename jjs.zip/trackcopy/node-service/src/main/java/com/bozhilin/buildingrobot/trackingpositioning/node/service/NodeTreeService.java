package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTree;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTreeKey;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeTreeDto;

import java.util.List;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
public interface NodeTreeService {
    List<NodeTree> listAll(Integer serverId);

    int create(NodeTree nodeTree);

    int update(Integer serverId, Integer nodeId, NodeTree nodeTree) ;

    int delete(NodeTreeKey nodeTreeKey);

    List<NodeTree> list(int pageNum, int pageSize);

    NodeTree get(NodeTreeKey nodeTreeKey);

    NodeTreeDto getChildrens(Integer serverId, Integer nodeId) throws Exception;
}
