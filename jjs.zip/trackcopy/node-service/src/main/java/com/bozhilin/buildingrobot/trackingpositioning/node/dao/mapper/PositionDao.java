package com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.PositionDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface PositionDao {

    /**
     * 查询最近的位置信息
     * @param tagCodes
     * @return
     */
    List<PositionDTO> listRecentlyPositions(@Param("tagCodes") List<String> tagCodes);
}
