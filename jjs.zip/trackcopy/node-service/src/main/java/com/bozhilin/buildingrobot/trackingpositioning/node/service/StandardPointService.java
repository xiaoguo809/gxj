package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.StandardPoint;

/**
 * @Author pengjunming
 * @Date  2019/8/31 11:13
 * @Description 基准点服务接口
 **/
public interface StandardPointService {

    /**
     * 保存基准点记录
     * @param standardPoint
     * longitude,latitude,areaCode都不能为空
     */
    void save(StandardPoint standardPoint);

    /**
     * 更新基准点记录
     * @param updatedRecord
     * longitude,latitude,areaCode都不能为空
     */
    void update(StandardPoint updatedRecord);

    /**
     * 删除基准点记录
     * @param areaCode
     */
    void delete(String areaCode);

    /**
     * 查找基准点记录
     * @param areaCode
     */
    StandardPoint find(String areaCode);
}
