package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;/**
 * @author :  pengjunming
 * @date :   11:16
 */

import com.bozhilin.buildingrobot.trackingpositioning.common.model.ResultCode;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.ServiceException;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.StandardPoint;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper.StandardPointDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.StandardPointService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: pengjunming
 * @Date:2019/8/31 11:16
 * @Description:
 */
@Service
@Slf4j
public class StandardPointServiceImpl implements StandardPointService {

    private StandardPointDao dao;

    @Autowired
    public StandardPointServiceImpl(StandardPointDao dao) {
        this.dao = dao;
    }

    @Override
    public void save(StandardPoint standardPoint) {
        if (standardPoint == null || !standardPoint.isValid()) {
            log.error("Invalid StandardPoint [{}].", standardPoint);
            throw new ServiceException(ResultCode.VALIDATE_FAILED);
        }
        StandardPoint existsRecord = dao.findByAreaCode(standardPoint.getAreaCode());
        if (existsRecord != null) {
            log.error("StandardPoint [{}] already exists.", standardPoint.getAreaCode());
            throw new ServiceException(ResultCode.RECORD_ALREADY_EXISTS);
        }
        dao.save(standardPoint);
    }

    @Override
    public void update(StandardPoint standardPoint) {
        if (standardPoint == null || !standardPoint.isValid()) {
            log.error("Invalid StandardPoint [{}].", standardPoint);
            throw new ServiceException(ResultCode.VALIDATE_FAILED);
        }
        int effectRows = dao.update(standardPoint);
        if (effectRows == 0) {
            log.error("StandardPoint [{}] does not exists.", standardPoint.getAreaCode());
            throw new ServiceException(ResultCode.RECORD_NOT_EXISTS);
        }
    }

    @Override
    public void delete(String areaCode) {
        if (StringUtil.isEmpty(areaCode)) {
            log.error("AreaCode [{}] is invalid.", areaCode);
            throw new ServiceException(ResultCode.VALIDATE_FAILED);
        }
        int effectRows = dao.deleteByAreaCode(areaCode);
        if (effectRows == 0) {
            log.error("StandardPoint [{}] does not exists.", areaCode);
            throw new ServiceException(ResultCode.RECORD_NOT_EXISTS);
        }
    }

    @Override
    public StandardPoint find(String areaCode) {
        if (StringUtil.isEmpty(areaCode)) {
            log.error("AreaCode [{}] is invalid.", areaCode);
            throw new ServiceException(ResultCode.VALIDATE_FAILED);
        }
        StandardPoint result = dao.findByAreaCode(areaCode);
        if (result == null) {
            log.error("StandardPoint [{}] does not exists.", areaCode);
            throw new ServiceException(ResultCode.RECORD_NOT_EXISTS);
        }
        return result;
    }

}
