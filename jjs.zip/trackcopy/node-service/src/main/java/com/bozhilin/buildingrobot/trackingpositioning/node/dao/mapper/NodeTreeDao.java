package com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTree;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 后台用户与角色管理自定义Dao
 * Created by chenang on 2019/7/28.
 */
public interface NodeTreeDao {

    /**
     * 获取用于所有角色
     */
    List<NodeTree> queryNodeTree(@Param("nodeId") Integer nodeId);
}
