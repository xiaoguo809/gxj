package com.bozhilin.buildingrobot.trackingpositioning.node.redis.listener;/**
 * @author :  pengjunming
 * @date :   14:55
 */

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @Author: pengjunming
 * @Date:2019/9/16 14:55
 * @Description: redis message工作线程池配置
 */
@Component
@ConfigurationProperties(prefix = "redis.message.thread-pool")
@Data
public class RedisMessageThreadPoolConfig {

    /**
     * 核心线程数
     */
    private int corePoolSize;

    /**
     * 最大线程数
     */
    private int maximumPoolSize;

    /**
     * 当最大线程数大于核心线程数时，空闲线程所等待的最大时间，超过keepAliveTime时间则终结多余的线程
     * 单位为秒
     */
    private int keepAliveTime;

}
