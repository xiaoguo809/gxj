package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatistics;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeStatisticsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

/**
 * 节点统计信息Controller
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeStatisticsController", description = "节点统计")
@RestController
@RequestMapping("/statistics")
@Slf4j
public class NodeStatisticsController {

    @Autowired
    private NodeStatisticsService nodeStatisticsService;

    @ApiOperation("节点业务统计")
    @GetMapping(value = "/list")
    public CommonResult<List<NodeStatistics>> listStatistics(@RequestParam("serverId")
                                                                 @ApiParam("服务器id") Integer serverId,
                                                             @RequestParam("nodeId")
                                                                 @ApiParam("节点id") Integer nodeId,
                                                             @RequestParam("beginDate")
                                                                 @ApiParam("开始日期(yyyy-MM-dd)")
                                                                 @DateTimeFormat(pattern="yyyy-MM-dd") Date beginDate,
                                                             @RequestParam("endDate")
                                                                 @ApiParam("结束日期(yyyy-MM-dd)")
                                                                 @DateTimeFormat(pattern="yyyy-MM-dd") Date endDate)
            throws Exception {
        return CommonResult.success(nodeStatisticsService.listStatistics(serverId, nodeId, beginDate, endDate));
    }
}
