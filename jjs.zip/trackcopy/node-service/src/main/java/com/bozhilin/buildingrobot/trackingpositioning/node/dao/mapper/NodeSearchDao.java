package com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.SearchNodeByKeyDto;

import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 后台用户与角色管理自定义Dao Created by chenang on 2019/7/28.
 */
public interface NodeSearchDao {

    /**
     * 获取用于所有角色
     */
    List<SearchNodeByKeyDto> queryBasestationsByKey(@Param("key") String key, @Param("serverId") String serverId);

    /**
     * 获取用于所有角色
     */
    List<SearchNodeByKeyDto> queryLabelsByKey(@Param("key") String key, @Param("carrierIdList") List<String> carrierIdList,
                                              @Param("serverId") String serverId);
}
