package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatistics;

import java.util.Date;
import java.util.List;

/**
 * NodeStatisticsService
 * Created by chenang on 2019/7/28
 */
public interface NodeStatisticsService {

    List<NodeStatistics> listStatistics(Integer serverId, Integer nodeId, Date beginDate, Date endDate) throws Exception;

}
