package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconData;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconDataExample;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.IconDataDto;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * author guoxujie
 * date 2019/08/15
 */
public interface IconService {
    List<IconData> getIcon(IconDataExample example);

    IconData getIconByPrimaryKey(Long id);

    int deleteIcon(Long iconId);

    int updateIcon(Map iconMap);

    int addIcon(IconData icon);

    long addIconFromMultipartFile(MultipartFile file);

    //返回生成文件的二进制数组
    IconDataDto getIconById(long id);

    List<IconData> getIconList();
}
