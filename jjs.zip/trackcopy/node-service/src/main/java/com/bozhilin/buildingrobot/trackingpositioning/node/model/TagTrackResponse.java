package com.bozhilin.buildingrobot.trackingpositioning.node.model;/**
 * @author :  pengjunming
 * @date :   15:14
 */

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSum;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 *@Author: pengjunming
 *@Date:2019/8/22 15:14
 *@Description: 实时轨迹响应报文
 *
 */
@Data
public class TagTrackResponse {

    private String id;

    private Position position;

    public TagTrackResponse(TrackSum trackSum){
        this.id = trackSum.getNodeCode();
        this.position = fromFullCoordinate(trackSum.getCoordinate());
    }

    @Data
    @AllArgsConstructor
    public static class Position {
        // 层数
        private int number;
        private String x;
        private String y;
    }

    /**
     * @Author pengjunming
     * @Description 从"22.12,33.12,52.16" 从解析出x和y坐标
     * @Date  2019/8/22 15:24
     **/
    private Position fromFullCoordinate(String coordinate){
        String[] coordinateArr = coordinate.split(",");
        // TODO 暂固定为1层,后续需要根据Z来计算层数
        return new Position(1, coordinateArr[0], coordinateArr[1]);
    }
}
