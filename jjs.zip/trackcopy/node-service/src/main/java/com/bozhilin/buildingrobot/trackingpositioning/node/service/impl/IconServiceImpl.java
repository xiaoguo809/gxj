package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.IconDataMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.IconFileDataMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconData;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconDataExample;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconFileData;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.IconDataDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.IconService;
import io.swagger.annotations.Api;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * author guoxujie
 * date 2019/08/16
 */
@Api(tags = "IconServiceImpl")
@Service
public class IconServiceImpl implements IconService {

    @Autowired
    IconFileDataMapper iconFileDataMapper;

    @Autowired
    IconDataMapper iconDataMapper;

    @Override
    public List<IconData> getIcon(IconDataExample example) {
        return iconDataMapper.selectByExample(example);
    }

    @Override
    public IconData getIconByPrimaryKey(Long id) {
        return iconDataMapper.selectByPrimaryKey(id);
    }


    @Override
    public int deleteIcon(Long iconId) {
        IconData iconData = iconDataMapper.selectByPrimaryKey(iconId);
        //有级联删除的约束所以只用删除文件会自动关联删除,删除了事务控制
        return iconFileDataMapper.deleteByPrimaryKey(iconData.getIconFileId());
//        return iconDataMapper.deleteByPrimaryKey(iconId);
    }

    @Override
    public int updateIcon(Map params) {
        return 0;
    }

    @Transactional
    @Override
    public int addIcon(IconData icon) {
        IconFileData iconFile = new IconFileData();
        iconFile.setName("样例待添加属性");
        Long iconFileId = (long) iconFileDataMapper.insert(iconFile);
        icon.setIconFileId(iconFileId);
        return iconDataMapper.insert(icon);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @Override
    public long addIconFromMultipartFile(MultipartFile file) {
        try {
            //1 就是啥也不是，因为该字段被要被更新,但是暂时不方便修改SQL
            final int ICON_TYPE = 1;
            IconFileData iconFile = this.getIconFile(file);
            iconFileDataMapper.insert(iconFile);
            long id = iconFile.getId();
            IconData icon = new IconData();
            icon.setIconFileId(id);
            //经过与梁工讨论，图片单独放置不耦合任何信息,
            icon.setIconType(ICON_TYPE);
            icon.setIconFileType(this.getIconType(file.getOriginalFilename()));
            icon.setName(file.getOriginalFilename());
            icon.setSize((int) file.getSize());
            long rsCode = iconDataMapper.insert(icon);
            System.out.println("执行成功");
            return rsCode > 0 ? icon.getId() : -1;
        } catch (IOException e) {
            //dosomething
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public IconDataDto getIconById(long id) {
        IconDataExample iconDataExample = new IconDataExample();
        IconDataExample.Criteria criteria = iconDataExample.createCriteria();
        criteria.andIdEqualTo(id);
        List<IconData> list = iconDataMapper.selectByExample(iconDataExample);
        if (list.size()<1){
            return null;
        }
        IconData icon = list.get(0);
        IconFileData file = iconFileDataMapper.selectByPrimaryKey(icon.getIconFileId());
        byte[] b = file.getFileInfo();
        IconDataDto iconDto = new IconDataDto();
        iconDto.setBytesData(b);
        BeanUtils.copyProperties(icon, iconDto);
        return iconDto;
    }

    @Override
    public List<IconData> getIconList() {
        IconDataExample iconDataExample = new IconDataExample();
//        IconDataExample.Criteria criteria = iconDataExample.createCriteria();
        return iconDataMapper.selectByExample(iconDataExample);
    }

    private IconFileData getIconFile(MultipartFile file) throws IOException {
        IconFileData iconFile = new IconFileData();
        String name = file.getOriginalFilename();
        byte[] s = file.getBytes();
        iconFile.setName(name);
        iconFile.setFileInfo(s);
        return iconFile;
    }

    private String getIconType(String name) {
        int idx = name.lastIndexOf(".");
        String iconType = name.substring(idx + 1);
        return iconType;
    }

}
