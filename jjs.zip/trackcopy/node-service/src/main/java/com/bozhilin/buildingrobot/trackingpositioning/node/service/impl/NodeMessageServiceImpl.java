package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeMessageMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessage;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessageExample;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeMessageService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * NodeMessageService实现类
 * Created by yutingyang on 2019/9/27
 */
@Service
public class NodeMessageServiceImpl implements NodeMessageService {

    @Autowired
    private NodeMessageMapper nodeMessageMapper;

    @Override
    public List<NodeMessage> listAll() {
        return nodeMessageMapper.selectByExample(new NodeMessageExample());
    }

    @Override
    public int create(NodeMessage nodeCommand) {
        return nodeMessageMapper.insertSelective(nodeCommand);
    }

    @Override
    public int update(Long id, NodeMessage nodeCommand) {
        if ("".equals(nodeCommand.getId())) {
            nodeCommand.setId(id);
        }

        if (id.equals(nodeCommand.getId())) {
            return nodeMessageMapper.updateByPrimaryKeySelective(nodeCommand);
        } else {
            delete(id);
            return create(nodeCommand);
        }
    }

    @Override
    public int delete(Long id) {
        return nodeMessageMapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<NodeMessage> list(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        nodeMessageMapper.selectByExample(new NodeMessageExample());
        return nodeMessageMapper.selectByExample(new NodeMessageExample());
    }

    @Override
    public NodeMessage get(Long id) {
        return nodeMessageMapper.selectByPrimaryKey(id);
    }
}
