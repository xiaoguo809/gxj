package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCategory;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
public interface NodeCategoryService {
    List<NodeCategory> listAll();

    int create(NodeCategory nodeCategory);

    @Transactional
    int update(Integer id, NodeCategory nodeCategory);

    int delete(Integer id);

    List<NodeCategory> list(int pageNum, int pageSize);

    NodeCategory get(Integer id);
}
