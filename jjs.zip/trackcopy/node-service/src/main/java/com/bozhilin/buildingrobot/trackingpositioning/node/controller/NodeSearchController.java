package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.SearchNodeByKeyDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeSearchService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 节点搜索Controller
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeSearchController", description = "节点搜索")
@RestController
@RequestMapping("/search")
@Slf4j
public class NodeSearchController {

    @Autowired
    private NodeSearchService nodeSearchService;

    @ApiOperation("根据关键字查询节点")
    @GetMapping(value = "/key")
    public CommonResult<List<SearchNodeByKeyDto>> searchNodeByKey(@RequestParam(value="key", required = false)
                                                                      @ApiParam("关键字") String key,
                                                                  @RequestParam(value = "isSearchBasestation", required = false)
                                                                      @ApiParam("是否搜索基站") String isSearchBasestation,
                                                                  @RequestParam(value = "carrierIds", required = false)
                                                                      @ApiParam("载体列表(以,分割)") String carrierIds,
                                                                  @RequestParam(value = "serverId", required = false)
                                                                      @ApiParam("服务器Id") String serverId) throws Exception {
        return CommonResult.success(nodeSearchService.searchNodeByKey(key, isSearchBasestation, carrierIds, serverId));
    }
}
