package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconData;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IconDataDto extends IconData {
    @ApiModelProperty(value = "文件的二进制数据")
    private byte[] bytesData;
}
