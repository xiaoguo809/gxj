package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.NodeBasestationDto;
import org.springframework.transaction.annotation.Transactional;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
public interface NodeBasestationService {
    @Transactional
    int create(NodeBasestationDto nodeBasestationDto);

    @Transactional
    int update(Integer serverId, Integer nodeId, NodeBasestationDto nodeBasestationDto);

    @Transactional
    int delete(Integer serverId, Integer nodeId);

    NodeBasestationDto get(Integer serverId, Integer nodeId);
}
