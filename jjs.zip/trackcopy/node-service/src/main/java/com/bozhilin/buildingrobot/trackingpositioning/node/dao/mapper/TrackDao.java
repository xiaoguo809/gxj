package com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackMerge;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumCm;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumDm;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSumM;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointDTO;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * 轨迹DAO
 * Create by TanJY on 2019/8/16 0016
 */
public interface TrackDao {
    List<TagTrackPointDTO> listTagTrack(@Param("startTime") Date startTime, @Param("endTime") Date endTime,
                                        @Param("postionAccuracy") String postionAccuracy, @Param("tagidList") List<String> tagidList);

    TagTrackPointDTO getLastTrack(@Param("startTime") Date startTime, @Param("endTime") Date endTime,
                                  @Param("postionAccuracy") String postionAccuracy, @Param("tagCode") String tagCode);

    void saveTrackMerge(@Param("trackMergeList") List<TrackMerge> trackMergeList);

    void saveTrackSumCm(@Param("trackSumCmList") List<TrackSumCm> trackSumCmList);

    void saveTrackSumDm(@Param("trackSumDmList") List<TrackSumDm> trackSumCmList);

    void saveTrackSumM(@Param("trackSumMList") List<TrackSumM> trackSumCmList);


}
