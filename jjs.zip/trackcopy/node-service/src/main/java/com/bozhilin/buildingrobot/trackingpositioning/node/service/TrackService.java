package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.TrackQueryParam;

import java.util.List;

/**
 * 轨迹服务
 * Create by TanJY on 2019/8/15
 */
public interface TrackService {

    /**
     * 查询标签轨迹列表
     * @Author TanJY
     * @CreateTime 2019/8/16 20:05
     */
    List<TagTrackDTO> listTagTrack(TrackQueryParam trackQueryParam);

    /**
     * 保存标签轨迹（异步保存至Redis, 然后合并保存至MYSQL数据库）
     * @Author TanJY
     * @CreateTime 2019/8/16 20:06
     */
    void saveTagTrack(TagTrackPointDTO tagTrackPointDTO);

}
