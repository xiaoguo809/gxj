package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefine;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * NodeDefineService
 * Created by chenang on 2019/7/28
 */
public interface NodeDefineService {
    List<NodeDefine> listAll(Integer serverId);

    int create(NodeDefine nodeDefine);

    @Transactional
    int update(Integer serverId, Integer nodeId, NodeDefine nodeDefine);

    int delete(Integer serverId, Integer nodeId);

    List<NodeDefine> list(int pageNum, int pageSize);

    NodeDefine get(Integer serverId, Integer nodeId);

    List<NodeDefine> search(String key);
}
