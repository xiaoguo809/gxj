package com.bozhilin.buildingrobot.trackingpositioning.node.repository;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeTree;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
//import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * ES操作类
 * Created by chenang on 2019/7/28.
 */
public interface NodeElasticSearchRepository //extends ElasticsearchRepository<NodeTree, Long>
{
    /**
     * 搜索查询
     *
     * @param name              名称
     * @param subTitle          标题
     * @param keywords          关键字
     * @param page              分页信息
     * @return
     */
    Page<NodeTree> findByNameOrSubTitleOrKeywords(String name, String subTitle, String keywords, Pageable page);

}

