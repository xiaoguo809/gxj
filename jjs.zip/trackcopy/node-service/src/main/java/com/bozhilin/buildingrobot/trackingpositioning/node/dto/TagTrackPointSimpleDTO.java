package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 标签轨迹点
 * Create by TanJY on 2019/8/15
 */

@Getter
@Setter
public class TagTrackPointSimpleDTO implements Serializable {
    private Date time;
    private BigDecimal x;
    private BigDecimal y;
    private BigDecimal z;
}
