package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeStatisticsMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatistics;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeStatisticsExample;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.NodeStatisticsRedisDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeStatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


/**
 * NodeStatisticsService实现类
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeStatisticsServiceImpl implements NodeStatisticsService {

    @Autowired
    private NodeStatisticsMapper nodeStatisticsMapper;

    @Autowired
    private NodeStatisticsRedisDao nodeStatisticsRedisDao;

    @Override
    public List<NodeStatistics> listStatistics(Integer serverId, Integer nodeId, Date beginDate, Date endDate) throws Exception {
        //首先从数据库查询节点统计信息
        NodeStatisticsExample example = new NodeStatisticsExample();
        example.createCriteria().andServerIdEqualTo(serverId).andNodeIdEqualTo(nodeId)
            .andCreateDateGreaterThanOrEqualTo(beginDate).andCreateDateLessThanOrEqualTo(endDate);
        List<NodeStatistics> nodeStatisticsList = nodeStatisticsMapper.selectByExample(example);

        //优先取Redis中的节点统计信息
        Calendar beginCalendar = Calendar.getInstance();
        Calendar endCalendar = Calendar.getInstance();
        beginCalendar.setTime(beginDate);
        endCalendar.setTime(endDate);
        SimpleDateFormat yyymmddFormat = new SimpleDateFormat("yyyyMMdd");
        while (!beginCalendar.after(endCalendar)) {
            String key = "nodeStatistics:" + serverId + ":" + nodeId + ":" + yyymmddFormat.format(beginCalendar.getTime());
            NodeStatistics nodeStatisticsRedis = nodeStatisticsRedisDao.getStatistics(serverId, nodeId, key);
            if (nodeStatisticsRedis != null) {
                NodeStatistics nodeStatisticsLast = nodeStatisticsList.stream().filter(
                        nodeStatistics -> nodeStatistics.getCreateDate().equals(nodeStatisticsRedis.getCreateDate()))
                        .findFirst().orElse(null);
                if (nodeStatisticsLast == null) {
                    nodeStatisticsLast = new NodeStatistics();
                    nodeStatisticsList.add(nodeStatisticsLast);
                }
                nodeStatisticsLast.setServerId(nodeStatisticsRedis.getServerId());
                nodeStatisticsLast.setNodeId(nodeStatisticsRedis.getNodeId());
                nodeStatisticsLast.setCreateDate(nodeStatisticsRedis.getCreateDate()); //"yyyy-MM-dd"
                nodeStatisticsLast.setModifyTime(nodeStatisticsRedis.getModifyTime()); //"yyyy-MM-dd HH:mm:ss"
                nodeStatisticsLast.setUpstreamTraffic(nodeStatisticsRedis.getUpstreamTraffic());
                nodeStatisticsLast.setDownstreamTraffic(nodeStatisticsRedis.getDownstreamTraffic());
                nodeStatisticsLast.setClassAQuantity(nodeStatisticsRedis.getClassAQuantity());
                nodeStatisticsLast.setClassBQuantity(nodeStatisticsRedis.getClassBQuantity());
                nodeStatisticsLast.setClassCQuantity(nodeStatisticsRedis.getClassCQuantity());
            }
            beginCalendar.add(Calendar.DAY_OF_MONTH, 1);
        }
        return nodeStatisticsList;
    }
}
