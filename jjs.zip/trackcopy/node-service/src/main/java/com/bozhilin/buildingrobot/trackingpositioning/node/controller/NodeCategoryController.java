package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonPage;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCategory;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeCategoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 节点分类管理Controller
 * Created by chenang on 2019/7/28
 */
@Api(tags = "NodeCategoryController", description = "节点分类管理")
@Controller
@RequestMapping("/category")
@Slf4j
public class NodeCategoryController {

    @Autowired
    private NodeCategoryService nodeCategoryService;

    @ApiOperation("获取所有节点分类列表")
    @RequestMapping(value = "all", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<NodeCategory>> listAll() {
        return CommonResult.success(nodeCategoryService.listAll());
    }

    @ApiOperation("添加节点分类")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult create(@RequestBody NodeCategory nodeCategory) {
        CommonResult commonResult;
        int count = nodeCategoryService.create(nodeCategory);
        if (count == 1) {
            commonResult = CommonResult.success(nodeCategory);
            log.debug("create node category success:{}", nodeCategory);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("create node category failed:{}", nodeCategory);
        }
        return commonResult;
    }

    @ApiOperation("更新指定id节点分类信息")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult update(@RequestParam("id") Integer id,
                               @RequestBody NodeCategory nodeCategory) {
        CommonResult commonResult;
        int count = nodeCategoryService.update(id, nodeCategory);
        if (count == 1) {
            commonResult = CommonResult.success(nodeCategory);
            log.debug("update node category success:{}", nodeCategory);
        } else {
            commonResult = CommonResult.failed("操作失败");
            log.debug("update node category failed:{}", nodeCategory);
        }
        return commonResult;
    }

    @ApiOperation("删除指定id的节点分类")
    @RequestMapping(value = "/delete", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult delete(@RequestParam("id") Integer id) {
        int count = nodeCategoryService.delete(id);
        if (count == 1) {
            log.debug("delete node category success :id={}", id);
            return CommonResult.success(null);
        } else {
            log.debug("delete node category failed :id={}", id);
            return CommonResult.failed("操作失败");
        }
    }

    @ApiOperation("分页查询节点分类列表")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<CommonPage<NodeCategory>> list(@RequestParam(value = "pageNum", defaultValue = "1")
                                                           @ApiParam("页码") Integer pageNum,
                                                       @RequestParam(value = "pageSize", defaultValue = "10")
                                                           @ApiParam("每页数量") Integer pageSize) {
        List<NodeCategory> NodeList = nodeCategoryService.list(pageNum, pageSize);
        return CommonResult.success(CommonPage.restPage(NodeList));
    }

    @ApiOperation("获取指定id的节点分类详情")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<NodeCategory> get(@RequestParam("id") Integer id) {
        return CommonResult.success(nodeCategoryService.get(id));
    }
}
