package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.IconData;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.IconDataDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.IconEnum;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.IconService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * author guoxujie
 * date 2019/08/16
 */
@Api(tags = "IconController")
@Controller
@RequestMapping(value = "/icon")
@Slf4j
public class IconController {

    @Autowired
    IconService iconService;

    public final int WIDTH = 40;

    public final int HEIGHT = 40;

    @ApiOperation(value = "根据ID获取图标")
    @ResponseBody
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    public void getIconById(long id, HttpServletResponse response) throws IOException {
        // 生成的图片会直接填进response 输出流里面
        IconDataDto icon = iconService.getIconById(id);
        this.FillImageIntoResponse(response, icon.getBytesData(), icon.getIconFileType());
    }

    @ApiOperation(value = "添加图标")
    @ResponseBody
    @RequestMapping(value = "/addIcon", method = RequestMethod.POST)
    public CommonResult addIcon(MultipartFile file, HttpServletResponse response) throws IOException {
        if (file.getSize() > IconEnum.ONE_M.getSize()) {
            //这个地方 也应该用枚举类型的
            return CommonResult.failed("文件太大!");
        }
        long rs = iconService.addIconFromMultipartFile(file);
        if (rs < 0) {
            return CommonResult.failed("添加失败");
        }
        return CommonResult.success(rs);
    }

    @ApiOperation(value = "删除图标")
    @ResponseBody
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public CommonResult deleteById(long iconId) {
        if (iconId < 1) {
            return CommonResult.failed("参数非法");
        }
        IconDataDto icon = iconService.getIconById(iconId);
        if (icon == null) {
            return CommonResult.failed("不存在此条数据");
        }
        int rs = iconService.deleteIcon(iconId);
        if (rs > 0) {
            return CommonResult.success(rs, "执行成功");
        }
        return CommonResult.failed("执行失败");
    }

    @ApiOperation(value = "获取图标列表")
    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public CommonResult getIconList() {
        List<IconData> list = iconService.getIconList();
        return CommonResult.success(list);
    }

    private void FillImageIntoResponse(HttpServletResponse response, byte[] b, String imageType) throws IOException {
        response.setContentType("image/" + imageType);
        OutputStream out = response.getOutputStream();
        out.write(b);
        out.flush();
        out.close();
    }

    @ApiOperation(value = "获取缩略图")
    @ResponseBody
    @RequestMapping(value = "/smaller", method = RequestMethod.GET)
    public void getSmallIcon(long iconId, HttpServletResponse response) throws IOException {

        IconDataDto icondto = iconService.getIconById(iconId);
        String fileType = icondto.getIconFileType();
        InputStream in = new ByteArrayInputStream(icondto.getBytesData());
        Image img = ImageIO.read(in);
        Image tempImg = img.getScaledInstance(WIDTH, HEIGHT, Image.SCALE_SMOOTH);
        if ("jpg".equalsIgnoreCase(fileType) || "jpeg".equalsIgnoreCase(fileType)) {
            this.getJPGImage(tempImg, response, fileType);
        } else {
            this.getNonJPGImage(tempImg,response,fileType);
        }
        in.close();
    }

    private void getJPGImage(Image img, HttpServletResponse response, String fileType) throws IOException {
        BufferedImage rsimg = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics2D = rsimg.createGraphics();
        graphics2D.drawImage(img, 0, 0, null);
        graphics2D.dispose();
        OutputStream out = response.getOutputStream();
        response.setContentType("image/" + fileType);
        ImageIO.write(rsimg, fileType, out);
        out.close();
    }
    private  void getNonJPGImage(Image img,HttpServletResponse response, String fileType) throws IOException{
        BufferedImage rsimg = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics2D = rsimg.createGraphics();
        // 设置“抗锯齿”的属性
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        graphics2D.drawImage(img, 0, 0, null);
        graphics2D.dispose();
        OutputStream out = response.getOutputStream();
        response.setContentType("image/" + fileType);
        ImageIO.write(rsimg, fileType, out);
        out.close();
    }
}
