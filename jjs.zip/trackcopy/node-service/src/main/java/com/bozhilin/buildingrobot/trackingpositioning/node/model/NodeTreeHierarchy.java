package com.bozhilin.buildingrobot.trackingpositioning.node.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class NodeTreeHierarchy {
    @ApiModelProperty(value = "服务器id")
    private Integer serverId;

    @ApiModelProperty(value = "节点id")
    private Integer nodeId;

    @ApiModelProperty(value = "父节点id")
    private Integer parentNodeId;

    @ApiModelProperty(value = "状态：0->失效；1->有效")
    private Integer state;

    @ApiModelProperty(value = "子节点列表")
    private List<NodeTreeHierarchy> childNodeList;
}