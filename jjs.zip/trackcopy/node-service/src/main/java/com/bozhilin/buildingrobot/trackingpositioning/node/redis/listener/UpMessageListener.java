package com.bozhilin.buildingrobot.trackingpositioning.node.redis.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;

/**
 * @Author: lupeihui
 * @Date:2019/9/29 11:20
 * @Description: Redis监听器的基类，
 */
public abstract class UpMessageListener implements MessageListener {

    private static final Logger logger = LoggerFactory.getLogger(UpMessageListener.class);

    @Override
    public void onMessage(Message message, byte[] pattern) {
        handleMessage(new String(message.getBody()));
    }

    /**
     * @Author lupeihui
     * @Description 具体处理消息逻辑
     * @Date 2019/9/29 11:13
     * @Param 待处理的String
     **/
    protected abstract void handleMessage(String t);
}
