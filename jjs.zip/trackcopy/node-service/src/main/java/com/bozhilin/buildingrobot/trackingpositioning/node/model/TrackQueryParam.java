package com.bozhilin.buildingrobot.trackingpositioning.node.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import java.util.Date;

/**
 * 轨迹查询参数
 * Created by TanJY on 2019/8/15.
 */
@Getter
@Setter
public class TrackQueryParam {
    @ApiModelProperty(value = "开始时间", required = true)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date startTime;

    @ApiModelProperty(value = "结束时间", required = true)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date endTime;

    @ApiModelProperty(value = "位置精度")
    private String postionAccuracy = "0.1";

    @ApiModelProperty(value = "标签ID数组")
    @NotEmpty(message = "标签ID不能为空")
    private String tagidList;

}
