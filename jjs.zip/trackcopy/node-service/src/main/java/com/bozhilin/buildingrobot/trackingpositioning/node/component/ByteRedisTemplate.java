package com.bozhilin.buildingrobot.trackingpositioning.node.component;

import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;

/**
 * Bytes Redis serializer
 * @author chenang on 2019/7/28
 */
public class ByteRedisTemplate extends RedisTemplate<String, byte[]> {

    public ByteRedisTemplate() {
        setKeySerializer(RedisSerializer.string());
        setValueSerializer(new ByteRedisSerializer());
        setHashKeySerializer(RedisSerializer.string());
        setHashValueSerializer(getValueSerializer());
    }

    public ByteRedisTemplate(RedisConnectionFactory connectionFactory) {
        this();
        setConnectionFactory(connectionFactory);
        afterPropertiesSet();
    }
}
