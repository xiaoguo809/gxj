package com.bozhilin.buildingrobot.trackingpositioning.node.model;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.PositionDTO;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @Author: pengjunming
 * @Date:2019/9/26 9:31
 * @Description:
 */
@Data
@AllArgsConstructor
public class PositionQueryResponse {

    private final List<PositionDTO> positions;
}
