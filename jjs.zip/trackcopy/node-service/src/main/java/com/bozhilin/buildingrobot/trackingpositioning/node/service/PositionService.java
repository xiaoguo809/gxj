package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.node.dto.PositionDTO;

import java.util.List;

/**
 * @Author pengjunming
 * @Date  2019/9/26 9:44
 * @Description 位置查询接口
 **/
public interface PositionService {

    /**
     * 根据设备id查询设备最后移动的位置
     * @param ids
     * @return
     */
    List<PositionDTO> listPositions(List<String> ids);
}
