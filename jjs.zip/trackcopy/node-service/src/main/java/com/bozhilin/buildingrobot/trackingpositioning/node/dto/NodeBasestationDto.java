package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeBasestationProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class NodeBasestationDto extends NodeBasestationProperty {
    @ApiModelProperty(value = "节点名称")
    private String name;
    @ApiModelProperty(value = "节点分类id")
    private Integer categoryId;
    @ApiModelProperty(value = "状态：0->失效；1->有效")
    private Integer state;
    @ApiModelProperty(value = "创建时间")
    private Date createTime;
    @ApiModelProperty(value = "修改时间")
    private Date modifyTime;
    @ApiModelProperty(value = "备注")
    private String note;
}
