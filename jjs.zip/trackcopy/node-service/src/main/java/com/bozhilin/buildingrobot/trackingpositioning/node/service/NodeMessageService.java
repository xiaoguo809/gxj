package com.bozhilin.buildingrobot.trackingpositioning.node.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessage;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * NodeMessageService
 * Created by yutingtang on 2019/9/27
 */
public interface NodeMessageService {
    List<NodeMessage> listAll();

    int create(NodeMessage nodeCommand);

    @Transactional
    int update(Long id, NodeMessage nodeCommand);

    int delete(Long id);

    List<NodeMessage> list(int pageNum, int pageSize);

    NodeMessage get(Long id);
}
