package com.bozhilin.buildingrobot.trackingpositioning.node.redis.listener;

import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackContext;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSum;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis.TrackRealTimeRedisDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.TrackService;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;

import java.util.Date;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @Author pengjunming
 * @Date 2019/8/16 14:10
 * @Description 位置消息监听器配置类
 **/
@Configuration
@Slf4j
public class TrackMessageListenerConfig {

    @Value("${redis.track.topic}")
    private String topic;

    @Autowired
    private RedisMessageThreadPoolConfig poolConfig;

    @Bean
    public RedisMessageListenerContainer container(RedisConnectionFactory factory, MessageListenerAdapter listenerAdapter) {
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();
        ThreadPoolExecutor executor = new ThreadPoolExecutor(poolConfig.getCorePoolSize(), poolConfig.getMaximumPoolSize(),
                poolConfig.getKeepAliveTime(), TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        container.setConnectionFactory(factory);
        container.setTaskExecutor(executor);
        container.addMessageListener(listenerAdapter, new PatternTopic(topic));
        return container;
    }

    @Bean
    public MessageListenerAdapter listenerAdapter(StringRedisTemplate redisTemplate
            , TrackContext context, TrackService trackService, TrackRealTimeRedisDao redisDao) {
        return new MessageListenerAdapter(new TrackMessageListener(redisTemplate, context, trackService, redisDao));
    }

    /**
     * @Author pengjunming
     * @Date 2019/8/21 14:55
     * @Description 位置消息监听类
     **/
    public static class TrackMessageListener extends BaseMessageListener<TrackSum> {

        private final StringRedisTemplate redisTemplate;

        private final TrackContext context;

        private final TrackService trackService;

        private final TrackRealTimeRedisDao redisDao;

        public TrackMessageListener(StringRedisTemplate redisTemplate
                , TrackContext context, TrackService trackService, TrackRealTimeRedisDao redisDao) {
            this.redisTemplate = redisTemplate;
            this.context = context;
            this.trackService = trackService;
            this.redisDao = redisDao;
        }

        @Override
        protected void handleMessage(TrackSum trackSum) {
            //保存活跃的节点,后续的清理工作需要从这里获取节点
            redisTemplate.opsForSet().add(context.getAllLabelsKey(), getServerLabelRelation(trackSum.getServerId(), trackSum.getNodeCode()));
            if (isOnline(trackSum.getServerId())) {
                String payload = JSON.toJSONString(trackSum);
                log.info("Payload [{}] of Label [{}]", payload, trackSum.getNodeCode());
                long currentSeconds = dateToLongSeconds(trackSum.getTime());
                String labelPayloadPerSecondKey = context.getLabelPayloadPerSecondKey(trackSum.getServerId(), trackSum.getNodeCode(), currentSeconds);
                //保存标签每秒的轨迹数据
                redisTemplate.opsForList().rightPush(labelPayloadPerSecondKey, payload);
                //保存标签所有的轨迹数据，值为上面每秒的轨迹集合对应的key,按照时间排序
                redisTemplate.opsForZSet().add(context.getLabelAllPayloadKey(trackSum.getServerId(), trackSum.getNodeCode()), labelPayloadPerSecondKey, currentSeconds);
            }
            //保存数据
            trackService.saveTagTrack(TagTrackPointDTO.fromTrackSum(trackSum));
        }

        private String getServerLabelRelation(String serverId, String nodeCode) {
            return serverId + ":" + nodeCode;
        }

        private long dateToLongSeconds(Date time) {
            return time.getTime() / 1000;
        }

        // 获取指定标签订阅的目的地址
        private String getAreaCode(String code) {
            String areaCode = (String) redisTemplate.opsForHash().get(context.getLabelToArea(), code);
            return StringUtils.isNotBlank(areaCode) ? areaCode : null;
        }

        private boolean isOnline(String areaCode) {
            return StringUtils.isBlank(context.getAreaToSessionKey(areaCode)) ? false : true;
        }

    }
}
