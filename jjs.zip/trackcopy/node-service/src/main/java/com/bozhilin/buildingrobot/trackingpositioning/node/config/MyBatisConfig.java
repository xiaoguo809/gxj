package com.bozhilin.buildingrobot.trackingpositioning.node.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * MyBatis配置类
 * Created by chenang on 2019/7/28.
 */
@Configuration
@MapperScan({"com.bozhilin.buildingrobot.trackingpositioning.node.mapper",
             "com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper",
             "com.bozhilin.buildingrobot.trackingpositioning.common.mapper",
             "com.bozhilin.buildingrobot.trackingpositioning.common.dao.mapper"})
public class MyBatisConfig {
}
