package com.bozhilin.buildingrobot.trackingpositioning.node.model;/**
 * @author :  pengjunming
 * @date :   14:24
 */

/**
 * @Author: pengjunming
 * @Date:2019/8/23 14:24
 * @Description: 定义队列类型
 */
public enum QueueType {
    // 数组
    ARRAY,
    // 链表
    LINKED;
}
