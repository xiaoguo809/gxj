package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper.NodeSearchDao;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.SearchNodeByKeyDto;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * NodeSearchService实现类
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeSearchServiceImpl implements NodeSearchService {

    @Autowired
    private NodeSearchDao nodeSearchDao;

    @Override
    public List<SearchNodeByKeyDto> searchNodeByKey(String key, String isSearchBasestation,
                                                    String carrierIds, String serverId) throws Exception {
        List<SearchNodeByKeyDto> result = new ArrayList<>();
        if ("1".equals(isSearchBasestation)) {
            result.addAll(nodeSearchDao.queryBasestationsByKey(key, serverId));
        }

        if (StringUtils.hasText(carrierIds)) {
            List<String> carrierIdList = List.of(carrierIds.split(","));
            if (!ObjectUtils.isEmpty(carrierIdList)) {
                result.addAll(nodeSearchDao.queryLabelsByKey(key, carrierIdList, serverId));
            }
        }
        return result;
    }
}
