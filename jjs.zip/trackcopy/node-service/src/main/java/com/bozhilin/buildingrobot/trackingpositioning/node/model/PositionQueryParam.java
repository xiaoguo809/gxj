package com.bozhilin.buildingrobot.trackingpositioning.node.model;

import lombok.Data;

import java.util.List;

/**
 * @Author: pengjunming
 * @Date:2019/9/26 9:27
 * @Description: 位置信息请求参数
 */
@Data
public class PositionQueryParam {
    private List<String> ids;
}
