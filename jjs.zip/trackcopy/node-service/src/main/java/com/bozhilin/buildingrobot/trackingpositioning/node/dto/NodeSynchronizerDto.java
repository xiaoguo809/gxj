package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
public class NodeSynchronizerDto implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "服务器id")
    private Integer serverId;
    @ApiModelProperty(value = "节点id")
    private Integer id;
    @ApiModelProperty(value = "节点名称")
    private String name;
    @ApiModelProperty(value = "节点分类id")
    @NotEmpty
    private Integer categoryId;
    @ApiModelProperty(value = "状态：0->失效；1->有效")
    private Integer state;
    @ApiModelProperty(value = "基站容量")
    private Integer baseStationCapacity;
    @ApiModelProperty(value = "标签容量")
    private Integer labelCapacity;
    @ApiModelProperty(value = "创建时间")
    private Date createTime;
}
