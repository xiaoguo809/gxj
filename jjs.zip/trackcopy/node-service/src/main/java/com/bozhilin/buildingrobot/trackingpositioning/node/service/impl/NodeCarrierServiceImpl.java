package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeCarrierMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCarrier;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeCarrierExample;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeCarrierService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * NodeCarrierService
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeCarrierServiceImpl implements NodeCarrierService {
    @Autowired
    private NodeCarrierMapper nodeCarrierMapper;

    @Override
    public List<NodeCarrier> listAll() {
        return nodeCarrierMapper.selectByExample(new NodeCarrierExample());
    }

    public int create(NodeCarrier nodeCarrier) {
        return nodeCarrierMapper.insertSelective(nodeCarrier);
    }

    public int update(Long id, NodeCarrier nodeCarrier) {
        if (id.equals(nodeCarrier.getId())) {
            return nodeCarrierMapper.updateByPrimaryKeySelective(nodeCarrier);
        } else {
            delete(id);
            return create(nodeCarrier);
        }
    }

    public int delete(Long id) {
        return nodeCarrierMapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<NodeCarrier> list(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return nodeCarrierMapper.selectByExample(new NodeCarrierExample());
    }

    public NodeCarrier get(Long id) {
        return nodeCarrierMapper.selectByPrimaryKey(id);
    }

    @Override
    public int bindIcon(long nodeId, long iconid) {
        NodeCarrier nodeCarrier= new NodeCarrier();
        nodeCarrier.setId(nodeId);
        nodeCarrier.setIconId(iconid);
        return nodeCarrierMapper.updateByPrimaryKeySelective(nodeCarrier);
    }
}
