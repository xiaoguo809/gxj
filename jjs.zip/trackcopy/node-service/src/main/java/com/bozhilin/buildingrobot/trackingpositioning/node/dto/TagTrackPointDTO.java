package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSum;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 标签轨迹点
 * Create by TanJY on 2019/8/15
 */

@Getter
@Setter
public class TagTrackPointDTO implements Serializable {
    private String tagCode;
    private Date time;
    private BigDecimal x;
    private BigDecimal y;
    private BigDecimal z;

    public static TagTrackPointDTO fromTrackSum(TrackSum track){
        TagTrackPointDTO dto = new TagTrackPointDTO();
        if(StringUtil.isEmpty(track.getCoordinate()) || track.getCoordinate().split(",").length != 3){
            throw new RuntimeException("Invalid coordinate.");
        }
        String[] coordinates = track.getCoordinate().split(",");
        dto.setX(BigDecimal.valueOf(Double.valueOf(coordinates[0])));
        dto.setY(BigDecimal.valueOf(Double.valueOf(coordinates[1])));
        dto.setZ(BigDecimal.valueOf(Double.valueOf(coordinates[2])));
        dto.setTagCode(track.getNodeCode());
        dto.setTime(track.getTime());
        return dto;
    }
}
