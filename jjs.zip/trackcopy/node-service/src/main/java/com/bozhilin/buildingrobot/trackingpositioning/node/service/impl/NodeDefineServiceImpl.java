package com.bozhilin.buildingrobot.trackingpositioning.node.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeDefineMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefine;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeDefineExample;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.NodeDefineService;
import com.bozhilin.buildingrobot.trackingpositioning.node.util.NodeUtil;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * NodeDefineService实现类
 * Created by chenang on 2019/7/28
 */
@Service
public class NodeDefineServiceImpl implements NodeDefineService {

    @Autowired
    private NodeDefineMapper nodeDefineMapper;

    @Override
    public List<NodeDefine> listAll(Integer serverId) {
        NodeDefineExample example = new NodeDefineExample();
        example.createCriteria().andServerIdEqualTo(serverId);
        return nodeDefineMapper.selectByExample(example);
    }

    @Override
    public int create(NodeDefine nodeDefine) {
        return nodeDefineMapper.insertSelective(nodeDefine);
    }

    @Override
    public int update(Integer serverId, Integer nodeId, NodeDefine nodeDefine) {
        nodeDefine.setServerId(serverId);
        if ("".equals(nodeDefine.getId())) {
            nodeDefine.setId(nodeId);
        }

        if (nodeId.equals(nodeDefine.getId())) {
            return nodeDefineMapper.updateByPrimaryKeySelective(nodeDefine);
        } else {
            delete(serverId, nodeId);
            return create(nodeDefine);
        }
    }

    @Override
    public int delete(Integer serverId, Integer nodeId) {
        return nodeDefineMapper.deleteByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));
    }

    @Override
    public List<NodeDefine> list(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return nodeDefineMapper.selectByExample(new NodeDefineExample());
    }

    @Override
    public NodeDefine get(Integer serverId, Integer nodeId) {
        return nodeDefineMapper.selectByPrimaryKey(NodeUtil.nodeDefineKey(serverId, nodeId));
    }

    @Override
    public List<NodeDefine> search(String key) {
        NodeDefineExample example = new NodeDefineExample();
        List<NodeDefine> result = new ArrayList<>();
        if (key.matches("^[\\d]+$"))
        {
            example.createCriteria().andIdEqualTo(Integer.parseInt(key));
            result.addAll(nodeDefineMapper.selectByExample(example));
        }

        //TODO: 防止SQL注入
        example.clear();
        example.createCriteria().andNameLike("%" + key + "%");
        result.addAll(nodeDefineMapper.selectByExample(example));
        return result;
    }
}
