package com.bozhilin.buildingrobot.trackingpositioning.node.controller;

import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.ResultCode;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.ServiceException;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.PositionDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.PositionQueryParam;
import com.bozhilin.buildingrobot.trackingpositioning.node.model.PositionQueryResponse;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.PositionService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author: pengjunming
 * @Date:2019/9/26 9:37
 * @Description:
 */
@RestController
@RequestMapping("/position")
@Slf4j
public class PositionController {

    @Autowired
    private PositionService positionService;

    @ApiOperation(value = "查询设备最新的位置信息接口")
    @PostMapping(value = "/list")
    public CommonResult<PositionQueryResponse> list(@RequestBody PositionQueryParam positionQueryParam) {
        if(CollectionUtils.isEmpty(positionQueryParam.getIds())){
            log.warn("Ids should not be empty.");
            throw new ServiceException(ResultCode.EMPTY_PARAMETER);
        }
        List<PositionDTO> positions = positionService.listPositions(positionQueryParam.getIds());
        if(CollectionUtils.isEmpty(positions)){
            log.warn("Position not found of tab:{}", JSON.toJSONString(positionQueryParam.getIds()));
            throw new ServiceException(ResultCode.RECORD_NOT_EXISTS);
        }
        return CommonResult.success(new PositionQueryResponse(positions));
    }
}
