package com.bozhilin.buildingrobot.trackingpositioning.node.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @Author: pengjunming
 * @Date:2019/9/26 9:31
 * @Description: 位置信息
 */
@Data
public class PositionDTO {

    /**
     * 设备id
     */
    private String id;

    /**
     * 经纬度
     */
    private String coordinate;

    /**
     * 到达该经纬度时的时间
     */
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
    private Date time;
}
