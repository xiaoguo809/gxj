package com.bozhilin.buildingrobot.trackingpositioning.node.dao.redis;/**
 * @author :  pengjunming
 * @date :   18:35
 */

import com.bozhilin.buildingrobot.trackingpositioning.common.inf.Processor;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


/**
 * @Author: pengjunming
 * @Date:2019/8/26 18:35
 * @Description:
 */
public class TrackRedisDaoTests {

    private RedisTemplate mockedRedisTemplate;
    private ListOperations mockedListOperations;
    private TrackRealTimeRedisDao dao;
    private Processor mockedProcessor;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void init() {
        dao = new TrackRealTimeRedisDao();
        mockedRedisTemplate = mock(RedisTemplate.class);
        dao.setRedisTemplate(mockedRedisTemplate);
        mockedListOperations = mock(ListOperations.class);
        mockedProcessor = mock(Processor.class);
    }

    @Test
    public void testGetLockSuccess() {
        when(mockedRedisTemplate.execute(any(RedisCallback.class))).thenReturn(true);
        boolean isLocked = dao.getLock(UUID.randomUUID().toString());
        Assert.assertTrue("Get lock success.", isLocked);
        verify(mockedRedisTemplate).execute(any(RedisCallback.class));
    }

    @Test
    public void testGetLockFailed() {
        when(mockedRedisTemplate.execute(any(RedisCallback.class))).thenReturn(false);
        boolean isLocked = dao.getLock(UUID.randomUUID().toString());
        Assert.assertFalse("Get lock failed.", isLocked);
        verify(mockedRedisTemplate).execute(any(RedisCallback.class));
    }

    @Test
    public void testGetLockFailedOnBlankKey() {
        thrown.expect(RuntimeException.class);
        thrown.expectMessage("Invalid parameter.");
        dao.getLock("");
    }


    @Test
    public void testGetLockWithRetryTimesSuccess() {
        when(mockedRedisTemplate.execute(any(RedisCallback.class))).thenReturn(true);
        boolean isLocked = dao.getLock(UUID.randomUUID().toString(), 10, 100);
        Assert.assertTrue("Get lock with retry time success.", isLocked);
        verify(mockedRedisTemplate).execute(any(RedisCallback.class));
    }

    @Test
    public void testGetLockWithRetryTimesFailed() {
        when(mockedRedisTemplate.execute(any(RedisCallback.class))).thenReturn(false);
        boolean isLocked = dao.getLock(UUID.randomUUID().toString(), 10, 100);
        Assert.assertFalse("Get lock with retry time failed.", isLocked);
        verify(mockedRedisTemplate, times(10)).execute(any(RedisCallback.class));
    }

    @Test
    public void testGetLockWithRetryTimesFailedOnBlankKey() {
        thrown.expect(RuntimeException.class);
        thrown.expectMessage("Invalid parameter.");
        dao.getLock("", 10, 100);
    }

    @Test
    public void testGetLockWithRetryTimesFailedOnRetryTimes() {
        thrown.expect(RuntimeException.class);
        thrown.expectMessage("Invalid retryTimes.");
        dao.getLock(UUID.randomUUID().toString(), - (new Random().nextInt(10)), 100);
    }

    @Test
    public void testGetLockWithRetryTimesFailedOnIntervalTime() {
        thrown.expect(RuntimeException.class);
        thrown.expectMessage("Invalid intervalTime.");
        dao.getLock(UUID.randomUUID().toString(), 1, - (new Random().nextInt(10)));
    }

    @Test
    public void testProcessWhileLockSuccess() {
        when(mockedRedisTemplate.execute(any(RedisCallback.class))).thenReturn(true);
        boolean isSuccess = dao.processWhileLock(UUID.randomUUID().toString(), 10, 100, mockedProcessor);
        verify(mockedProcessor).process();
        verify(mockedRedisTemplate).execute(any(RedisCallback.class));
        Assert.assertTrue("Process success.", isSuccess);
    }

    @Test
    public void testGetAllListFailedOnBlankKey(){
        thrown.expect(RuntimeException.class);
        thrown.expectMessage("Key should not be blank.");
        dao.getAllList("");
    }

    @Test
    public void testGetAllListFailedOnNullKey(){
        thrown.expect(RuntimeException.class);
        thrown.expectMessage("Key should not be blank.");
        dao.getAllList(null);
    }

    @Test
    public void testGetAllListSuccess(){
        String key = UUID.randomUUID().toString();
        List<String> expected = buildList();
        when(mockedRedisTemplate.opsForList()).thenReturn(mockedListOperations);
        when(mockedListOperations.range(key, 0, -1)).thenReturn(expected);
        List<String> actual = dao.getAllList(key);
        verify(mockedRedisTemplate).opsForList();
        verify(mockedListOperations).range(key,0,-1);
        assertResult(expected, actual);
    }

    private void assertResult(List<String> expected, List<String> actual) {
        Assert.assertNotNull("Actual result should not be null.",actual);
        Assert.assertEquals("Actual and expected size should be same.", expected.size(), actual.size());
        for(int index = 0; index < expected.size(); index ++ ){
            Assert.assertEquals(expected.get(index), actual.get(index));
        }
    }

    private List<String> buildList() {
        List<String> results = new ArrayList<>();
        results.add("a");
        results.add("b");
        results.add("c");
        results.add("d");
        results.add("e");
        return results;
    }
}
