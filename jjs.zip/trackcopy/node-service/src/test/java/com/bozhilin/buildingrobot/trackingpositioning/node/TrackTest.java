package com.bozhilin.buildingrobot.trackingpositioning.node;

/**
 * Create by TanJY on 2019/8/16 0016
 */

import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.node.dto.TagTrackPointDTO;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.TrackService;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = NodeApplication.class)
//手动执行的时候把Ignore注释掉
//@Ignore
public class TrackTest {

    @Autowired
    private TrackService trackService;

    @Test
    public void stringTest() {
        String str2 = "ROBOT_POSITIONING_TAG_0001_20190801";
        int lastOne = str2.lastIndexOf("_");
        System.out.println(str2.substring(lastOne+1, str2.length()));
        System.out.println(str2.substring(str2.lastIndexOf("_", lastOne-1)+1, lastOne));
    }

    @Test
    public void trackSaveTest() throws InterruptedException {
        ThreadPoolExecutor executor = new ThreadPoolExecutor(20, 20, 0l, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        executor.execute(new ThreadTest("2001"));
        executor.execute(new ThreadTest("4002"));
        executor.execute(new ThreadTest("4010"));
        executor.execute(new ThreadTest("5003"));
        executor.execute(new ThreadTest("5010"));
//        executor.execute(new ThreadTest("6"));
//        executor.execute(new ThreadTest("7"));
//        executor.execute(new ThreadTest("8"));
//        executor.execute(new ThreadTest("9"));
//        executor.execute(new ThreadTest("10"));
        Thread.sleep(10000000l);
    }

    class ThreadTest implements Runnable {
        private String tagCode;
        private BigDecimal x = new BigDecimal(1132723000000L);
        private BigDecimal y = new BigDecimal(229260000000L);
        private boolean xIfAdd = true;
        private boolean yIfAdd = true;

        private long time = System.currentTimeMillis() - 400000000;

        public ThreadTest(String tagCode) {
            this.tagCode = tagCode;
        }
        @Override
        public void run() {
            try {
                for (int i = 0; i < 12000; i++ ) {
                    BigDecimal xInc = new BigDecimal(new Random().nextInt(1000)).multiply(new BigDecimal(8)).subtract(new BigDecimal(3000));
                    BigDecimal yInc = new BigDecimal(new Random().nextInt(1000)).multiply(new BigDecimal(10)).subtract(new BigDecimal(4000));
                    if (x.compareTo(new BigDecimal(200)) >= 0) {
                        xIfAdd = false;
                    }
                    if (x.compareTo(new BigDecimal(10)) < 0) {
                        xIfAdd = true;
                    }
                    if (y.compareTo(new BigDecimal(200)) >= 0) {
                        yIfAdd = false;
                    }
                    if (y.compareTo(new BigDecimal(10)) < 0) {
                        yIfAdd = true;
                    }
                    if (xIfAdd) {
                        x = x.add(xInc);
                    } else {
                        x = x.subtract(xInc);
                    }
                    if (yIfAdd) {
                        y = y.add(yInc);
                    } else {
                        y = y.subtract(yInc);
                    }
                    TagTrackPointDTO pointDTO = new TagTrackPointDTO();
                    pointDTO.setTagCode(tagCode);
                    pointDTO.setTime(new Date(time+=new Random().nextInt(50000)));
                    pointDTO.setX(x);
                    pointDTO.setY(y);
                    pointDTO.setZ(new BigDecimal(1));
                    System.out.println(JSON.toJSONString(pointDTO));
                    trackService.saveTagTrack(pointDTO);
                }
            } catch (Exception e) {

            }
        }
    }

}
