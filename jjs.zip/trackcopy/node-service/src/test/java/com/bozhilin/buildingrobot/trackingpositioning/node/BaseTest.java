package com.bozhilin.buildingrobot.trackingpositioning.node;

import org.junit.Rule;
import org.junit.rules.ExpectedException;

/**
 * @Author: pengjunming
 * @Date:2019/9/19 10:48
 * @Description:
 */
public class BaseTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();
}
