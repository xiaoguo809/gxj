package com.bozhilin.buildingrobot.trackingpositioning.node;


import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSum;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

@Slf4j
public class MessageSender {

    private static final String Z_COORDINATE = "3";
    private static final String[] NODES = {"4001","4002","4010","5003","5010"};
    private static final String HOST = "10.8.200.55";
    private static final int PORT = 6379;
    private static final String SERVER_ID = "1";
    // 如果为true则不需要按1秒间隔发送
    private boolean simulateImmediately = false;
    // 模拟总移动的时长，单位：秒
    private int totalMoveTime = 60900;
    private static final String longitude = "1132723000000";
    private static final String latitude = "229260000000";
    private static StringRedisTemplate redisTemplate;

    @BeforeClass
    public static void init() {
        RedisStandaloneConfiguration coinfig = new RedisStandaloneConfiguration(HOST, PORT);
        coinfig.setDatabase(0);
        JedisConnectionFactory factory = new JedisConnectionFactory(coinfig);
        factory.afterPropertiesSet();
        redisTemplate = new StringRedisTemplate(factory);
        redisTemplate.setKeySerializer(RedisSerializer.string());
        redisTemplate.setValueSerializer(new StringRedisSerializer());
        redisTemplate.afterPropertiesSet();
    }

    private String topic = "track";

    private Random random = new Random(System.currentTimeMillis());

    @Test
    public void simulate() {
        for (String code : NODES) {
            new Thread() {
                @Override
                public void run() {
                    simulate(code);
                }
            }.start();
        }
        try {
            Thread.sleep(totalMoveTime * 1000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * @Author pengjunming
     * @Description 模拟机器人运动
     **/

    public void simulate(String code) {

        // 每一秒移动的点
        int moveTracksPers = 0;
        Date startTime = new Date();
        TrackDTO dto = new TrackDTO();
        dto.setCode(code);
        dto.setLastMoveTime(startTime);
        dto.setLastCoordinate(new Coordinate(longitude, latitude).toString());
        // 每一秒移动一次
        for (int movedTime = 0; movedTime < totalMoveTime; movedTime++) {
            if (!simulateImmediately) {
                try {
                    Thread.sleep(1000l);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            // 获取一秒内移动的点
            moveTracksPers = random();
            // 生成轨迹
            dto = createTracks(moveTracksPers, dto);
            // 发送移动轨迹到Redis
            send(dto);
            // 重置移动轨迹
            dto.setTracks(null);
        }
    }

    /**
     * @Author pengjunming
     * @Description 生成移动轨迹
     **/
    private TrackDTO createTracks(int moveTracksPers, TrackDTO dto) {
        // 产生0~2随机数
        int mode = random.nextInt(3);
        // 0:直线轨迹，1:曲线轨迹,2:停止运动
        switch (mode) {
            case 0:
                dto = createLineTracks(moveTracksPers, dto);
                break;
            case 1:
                dto = createCurveTracks(moveTracksPers, dto);
                break;
            default:
                dto = stopMoving(dto);
        }
        return dto;
    }

    /**
     * @Author pengjunming
     * @Description 发送移动轨迹到Redis
     **/
    private void send(TrackDTO dto) {
        // 如果机器没有移动过则不需要发送
        if (dto.getTracks() == null) {
            return;
        }
        for (TrackSum track : dto.getTracks()) {
            String json = JSON.toJSONString(track);
            log.error(json);
            redisTemplate.convertAndSend(topic, json);
        }
    }

    /**
     * @Author pengjunming
     * @Description 产生1~10的随机数
     **/
    private int random() {
        return random.nextInt(10) + 1;
    }

    /**
     * @Author pengjunming
     * @Description 生成一秒内一段直线运动的轨迹
     **/
    private TrackDTO createLineTracks(int trackNum, TrackDTO dto) {
        return create(trackNum, dto, true);
    }

    /**
     * @Author pengjunming
     * @Description 生成一秒内一段曲线运动的轨迹
     **/
    private TrackDTO createCurveTracks(int trackNum, TrackDTO dto) {
        return create(trackNum, dto, false);
    }

    /**
     * @Author pengjunming
     * @Description 停止移动，只需修改时间
     **/
    private TrackDTO stopMoving(TrackDTO dto) {
        dto.setLastMoveTime(new Date(dto.getLastMoveTime().getTime() + 1000L));
        return dto;
    }

    private TrackDTO create(int trackNum, TrackDTO dto, boolean isLine) {
        List<TrackSum> tracks = new ArrayList<>();
        Date lastMovedTime = dto.getLastMoveTime();
        // 计算每次移动的时间间隔,单位为毫秒,假设发送的间隔是相等的
        Long timeMillisPerMove = 1000L / trackNum;
        for (int i = 0; i < trackNum; i++) {
            TrackSum track = new TrackSum();
            track.setServerId(SERVER_ID);
            tracks.add(track);
            track.setCoordinate(computeCoordinate(dto, isLine).toString());
            track.setNodeCode(dto.getCode());
            Date currentTime = new Date(lastMovedTime.getTime() + timeMillisPerMove * (i + 1));
            track.setTime(currentTime);
            // 更新最后移动的坐标
            dto.setLastCoordinate(track.getCoordinate());
        }
        dto.setTracks(tracks);
        // 时间增加1秒
        dto.setLastMoveTime(new Date(lastMovedTime.getTime() + 1000L));
        return dto;
    }

    /**
     * @param isLine 是否计算直线的坐标
     * @Author pengjunming
     * @Description 计算坐标
     **/
    private Coordinate computeCoordinate(TrackDTO dto, boolean isLine) {
        Double[] xyCoordinate = getXY(dto.getLastCoordinate());
        // 算出x/y的比例,保留3位小数,向上转型
        BigDecimal rate = BigDecimal.valueOf(xyCoordinate[0]).divide(BigDecimal.valueOf(xyCoordinate[1]), 3, RoundingMode.UP);
        // y坐标移动的距离
        BigDecimal yMoveDistance = getRandomDistance();
        // x = y * rate，这样才会保持一条直线
        BigDecimal xMoveDistance = yMoveDistance.multiply(rate).setScale(3, RoundingMode.UP);
        // 如果不是直线则Y坐标或X坐标需要增加随机的位移
        if (!isLine) {
            if (random.nextInt(10) % 2 == 0) {
                xMoveDistance = xMoveDistance.add(getRandomDistance());
            } else {
                yMoveDistance = yMoveDistance.add(getRandomDistance());
            }
        }
        // 计算y坐标 x = 原来x坐标 + x移动距离
        Long xCoordinate = BigDecimal.valueOf(xyCoordinate[0]).add(xMoveDistance).longValue();
        // 计算y坐标 算法同上
        Long yCoordinate = BigDecimal.valueOf(xyCoordinate[1]).add(yMoveDistance).longValue();
        return new Coordinate(xCoordinate.toString(), yCoordinate.toString());
    }

    private BigDecimal getRandomDistance() {
        return BigDecimal.valueOf(random.nextInt(10000));
//        BigDecimal distance = NumberUtil.round(random.nextDouble(), 3);
//        int range = random.nextInt(MAX_DISTANCE);
//        if (range > currentCoordinate) {
//            return distance;
//        }
//        return distance.negate();
    }

    /**
     * @Author pengjunming
     * @Description 获取x, y坐标
     **/
    private Double[] getXY(String coordinate) {
        // eg: 231.551,212.212,121,332
        String[] xyz = coordinate.split(",");
        return new Double[]{Double.valueOf(xyz[0]), Double.valueOf(xyz[1])};
    }


    @Data
    private static class TrackDTO {
        private String code;
        // 一段连续的轨迹记录
        private List<TrackSum> tracks;

        // 最后移动的时间
        private Date lastMoveTime;

        // 最后移动的坐标
        private String lastCoordinate;
    }

    private static class Coordinate {
        // x坐标
        private final String x;
        // y坐标
        private final String y;
        // z坐标暂定为固定值
        private String z = Z_COORDINATE;

        public Coordinate(String x, String y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public String toString() {
            return x + "," + y + "," + z;
        }

    }
}
