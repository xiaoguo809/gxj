package com.bozhilin.buildingrobot.trackingpositioning.node.service;/**
 * @author :  pengjunming
 * @date :   11:15
 */

import com.bozhilin.buildingrobot.trackingpositioning.common.model.ResultCode;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.ServiceException;
import com.bozhilin.buildingrobot.trackingpositioning.node.dao.mapper.StandardPointDao;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.StandardPoint;
import com.bozhilin.buildingrobot.trackingpositioning.node.service.impl.StandardPointServiceImpl;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;

import java.math.BigDecimal;

/**
 * @Author: pengjunming
 * @Date:2019/8/31 11:15
 * @Description: 基准点接口测试
 */
public class StandardPointServiceTest {

    private static final BigDecimal LONGITUDE = new BigDecimal(112.33215522);

    private static final BigDecimal LATITUDE =  new BigDecimal(23.66551231);

    private static final String AREA_CODE = "areaCode";

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private StandardPointService service;

    private StandardPointDao mockedDao;

    @Before
    public void init() {
        mockedDao = Mockito.mock(StandardPointDao.class);
        service = new StandardPointServiceImpl(mockedDao);
    }

//***************************测试save方法*************************************

    /**
     * 测试新增成功的场景
     **/
    @Test
    public void testSave() {
        StandardPoint validData = new StandardPoint(LONGITUDE, LATITUDE, AREA_CODE);
        Mockito.when(mockedDao.findByAreaCode(AREA_CODE)).thenReturn(null);
        service.save(validData);
        Mockito.verify(mockedDao).findByAreaCode(AREA_CODE);
        Mockito.verify(mockedDao).save(validData);
    }

    /**
     * 测试区域码为空的场景
     **/
    @Test
    public void testSaveFailedOnBlankCode() {
        StandardPoint invalidData = new StandardPoint(LONGITUDE, LATITUDE, null);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.save(invalidData);
    }

    /**
     * 测试经度为空的场景
     **/
    @Test
    public void testSaveFailedOnNullLongitude() {
        StandardPoint invalidData = new StandardPoint(null, LATITUDE, AREA_CODE);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.save(invalidData);
    }

    /**
     * 测试纬度为空的场景
     **/
    @Test
    public void testSaveFailedOnNullLatitude() {
        StandardPoint invalidData = new StandardPoint(LONGITUDE, null, AREA_CODE);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.save(invalidData);
    }

    /**
     * 测试记录已存在的场景
     **/
    @Test
    public void testSaveFaileOnRecordAlreadyExists() {
        StandardPoint existRecord = new StandardPoint(LONGITUDE, LATITUDE, AREA_CODE);
        Mockito.when(mockedDao.findByAreaCode(AREA_CODE)).thenReturn(existRecord);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.RECORD_ALREADY_EXISTS.getMessage());
        service.save(existRecord);
    }
//******************************测试update方法**************************************

    /**
     * 测试更新成功的场景
     **/
    @Test
    public void testUpdateSuccess() {
        StandardPoint updatedRecord = new StandardPoint(LONGITUDE, LATITUDE, AREA_CODE);
        Mockito.when(mockedDao.update(updatedRecord)).thenReturn(1);
        service.update(updatedRecord);
        Mockito.verify(mockedDao).update(updatedRecord);
    }

    /**
     * 测试区域码为null的场景
     */
    @Test
    public void testUpdateFailedOnNullAreaCode() {
        StandardPoint invalidRecord = new StandardPoint(LONGITUDE, LATITUDE, null);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.update(invalidRecord);
    }

    /**
     * 测试经度为null的场景
     */
    @Test
    public void testUpdateFailedOnNullLongitude(){
        StandardPoint invalidRecord = new StandardPoint(null, LATITUDE, AREA_CODE);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.update(invalidRecord);
    }

    /**
     * 测试纬度为null的情况
     */
    @Test
    public void testUpdateFailedOnNullLatitude(){
        StandardPoint invalidRecord = new StandardPoint(LONGITUDE, null, AREA_CODE);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.update(invalidRecord);
    }

    /**
     * 测试记录不存在更新失败的情况
     */
    @Test
    public void testUpdateFailedOnRecordNotExists(){
        StandardPoint notExistsRecord = new StandardPoint(LONGITUDE, LATITUDE, AREA_CODE);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.RECORD_NOT_EXISTS.getMessage());
        Mockito.when(mockedDao.update(notExistsRecord)).thenReturn(0);
        service.update(notExistsRecord);
        Mockito.verify(mockedDao).update(notExistsRecord);
    }

//********************************测试delete方法****************************************

    /**
     * 测试删除成功的场景
     */
    @Test
    public void testDeleteSuccess(){
        Mockito.when(mockedDao.deleteByAreaCode(AREA_CODE)).thenReturn(1);
        service.delete(AREA_CODE);
        Mockito.verify(mockedDao).deleteByAreaCode(AREA_CODE);
    }

    /**
     * 测试aredCode为null的场景
     */
    @Test
    public void testDeleteFailedOnNullAreaCode(){
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.delete(null);
    }

    /**
     * 测试aredCode为空的场景
     */
    @Test
    public void testDeleteFailedOnBlankAreaCode(){
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.delete("");
    }

    /**
     * 测试被删除的记录不存的场景
     */
    @Test
    public void testDeleteFailedOnRecordNotExists(){
        Mockito.when(mockedDao.deleteByAreaCode(AREA_CODE)).thenReturn(0);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.RECORD_NOT_EXISTS.getMessage());
        service.delete(AREA_CODE);
    }

//*************************测试 find方法**********************************

    /**
     * 测试查询成功的场景
     */
    @Test
    public void testFindSuccess(){
        StandardPoint expected = new StandardPoint(LONGITUDE, LATITUDE, AREA_CODE);
        Mockito.when(mockedDao.findByAreaCode(AREA_CODE)).thenReturn(expected);
        StandardPoint actual =  service.find(AREA_CODE);
        Mockito.verify(mockedDao).findByAreaCode(AREA_CODE);
        Assert.assertEquals("AreaCode should be equals", expected.getAreaCode(), actual.getAreaCode());
        Assert.assertEquals("Latitude should be equals", expected.getLatitude(), actual.getLatitude());
        Assert.assertEquals("Longitude should be equals", expected.getLongitude(), actual.getLongitude());
    }

    /**
     * 测试areaCode为null的场景
     */
    @Test
    public void testFindFailedOnNullAreaCode(){
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.delete(null);
    }

    /**
     * 测试areaCode为空的场景
     */
    @Test
    public void testFindFailedOnBlankAreaCode(){
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        service.delete("");
    }

    /**
     * 测试记录不存在的场景
     */
    @Test
    public void testFindFailedOnRecordNotExists(){
        Mockito.when(mockedDao.findByAreaCode(AREA_CODE)).thenReturn(null);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.RECORD_NOT_EXISTS.getMessage());
        service.find(AREA_CODE);
    }
}
