package com.bozhilin.buildingrobot.trackingpositioning.node.service;

/**
 * Create by TanJY on 2019/8/16 0016
 */

import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessage;
import com.bozhilin.buildingrobot.trackingpositioning.node.NodeApplication;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = NodeApplication.class)
public class UpTest {

    private static final String HOST = "127.0.0.1";
    private static final int PORT = 6379;
    private static StringRedisTemplate redisTemplate;

    @BeforeClass
    public static void init() {
        RedisStandaloneConfiguration coinfig = new RedisStandaloneConfiguration(HOST, PORT);
        coinfig.setDatabase(0);
        JedisConnectionFactory factory = new JedisConnectionFactory(coinfig);
        factory.afterPropertiesSet();
        redisTemplate = new StringRedisTemplate(factory);
        redisTemplate.setKeySerializer(RedisSerializer.string());
        redisTemplate.setValueSerializer(new StringRedisSerializer());
        redisTemplate.afterPropertiesSet();
    }

    private String topic = "upmsg";

    @Test
    public void stringTest() {
        for (int i = 0; i < 1000; i++) {
            NodeMessage nodeMessage = new NodeMessage();
            nodeMessage.setNodeId(20L);
            nodeMessage.setMsgBody("12231");
            nodeMessage.setMsgType("up");
            nodeMessage.setEffTime("10");
            nodeMessage.setCreateTime(new Date());
            nodeMessage.setModifyTime(new Date());
            redisTemplate.convertAndSend(topic, JSON.toJSONString(nodeMessage));
        }

    }

}
