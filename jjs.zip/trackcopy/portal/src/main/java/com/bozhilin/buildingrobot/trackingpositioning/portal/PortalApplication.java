package com.bozhilin.buildingrobot.trackingpositioning.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(scanBasePackages={"com.bozhilin.buildingrobot.trackingpositioning.portal",
                                         "com.bozhilin.buildingrobot.trackingpositioning.common"})
@EnableScheduling
public class PortalApplication {
    public static void main(String[] args) {
        /**
         * Springboot整合Elasticsearch，netty冲突后，初始化client时
         * 解决
         * 防止报错java.lang.IllegalStateException: availableProcessors is already set to [4], rejecting [4]
         */
        System.setProperty("es.set.netty.runtime.available.processors", "false"); //for Elasticsearch
        SpringApplication.run(PortalApplication.class, args);
    }

}
