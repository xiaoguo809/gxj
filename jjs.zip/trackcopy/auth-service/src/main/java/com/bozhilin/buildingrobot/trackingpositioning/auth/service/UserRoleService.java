package com.bozhilin.buildingrobot.trackingpositioning.auth.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.Role;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 后台管理员Service
 * Created by chenang on 2019/7/28.
 */
public interface UserRoleService {
    /**
     * 修改用户角色关系
     */
    @Transactional
    int updateRole(Long userId, List<Long> roleIds);

    /**
     * 获取用户对于角色
     */
    List<Role> getRoleList(Long userId);
}
