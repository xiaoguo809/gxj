package com.bozhilin.buildingrobot.trackingpositioning.auth.dao;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.Permission;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.RolePermission;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 后台用户角色管理自定义Dao
 * Created by chenang on 2019/7/28.
 */
public interface RolePermissionDao {
    /**
     * 批量插入角色和权限关系
     */
    int insertList(@Param("list") List<RolePermission> list);

    /**
     * 根据角色获取权限
     */
    List<Permission> getPermissionList(@Param("roleId") Long roleId);
}
