package com.bozhilin.buildingrobot.trackingpositioning.auth.dao;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.Permission;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.Role;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.UserRole;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 后台用户与角色管理自定义Dao
 * Created by chenang on 2019/7/28.
 */
public interface UserRoleDao {
    /**
     * 批量插入用户角色关系
     */
    int insertList(@Param("list") List<UserRole> userRoleList);

    /**
     * 获取用于所有角色
     */
    List<Role> getRoleList(@Param("userId") Long userId);

    /**
     * 获取用户所有角色权限
     */
    List<Permission> getRolePermissionList(@Param("userId") Long userId);

    /**
     * 获取用户所有权限(包括+-权限)
     */
    List<Permission> getPermissionList(@Param("userId") Long userId);
}
