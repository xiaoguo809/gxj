package com.bozhilin.buildingrobot.trackingpositioning.auth.controller;

import com.bozhilin.buildingrobot.trackingpositioning.auth.service.UserRoleService;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.Role;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 用户角色管理
 * Created by chenang on 2019/7/28.
 */
@Controller
@Api(tags = "UserRoleController", description = "用户角色管理")
@RequestMapping("/user")
public class UserRoleController {
    @Autowired
    private UserRoleService userRoleService;

    @ApiOperation("给用户分配角色")
    @RequestMapping(value = "/role/update", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult updateRole(@RequestParam("userId") Long userId,
                                   @RequestParam("roleIds") List<Long> roleIds) {
        int count = userRoleService.updateRole(userId, roleIds);
        if (count >= 0) {
            return CommonResult.success(count);
        }
        return CommonResult.failed();
    }

    @ApiOperation("获取指定用户的角色")
    @RequestMapping(value = "/role/get", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<Role>> getRoleList(@RequestParam("userId") Long userId) {
        List<Role> roleList = userRoleService.getRoleList(userId);
        return CommonResult.success(roleList);
    }
}