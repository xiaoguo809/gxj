package com.bozhilin.buildingrobot.trackingpositioning.auth.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.UserPermissionMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.Permission;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.UserPermission;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.UserPermissionExample;
import com.bozhilin.buildingrobot.trackingpositioning.auth.dao.UserPermissionDao;
import com.bozhilin.buildingrobot.trackingpositioning.auth.dao.UserRoleDao;
import com.bozhilin.buildingrobot.trackingpositioning.auth.service.UserPermissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * UserService实现类
 * Created by chenang on 2019/7/28.
 */
@Service
@Slf4j
public class UserPermissonServiceImpl implements UserPermissionService {
    @Autowired
    private UserRoleDao userRoleDao;
    @Autowired
    private UserPermissionMapper userPermissionMapper;
    @Autowired
    private UserPermissionDao userPermissionDao;

    @Override
    public int updatePermission(Long userId, List<Long> permissionIds) {
        //删除原所有权限关系
        UserPermissionExample relationExample = new UserPermissionExample();
        relationExample.createCriteria().andUserIdEqualTo(userId);
        userPermissionMapper.deleteByExample(relationExample);
        //获取用户所有角色权限
        List<Permission> permissionList = userRoleDao.getRolePermissionList(userId);
        List<Long> rolePermissionList = permissionList.stream().map(Permission::getId).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(permissionIds)) {
            List<UserPermission> relationList = new ArrayList<>();
            //筛选出+权限
            List<Long> addPermissionIdList = permissionIds.stream().filter(permissionId -> !rolePermissionList.contains(permissionId)).collect(Collectors.toList());
            //筛选出-权限
            List<Long> subPermissionIdList = rolePermissionList.stream().filter(permissionId -> !permissionIds.contains(permissionId)).collect(Collectors.toList());
            //插入+-权限关系
            relationList.addAll(convert(userId,1,addPermissionIdList));
            relationList.addAll(convert(userId,-1,subPermissionIdList));
            return userPermissionDao.insertList(relationList);
        }
        return 0;
    }

    /**
     * 将+-权限关系转化为对象
     */
    private List<UserPermission> convert(Long userId, Integer type, List<Long> permissionIdList) {
        List<UserPermission> userPermissionList = permissionIdList.stream().map(permissionId -> {
            UserPermission userPermission = new UserPermission();
            userPermission.setUserId(userId);
            userPermission.setType(type);
            userPermission.setPermissionId(permissionId);
            return userPermission;
        }).collect(Collectors.toList());
        return userPermissionList;
    }

    @Override
    public List<Permission> getPermissionList(Long userId) {
        return userRoleDao.getPermissionList(userId);
    }
}
