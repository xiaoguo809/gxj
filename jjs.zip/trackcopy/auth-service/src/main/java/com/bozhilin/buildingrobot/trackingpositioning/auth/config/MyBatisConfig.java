package com.bozhilin.buildingrobot.trackingpositioning.auth.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * MyBatis配置类
 * Created by chenang on 2019/7/28.
 */
@Configuration
@MapperScan({"com.bozhilin.buildingrobot.trackingpositioning.auth.mapper",
             "com.bozhilin.buildingrobot.trackingpositioning.auth.dao",
             "com.bozhilin.buildingrobot.trackingpositioning.common.mapper",
             "com.bozhilin.buildingrobot.trackingpositioning.common.dao"})
public class MyBatisConfig {
}
