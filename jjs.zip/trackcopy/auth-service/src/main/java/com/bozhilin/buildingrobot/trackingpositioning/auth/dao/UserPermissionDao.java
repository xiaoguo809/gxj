package com.bozhilin.buildingrobot.trackingpositioning.auth.dao;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.UserPermission;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 用户权限自定义Dao
 * Created by chenang on 2019/7/28.
 */
public interface UserPermissionDao {
    int insertList(@Param("list") List<UserPermission> list);
}
