package com.bozhilin.buildingrobot.trackingpositioning.auth.controller;

import com.bozhilin.buildingrobot.trackingpositioning.auth.service.UserPermissionService;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.Permission;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 用户权限管理
 * Created by chenang on 2019/7/28.
 */
@Controller
@Api(tags = "UserPermissionController", description = "用户权限管理")
@RequestMapping("/user")
public class UserPermissionController {
    @Autowired
    private UserPermissionService userPermissionService;

    @ApiOperation("给用户分配+-权限")
    @RequestMapping(value = "/permission/update", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult updatePermission(@RequestParam("userId") Long userId,
                                         @RequestParam("permissionIds") List<Long> permissionIds) {
        int count = userPermissionService.updatePermission(userId, permissionIds);
        if (count > 0) {
            return CommonResult.success(count);
        }
        return CommonResult.failed();
    }

    @ApiOperation("获取用户所有权限（包括+-权限）")
    @RequestMapping(value = "/permission/get", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<List<Permission>> getPermissionList(@RequestParam("userId") Long userId) {
        List<Permission> permissionList = userPermissionService.getPermissionList(userId);
        return CommonResult.success(permissionList);
    }
}