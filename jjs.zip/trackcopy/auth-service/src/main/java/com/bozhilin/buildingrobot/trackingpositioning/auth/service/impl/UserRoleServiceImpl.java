package com.bozhilin.buildingrobot.trackingpositioning.auth.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.UserRoleMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.Role;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.UserRole;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.UserRoleExample;
import com.bozhilin.buildingrobot.trackingpositioning.auth.dao.UserRoleDao;
import com.bozhilin.buildingrobot.trackingpositioning.auth.service.UserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * UserService实现类
 * Created by chenang on 2019/7/28.
 */
@Service
@Slf4j
public class UserRoleServiceImpl implements UserRoleService {
    @Autowired
    private UserRoleMapper userRoleMapper;
    @Autowired
    private UserRoleDao userRoleDao;

    @Override
    public int updateRole(Long userId, List<Long> roleIds) {
        int count = roleIds == null ? 0 : roleIds.size();
        //先删除原来的关系
        UserRoleExample userRoleExample = new UserRoleExample();
        userRoleExample.createCriteria().andUserIdEqualTo(userId);
        userRoleMapper.deleteByExample(userRoleExample);
        //建立新关系
        if (!CollectionUtils.isEmpty(roleIds)) {
            List<UserRole> list = new ArrayList<>();
            for (Long roleId : roleIds) {
                UserRole roleRelation = new UserRole();
                roleRelation.setUserId(userId);
                roleRelation.setRoleId(roleId);
                list.add(roleRelation);
            }
            userRoleDao.insertList(list);
        }
        return count;
    }

    @Override
    public List<Role> getRoleList(Long userId) {
        return userRoleDao.getRoleList(userId);
    }
}
