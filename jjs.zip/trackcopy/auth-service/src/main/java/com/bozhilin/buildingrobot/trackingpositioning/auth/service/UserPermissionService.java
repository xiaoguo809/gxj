package com.bozhilin.buildingrobot.trackingpositioning.auth.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.Permission;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 后台管理员Service
 * Created by chenang on 2019/7/28.
 */
public interface UserPermissionService {
    /**
     * 修改用户的+-权限
     */
    @Transactional
    int updatePermission(Long userId, List<Long> permissionIds);

    /**
     * 获取用户所有权限（包括角色权限和+-权限）
     */
    List<Permission> getPermissionList(Long userId);
}
