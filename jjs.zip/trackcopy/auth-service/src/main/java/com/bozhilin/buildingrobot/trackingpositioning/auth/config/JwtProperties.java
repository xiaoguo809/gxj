package com.bozhilin.buildingrobot.trackingpositioning.auth.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "jwt")
@Getter
@Setter
public class JwtProperties {
    private String tokenHeader; //JWT存储的请求头
    private String secretKey; //JWT加解密使用的密钥
    private int expiration; //JWT的超期限时间(单位：秒)
    private String tokenHead; //JWT负载中拿到开头
}
