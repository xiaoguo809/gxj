# 博智林建筑机器人追踪定位系统

## 微服务架构
* portal 网关服务（实时轨迹显示、信息传递）
* admin 系统管理服务（包括权限管理、登录管理）
* node 节点服务（地图应用、网络配置、标签管理、网络拓扑展示）
* search 搜索服务（业务统计）
* background 后台进程()
* api api服务

## 技术选型
* Spring Boot	容器+MVC框架	https://spring.io/projects/spring-boot
* Spring Security	认证和授权框架	https://spring.io/projects/spring-security
* MyBatis	ORM框架	http://www.mybatis.org/mybatis-3/zh/index.html
* MyBatisGenerator	数据层代码生成	http://www.mybatis.org/generator/index.html
* PageHelper	MyBatis物理分页插件	http://git.oschina.net/free/Mybatis_PageHelper
* Swagger-UI	文档生产工具	https://github.com/swagger-api/swagger-ui
* Hibernator-Validator	验证框架	http://hibernate.org/validator/
* Elasticsearch	搜索引擎	https://github.com/elastic/elasticsearch
* RabbitMq	消息队列	https://www.rabbitmq.com/
* Redis	分布式缓存	https://redis.io/
* MongoDb	NoSql数据库	https://www.mongodb.com/
* Docker	应用容器引擎	https://www.docker.com/
* JWT	JWT登录支持	https://github.com/jwtk/jjwt
* LogStash	日志收集	https://github.com/logstash/logstash-logback-encoder
* Lombok	简化对象封装工具	https://github.com/rzwitserloot/lombok
* Protobuf https://github.com/protocolbuffers/protobuf

## 开发工具
* IDEA          开发IDE				https://www.jetbrains.com/idea/download
* Git 			版本控制工具		https://git-scm.com/download/win
* RedisDesktop	redis客户端连接工具	https://redisdesktop.com/download
* Robomongo	    mongo客户端连接工具	https://robomongo.org/download
* PowerDesigner	数据库设计工具		http://powerdesigner.de/
* Axure	        原型设计工具		https://www.axure.com/
* MindMaster	思维导图设计工具	http://www.edrawsoft.cn/mindmaster
* Swagger							https://swagger.io/
* JDK	1.8	https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
* Mysql	5.7	https://www.mysql.com/
* Redis	3.2	https://redis.io/download
* Elasticsearch	6.2.2	https://www.elastic.co/downloads
* MongoDb	3.2	https://www.mongodb.com/download-center
* RabbitMq	3.7.14	http://www.rabbitmq.com/download.html
* Nginx	1.1	http://nginx.org/en/download.html

## 系统架构图
    ![](./document/image/architecture.png)    

## IDEA设置：
* 安装Plugin
  打开File --》Setting --》Plugins，输入Lombok，查找Lombok插件，点击Install进行安装
* 配置Git路径
打开File--》Setting--》Version Control，配置Path to Git executable为C:\Program Files\Git\bin\git.exe
* 配置terminal为Git终端
打开File --》Setting --》Tools -》Terminal，配置shell path为C:\Program Files\Git\bin\bash.exe

> 注意：