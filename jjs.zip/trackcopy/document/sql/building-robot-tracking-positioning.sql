-- 新建robot数据库
CREATE DATABASE IF NOT EXISTS `robot`;

USE `robot`;

SET FOREIGN_KEY_CHECKS=0;

-- 节点定义表
DROP TABLE IF EXISTS `node_define`;
CREATE TABLE `node_define` (
  `server_id` int(10) NOT NULL COMMENT '服务器id',
  `id` int(10) NOT NULL COMMENT '节点id',
  `name` varchar(64) NOT NULL COMMENT '节点名称',
  `category_id` int(10) NOT NULL COMMENT '节点分类id',
  `state` int(1) NOT NULL COMMENT '状态：0->失效；1->有效',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  `note` varchar(256) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`server_id`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='节点定义表';

-- 服务器属性表
DROP TABLE IF EXISTS `node_server_property`;
CREATE TABLE `node_server_property` (
  `id` int(10) NOT NULL COMMENT '服务器id',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  `modify_flag` int(1) NOT NULL COMMENT '修改标志，0->未修改，1->已修改，待服务端读取',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务器属性表';

-- 同步器属性表
DROP TABLE IF EXISTS `node_synchronizer_property`;
CREATE TABLE `node_synchronizer_property` (
  `server_id` int(10) NOT NULL COMMENT '服务器id',
  `id` int(10) NOT NULL COMMENT '节点id',
  `base_station_capacity` int(5) NOT NULL COMMENT '基站容量',
  `label_capacity` int(5) NOT NULL COMMENT '标签容量',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  `modify_flag` int(1) NOT NULL COMMENT '修改标志，0->未修改，1->已修改，待服务端读取',
  PRIMARY KEY (`server_id`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='同步器属性表';

-- 基站属性表
DROP TABLE IF EXISTS `node_basestation_property`;
CREATE TABLE `node_basestation_property` (
  `server_id` int(10) NOT NULL COMMENT '服务器id',
  `id` int(10) NOT NULL COMMENT '节点id',
  `role` int(3) NOT NULL COMMENT '基站角色，取值1，2，3	1=一级基站 2=二级基站 3=三级基站',
  `follow_main_id` int(5) NOT NULL COMMENT '从基站跟随主基站ID，从基站跟随主基站ID进行时钟同步',
  `slot_length` int(3) NOT NULL COMMENT '时隙长度',
  `slot_number` int(3) NOT NULL COMMENT '总时隙数目',
  `slot_reserve` int(3) NOT NULL COMMENT '预留时隙数',
  `antenna_delay_tx` int(5) NOT NULL COMMENT '天线延迟值Tx',
  `antenna_delay_rx` int(5) NOT NULL COMMENT '天线延迟值Rx',
  `channel` int(3) NOT NULL COMMENT '信道：1/2/3/4/5/7',
  `light_velocity` int(3) NOT NULL COMMENT '光速，取值0，1	',
  `uwb_velocity` int(3) NOT NULL COMMENT 'UWB速度，取值0，1	0=110K,1=850K,2=6.8M,3=27M',
  `uwb_peak_frequency` int(3) NOT NULL COMMENT 'UWB峰值重复频率，取值0，1	0=16,1=64',
  `preamble` int(3) NOT NULL COMMENT '前导码，取值0-23	0=32,1=64,2=128,…',
  `transmission_power` int(3) NOT NULL COMMENT '基站发送功率大小',
  `longitude` bigint(20) NOT NULL COMMENT 'RTK经度',
  `latitude` bigint(20) NOT NULL COMMENT 'RTK纬度',
  `height` bigint(20) NOT NULL COMMENT 'RTK高度',
  `tof_compensation` int(10) NOT NULL COMMENT '基站侧TOF补偿值，各基站与参考基站之间的飞行时间',
  `lan_id` int(5) NOT NULL COMMENT '局域网id',
  `delay_tx` int(5) NOT NULL COMMENT '基站延时Tx',
  `min_time_unit` int(3) NOT NULL COMMENT 'UWB最小测量时间单位',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  `modify_flag` int(1) NOT NULL COMMENT '修改标志，0->未修改，1->已修改，待服务端读取',
  PRIMARY KEY (`server_id`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='基站属性表';

-- 标签属性表
DROP TABLE IF EXISTS `node_label_property`;
CREATE TABLE `node_label_property` (
  `server_id` int(10) NOT NULL COMMENT '服务器id',
  `id` int(10) NOT NULL COMMENT '节点id',
  `role` int(3) NOT NULL COMMENT '标签角色,取值1，2，3	1=A类标签 2=B类标签 3=C类标签',
  `light_velocity` int(3) NOT NULL COMMENT '光速，取值0，1	',
  `antenna_delay_tx` int(5) NOT NULL COMMENT '天线延迟值Tx',
  `antenna_delay_rx` int(5) NOT NULL COMMENT '天线延迟值Rx',
  `channel` int(3) NOT NULL COMMENT '信道',
  `uwb_velocity` int(3) NOT NULL COMMENT 'UWB速度，取值0，1	0=110K,1=6.8M',
  `uwb_peak_frequency` int(3) NOT NULL COMMENT 'UWB峰值重复频率，取值0，1	0=16,1=64',
  `preamble` int(3) NOT NULL COMMENT '前导码，取值0-23: 0=32,1=64,2=128,…',
  `refresh_frequency` int(3) NOT NULL COMMENT '标签刷新频率',
  `upload_frequency` int(3) NOT NULL COMMENT '标签上传频率',
  `data_output_frequency` int(3) NOT NULL COMMENT '数据输出频率',
  `lan_id` int(5) NOT NULL COMMENT '局域网id',
  `min_time_unit` int(3) NOT NULL COMMENT 'UWB最小测量时间单位',
  `carrier_id` bigint(18) NOT NULL COMMENT '载体ID',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  `modify_flag` int(1) NOT NULL COMMENT '修改标志，0->未修改，1->已修改，待服务端读取',
  PRIMARY KEY (`server_id`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标签属性表';

-- 载体表
DROP TABLE IF EXISTS `node_carrier`;
CREATE TABLE `node_carrier` (
  `id` bigint(18) NOT NULL AUTO_INCREMENT COMMENT '载体ID',
  `name` varchar(256) NOT NULL COMMENT '载体名称',
  `icon_id` bigint comment '图标的ID',
  `state` int(1) NOT NULL COMMENT '状态：0->失效；1->有效',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000000000 DEFAULT CHARSET=utf8mb4 COMMENT='载体表';

-- 节点树表
DROP TABLE IF EXISTS `node_tree`;
CREATE TABLE `node_tree` (
  `server_id` int(10) NOT NULL COMMENT '服务器id',
  `node_id` int(10) NOT NULL COMMENT '节点id',
  `parent_node_id` int(10) NOT NULL COMMENT '父节点id',
  `state` int(1) NOT NULL COMMENT '状态：0->失效；1->有效',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`server_id`, `node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='节点树表';

-- 节点分类表
DROP TABLE IF EXISTS `node_category`;
CREATE TABLE `node_category` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '节点分类id',
  `name` varchar(64) NOT NULL COMMENT '节点分类名称',
  `type` int(1) NOT NULL COMMENT '类型：1->服务器；2->同步器；3->基站；4->标签',
  `level` int(3) NOT NULL COMMENT '分级级数',
  `state` int(1) NOT NULL COMMENT '状态：0->失效；1->有效',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  `note` varchar(256) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000000000 DEFAULT CHARSET=utf8mb4 COMMENT='节点分类表';

-- 节点统计信息表
DROP TABLE IF EXISTS `node_statistics`;
CREATE TABLE `node_statistics` (
  `server_id` int(10) NOT NULL COMMENT '服务器id',
  `node_id` int(10) NOT NULL COMMENT '节点id',
  `create_date` date NOT NULL COMMENT '创建日期',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  `upstream_traffic` varchar(256) NOT NULL COMMENT '节点上行数据量',
  `downstream_traffic` varchar(256) NOT NULL COMMENT '节点下行数据量',
  `class_a_quantity` varchar(256) NOT NULL COMMENT 'A类标签数量',
  `class_b_quantity` varchar(256) NOT NULL COMMENT 'B类标签数量',
  `class_c_quantity` varchar(256) NOT NULL COMMENT 'C类标签数量',
  PRIMARY KEY (`server_id`, `node_id`, `create_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='节点统计信息表';

-- 节点消息表
DROP TABLE IF EXISTS `node_message`;
CREATE TABLE `node_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '消息ID',
  `node_id` bigint(20) DEFAULT NULL COMMENT '节点ID',
  `server_id` bigint(20) DEFAULT NULL COMMENT '服务器ID',
  `category_id` bigint(20) DEFAULT NULL COMMENT '节点分类ID',
  `msg_type` varchar(20) DEFAULT NULL COMMENT '消息分类',
  `msg_body` varchar(500) DEFAULT NULL COMMENT '消息体',
  `eff_time` varchar(10) DEFAULT NULL COMMENT '有效时间',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `modify_time` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='节点消息表';

 /*
insert into `node_define` (`server_id`, `id`, `name`, `category_id`, `state`, `create_time`, `modify_time`, `note`) values (1001, 100100001, '服务器', 1001, 1, NOW(), NOW(), '');
insert into `node_define` (`server_id`, `id`, `name`, `category_id`, `state`, `create_time`, `modify_time`, `note`) values (1001, 100100002, '同步器', 2001, 1, NOW(), NOW(), '');
insert into `node_define` (`server_id`, `id`, `name`, `category_id`, `state`, `create_time`, `modify_time`, `note`) values (1001, 100100003, '一级基站', 3001, 1, NOW(), NOW(), '');
insert into `node_define` (`server_id`, `id`, `name`, `category_id`, `state`, `create_time`, `modify_time`, `note`) values (1001, 100100004, '二级基站', 3002, 1, NOW(), NOW(), '');

insert into `node_tree` (`server_id`, `node_id`, `parent_node_id`, `state`, `create_time`, `modify_time`) values (1001, 100100001, -1, 1, NOW(), NOW());
insert into `node_tree` (`server_id`, `node_id`, `parent_node_id`, `state`, `create_time`, `modify_time`) values (1001, 100100002, 100100001, 1, NOW(), NOW());
insert into `node_tree` (`server_id`, `node_id`, `parent_node_id`, `state`, `create_time`, `modify_time`) values (1001, 100100003, 100100002, 1, NOW(), NOW());
insert into `node_tree` (`server_id`, `node_id`, `parent_node_id`, `state`, `create_time`, `modify_time`) values (1001, 100100004, 100100002, 1, NOW(), NOW());
	
insert into `node_category` (`id`, `name`, `type`, `level`, `state`, `create_time`, `modify_time`, `note`) values (1001, '服务器', 1, 1, 1, now(), now(), '');
insert into `node_category` (`id`, `name`, `type`, `level`, `state`, `create_time`, `modify_time`, `note`) values (2001, '同步器', 2, 1, 1, now(), now(), '');
insert into `node_category` (`id`, `name`, `type`, `level`, `state`, `create_time`, `modify_time`, `note`) values (3001, '一级基站', 3, 1, 1, now(), now(), '');
insert into `node_category` (`id`, `name`, `type`, `level`, `state`, `create_time`, `modify_time`, `note`) values (3002, '二级基站', 3, 2, 1, now(), now(), '');
*/

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `icon` varchar(500) DEFAULT NULL COMMENT '头像',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `nick_name` varchar(200) DEFAULT NULL COMMENT '昵称',
  `note` varchar(500) DEFAULT NULL COMMENT '备注信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `status` int(1) DEFAULT '1' COMMENT '帐号启用状态：0->禁用；1->启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL COMMENT '名称',
  `description` varchar(500) DEFAULT NULL COMMENT '描述',
  `user_count` int(11) DEFAULT NULL COMMENT '用户数量',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `status` int(1) DEFAULT '1' COMMENT '启用状态：0->禁用；1->启用',
  `sort` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户角色表';

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) DEFAULT NULL COMMENT '父级权限id',
  `name` varchar(100) DEFAULT NULL COMMENT '名称',
  `value` varchar(200) DEFAULT NULL COMMENT '权限值',
  `icon` varchar(500) DEFAULT NULL COMMENT '图标',
  `type` int(1) DEFAULT NULL COMMENT '权限类型：0->目录；1->菜单；2->按钮（接口绑定权限）',
  `uri` varchar(200) DEFAULT NULL COMMENT '前端资源路径',
  `status` int(1) DEFAULT NULL COMMENT '启用状态；0->禁用；1->启用',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='后台用户权限表';

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='用户和角色关系表';

-- ----------------------------
-- Table structure for role_permission
-- ----------------------------
DROP TABLE IF EXISTS `role_permission`;
CREATE TABLE `role_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL,
  `permission_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='用户角色和权限关系表';

-- ----------------------------
-- Table structure for user_permission
-- ----------------------------
DROP TABLE IF EXISTS `user_permission`;
CREATE TABLE `user_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `permission_id` bigint(20) DEFAULT NULL,
  `type` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户和权限关系表(除角色中定义的权限以外的加减权限)';

-- ----------------------------
-- Table structure for track_sum_cm
-- ----------------------------
CREATE TABLE `track_sum_cm` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tag_code` varchar(50) DEFAULT NULL COMMENT '标签编码',
  `coordinate` varchar(50) DEFAULT NULL COMMENT '坐标',
  `time` datetime DEFAULT NULL COMMENT '时间',
  `x_axis` decimal(16,4) DEFAULT NULL COMMENT 'X轴',
  `y_axis` decimal(16,4) DEFAULT NULL COMMENT 'Y轴',
  `z_axis` decimal(16,4) DEFAULT NULL COMMENT 'Z轴',
  `speed` decimal(16,4) DEFAULT NULL COMMENT '速度',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='轨迹汇总表(精度1厘米)';

-- ----------------------------
-- Table structure for track_sum_dm
-- ----------------------------
CREATE TABLE `track_sum_dm` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tag_code` varchar(50) DEFAULT NULL COMMENT '标签编码',
  `coordinate` varchar(50) DEFAULT NULL COMMENT '坐标',
  `time` datetime DEFAULT NULL COMMENT '时间',
  `x_axis` decimal(16,4) DEFAULT NULL COMMENT 'X轴',
  `y_axis` decimal(16,4) DEFAULT NULL COMMENT 'Y轴',
  `z_axis` decimal(16,4) DEFAULT NULL COMMENT 'Z轴',
  `speed` decimal(16,4) DEFAULT NULL COMMENT '速度',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='轨迹汇总表(精度1分米)';

-- ----------------------------
-- Table structure for track_sum_m
-- ----------------------------
CREATE TABLE `track_sum_m` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tag_code` varchar(50) DEFAULT NULL COMMENT '标签编码',
  `coordinate` varchar(50) DEFAULT NULL COMMENT '坐标',
  `time` datetime DEFAULT NULL COMMENT '时间',
  `x_axis` decimal(16,4) DEFAULT NULL COMMENT 'X轴',
  `y_axis` decimal(16,4) DEFAULT NULL COMMENT 'Y轴',
  `z_axis` decimal(16,4) DEFAULT NULL COMMENT 'Z轴',
  `speed` decimal(16,4) DEFAULT NULL COMMENT '速度',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='轨迹汇总表(精度1米)';

-- ----------------------------
-- Table structure for track_merge
-- ----------------------------
CREATE TABLE `track_merge` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tag_code` varchar(50) DEFAULT NULL COMMENT '标签编码',
  `coordinate_list` text COMMENT '坐标列表',
  `time` datetime DEFAULT NULL COMMENT '时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='轨迹记录合并表';

-- ----------------------------
-- Table 图标信息表
-- ----------------------------
DROP TABLE IF EXISTS `icon_data`;
CREATE TABLE `icon_data`
(
    `id`           bigint       not null auto_increment primary key,
    `name`         varchar(255) not null comment '图标的名称',
    `icon_type`    int          not null comment '图标类型',
    `size`      int(11)     default '0' comment '文件的大小单位B',
    `icon_file_type`    varchar(10)      not null comment '图标文件的类型',
    `icon_file_id` bigint       not null comment '图标文件的id'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8 COMMENT ='图标信息表';

-- ----------------------------
-- Table 图标文件表
-- ----------------------------
drop table if exists `icon_file_data`;
create table `icon_file_data`
(
    `id`        bigint(20) not null auto_increment,
    `name`      varchar(100) comment '图标文件的名称',
    `file_info` BLOB(1048576) comment '二进制文件信息最大1M',
    primary key (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8 COMMENT ='图标文件信息表';

-- 添加外键约束 图标与其对应的图标文件
ALTER TABLE `icon_data` add CONSTRAINT `fk_icon_file_id` FOREIGN KEY(`icon_file_id`)
    REFERENCES `icon_file_data`(`id`) on  delete CASCADE;
-- 添加索引
alter table track_merge add index idx_tagcode_time(tag_code, time);
alter table track_sum_cm add index idx_tagcode_time(tag_code, time);
alter table track_sum_dm add index idx_tagcode_time(tag_code, time);
alter table track_sum_m add index idx_tagcode_time(tag_code, time);


-- ----------------------------
-- Table structure for track_standard_point
-- ----------------------------
DROP TABLE IF EXISTS `track_standard_point`;
CREATE TABLE `track_standard_point` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `area_code` varchar(32) NOT NULL ,
  `area_desc` varchar(255) ,
  `longitude` DECIMAL(16,8) DEFAULT NULL,
  `latitude` DECIMAL(16,8) DEFAULT NULL,
  `created_timestamp` datetime DEFAULT NULL COMMENT '创建时间',
  `modified_timestamp` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='轨迹基准点';

-- 创建唯一索引
CREATE UNIQUE INDEX IDX_AREA_CODE ON track_standard_point(area_code);

------------------------------------Quartz 脚本 begin----------------------------------

-- 存储每一个已配置的 Job 的详细信息
CREATE TABLE qrtz_job_details
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    JOB_NAME  VARCHAR2(200) NOT NULL,
    JOB_GROUP VARCHAR2(200) NOT NULL,
    DESCRIPTION VARCHAR2(250) NULL,
    JOB_CLASS_NAME   VARCHAR2(250) NOT NULL,
    IS_DURABLE VARCHAR2(1) NOT NULL,
    IS_NONCONCURRENT VARCHAR2(1) NOT NULL,
    IS_UPDATE_DATA VARCHAR2(1) NOT NULL,
    REQUESTS_RECOVERY VARCHAR2(1) NOT NULL,
    JOB_DATA BLOB NULL,
    CONSTRAINT QRTZ_JOB_DETAILS_PK PRIMARY KEY (SCHED_NAME,JOB_NAME,JOB_GROUP)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Job的详细信息';

--  存储已配置的 Trigger 的信息
CREATE TABLE qrtz_triggers
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    JOB_NAME  VARCHAR2(200) NOT NULL,
    JOB_GROUP VARCHAR2(200) NOT NULL,
    DESCRIPTION VARCHAR2(250) NULL,
    NEXT_FIRE_TIME NUMBER(13) NULL,
    PREV_FIRE_TIME NUMBER(13) NULL,
    PRIORITY NUMBER(13) NULL,
    TRIGGER_STATE VARCHAR2(16) NOT NULL,
    TRIGGER_TYPE VARCHAR2(8) NOT NULL,
    START_TIME NUMBER(13) NOT NULL,
    END_TIME NUMBER(13) NULL,
    CALENDAR_NAME VARCHAR2(200) NULL,
    MISFIRE_INSTR NUMBER(2) NULL,
    JOB_DATA BLOB NULL,
    CONSTRAINT QRTZ_TRIGGERS_PK PRIMARY KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP),
    CONSTRAINT QRTZ_TRIGGER_TO_JOBS_FK FOREIGN KEY (SCHED_NAME,JOB_NAME,JOB_GROUP)
      REFERENCES QRTZ_JOB_DETAILS(SCHED_NAME,JOB_NAME,JOB_GROUP)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Trigger信息';
-- 存储简单的 Trigger，包括重复次数，间隔，以及已触的次数
CREATE TABLE qrtz_simple_triggers
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    REPEAT_COUNT NUMBER(7) NOT NULL,
    REPEAT_INTERVAL NUMBER(12) NOT NULL,
    TIMES_TRIGGERED NUMBER(10) NOT NULL,
    CONSTRAINT QRTZ_SIMPLE_TRIG_PK PRIMARY KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP),
    CONSTRAINT QRTZ_SIMPLE_TRIG_TO_TRIG_FK FOREIGN KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP)
  REFERENCES QRTZ_TRIGGERS(SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='简单Trigger信息';

-- 存储 Cron Trigger，包括 Cron 表达式和时区信息
CREATE TABLE qrtz_cron_triggers
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    CRON_EXPRESSION VARCHAR2(120) NOT NULL,
    TIME_ZONE_ID VARCHAR2(80),
    CONSTRAINT QRTZ_CRON_TRIG_PK PRIMARY KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP),
    CONSTRAINT QRTZ_CRON_TRIG_TO_TRIG_FK FOREIGN KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP)
      REFERENCES QRTZ_TRIGGERS(SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Cron Trigger信息';

CREATE TABLE qrtz_simprop_triggers
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    STR_PROP_1 VARCHAR2(512) NULL,
    STR_PROP_2 VARCHAR2(512) NULL,
    STR_PROP_3 VARCHAR2(512) NULL,
    INT_PROP_1 NUMBER(10) NULL,
    INT_PROP_2 NUMBER(10) NULL,
    LONG_PROP_1 NUMBER(13) NULL,
    LONG_PROP_2 NUMBER(13) NULL,
    DEC_PROP_1 NUMERIC(13,4) NULL,
    DEC_PROP_2 NUMERIC(13,4) NULL,
    BOOL_PROP_1 VARCHAR2(1) NULL,
    BOOL_PROP_2 VARCHAR2(1) NULL,
    CONSTRAINT QRTZ_SIMPROP_TRIG_PK PRIMARY KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP),
    CONSTRAINT QRTZ_SIMPROP_TRIG_TO_TRIG_FK FOREIGN KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP)
      REFERENCES QRTZ_TRIGGERS(SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='simprop Trigger信息';

-- Trigger 作为 Blob 类型存储(用于 Quartz 用户用 JDBC 创建他们自己定制的 Trigger 类型，<span style="color:#800080;">JobStore</span> 并不知道如何存储实例的时候)
CREATE TABLE qrtz_blob_triggers
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    BLOB_DATA BLOB NULL,
    CONSTRAINT QRTZ_BLOB_TRIG_PK PRIMARY KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP),
    CONSTRAINT QRTZ_BLOB_TRIG_TO_TRIG_FK FOREIGN KEY (SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Trigger Blob类型存储信息';

-- 以 Blob 类型存储 Quartz 的 Calendar 信息
CREATE TABLE qrtz_calendars
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    CALENDAR_NAME  VARCHAR2(200) NOT NULL,
    CALENDAR BLOB NOT NULL,
    CONSTRAINT QRTZ_CALENDARS_PK PRIMARY KEY (SCHED_NAME,CALENDAR_NAME)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Quartz的Blob类型Calendar信息';

-- 存储已暂停的 Trigger 组的信息
CREATE TABLE qrtz_paused_trigger_grps
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_GROUP  VARCHAR2(200) NOT NULL,
    CONSTRAINT QRTZ_PAUSED_TRIG_GRPS_PK PRIMARY KEY (SCHED_NAME,TRIGGER_GROUP)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='暂停的Trigger信息';

-- 存储与已触发的 Trigger 相关的状态信息，以及相联 Job 的执行信息
CREATE TABLE qrtz_fired_triggers
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    ENTRY_ID VARCHAR2(95) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    INSTANCE_NAME VARCHAR2(200) NOT NULL,
    FIRED_TIME NUMBER(13) NOT NULL,
    SCHED_TIME NUMBER(13) NOT NULL,
    PRIORITY NUMBER(13) NOT NULL,
    STATE VARCHAR2(16) NOT NULL,
    JOB_NAME VARCHAR2(200) NULL,
    JOB_GROUP VARCHAR2(200) NULL,
    IS_NONCONCURRENT VARCHAR2(1) NULL,
    REQUESTS_RECOVERY VARCHAR2(1) NULL,
    CONSTRAINT QRTZ_FIRED_TRIGGER_PK PRIMARY KEY (SCHED_NAME,ENTRY_ID)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='存储与已触发的Trigger相关的状态信息';

-- 存储少量的有关 Scheduler 的状态信息，和别的 Scheduler 实例(假如是用于一个集群中)
CREATE TABLE qrtz_scheduler_state
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    INSTANCE_NAME VARCHAR2(200) NOT NULL,
    LAST_CHECKIN_TIME NUMBER(13) NOT NULL,
    CHECKIN_INTERVAL NUMBER(13) NOT NULL,
    CONSTRAINT QRTZ_SCHEDULER_STATE_PK PRIMARY KEY (SCHED_NAME,INSTANCE_NAME)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='存储少量的有关Scheduler的状态信息';

-- 存储程序的悲观锁的信息(假如使用了悲观锁)
CREATE TABLE qrtz_locks
  (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    LOCK_NAME  VARCHAR2(40) NOT NULL,
    CONSTRAINT QRTZ_LOCKS_PK PRIMARY KEY (SCHED_NAME,LOCK_NAME)
)ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='存储程序的悲观锁的信息';

create index idx_qrtz_j_req_recovery on qrtz_job_details(SCHED_NAME,REQUESTS_RECOVERY);
create index idx_qrtz_j_grp on qrtz_job_details(SCHED_NAME,JOB_GROUP);

create index idx_qrtz_t_j on qrtz_triggers(SCHED_NAME,JOB_NAME,JOB_GROUP);
create index idx_qrtz_t_jg on qrtz_triggers(SCHED_NAME,JOB_GROUP);
create index idx_qrtz_t_c on qrtz_triggers(SCHED_NAME,CALENDAR_NAME);
create index idx_qrtz_t_g on qrtz_triggers(SCHED_NAME,TRIGGER_GROUP);
create index idx_qrtz_t_state on qrtz_triggers(SCHED_NAME,TRIGGER_STATE);
create index idx_qrtz_t_n_state on qrtz_triggers(SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP,TRIGGER_STATE);
create index idx_qrtz_t_n_g_state on qrtz_triggers(SCHED_NAME,TRIGGER_GROUP,TRIGGER_STATE);
create index idx_qrtz_t_next_fire_time on qrtz_triggers(SCHED_NAME,NEXT_FIRE_TIME);
create index idx_qrtz_t_nft_st on qrtz_triggers(SCHED_NAME,TRIGGER_STATE,NEXT_FIRE_TIME);
create index idx_qrtz_t_nft_misfire on qrtz_triggers(SCHED_NAME,MISFIRE_INSTR,NEXT_FIRE_TIME);
create index idx_qrtz_t_nft_st_misfire on qrtz_triggers(SCHED_NAME,MISFIRE_INSTR,NEXT_FIRE_TIME,TRIGGER_STATE);
create index idx_qrtz_t_nft_st_misfire_grp on qrtz_triggers(SCHED_NAME,MISFIRE_INSTR,NEXT_FIRE_TIME,TRIGGER_GROUP,TRIGGER_STATE);

create index idx_qrtz_ft_trig_inst_name on qrtz_fired_triggers(SCHED_NAME,INSTANCE_NAME);
create index idx_qrtz_ft_inst_job_req_rcvry on qrtz_fired_triggers(SCHED_NAME,INSTANCE_NAME,REQUESTS_RECOVERY);
create index idx_qrtz_ft_j_g on qrtz_fired_triggers(SCHED_NAME,JOB_NAME,JOB_GROUP);
create index idx_qrtz_ft_jg on qrtz_fired_triggers(SCHED_NAME,JOB_GROUP);
create index idx_qrtz_ft_t_g on qrtz_fired_triggers(SCHED_NAME,TRIGGER_NAME,TRIGGER_GROUP);

create index idx_qrtz_ft_tg on qrtz_fired_triggers(SCHED_NAME,TRIGGER_GROUP);

---------------------------Quartz 脚本 end-----------------------------------