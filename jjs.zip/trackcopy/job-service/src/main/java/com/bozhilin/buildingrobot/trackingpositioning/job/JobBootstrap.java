package com.bozhilin.buildingrobot.trackingpositioning.job;

import com.bozhilin.buildingrobot.trackingpositioning.common.util.BeanUtils;
import com.bozhilin.buildingrobot.trackingpositioning.job.BaseJob;
import com.bozhilin.buildingrobot.trackingpositioning.job.service.JobService;

import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * @Author: pengjunming
 * @Date:2019/9/18 16:34
 * @Description: job启动器，在系统启动的时候加载配置的job，并且启动配置的job
 */
@Component
@Slf4j
public class JobBootstrap implements CommandLineRunner {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private JobService jobService;

    @Autowired
    private JobConfig jobConfig;

    @Override
    public void run(String... args) throws Exception {
        log.info("Start to bootstrap job.");
        bootstrap();
    }

    private void bootstrap() throws SchedulerException {
        if (CollectionUtils.isEmpty(jobConfig.getBootstrapJobs())) {
            return;
        }
        for (String job : jobConfig.getBootstrapJobs()) {
            Object baseJob = BeanUtils.getBean(job);
            if (!(baseJob instanceof BaseJob)) {
                log.error("Job [{}] is not the subclass of BaseJob", job);
                continue;
            }
            log.info("Job [{}] starting up.", job);
            jobService.create(((BaseJob) baseJob).createScheduleContext());
        }
    }

    @Configuration
    @ConfigurationProperties(prefix = "quartz")
    @Data
    public static class JobConfig {

        private List<String> bootstrapJobs;

        public void setBootstrapJobs(List<String> bootstrapJobs) {
            this.bootstrapJobs = bootstrapJobs;
        }
    }
}
