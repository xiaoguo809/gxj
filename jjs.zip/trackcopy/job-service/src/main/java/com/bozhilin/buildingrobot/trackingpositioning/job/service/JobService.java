package com.bozhilin.buildingrobot.trackingpositioning.job.service;/**
 * @author :  pengjunming
 * @date :   10:23
 */


import com.bozhilin.buildingrobot.trackingpositioning.job.SchedulerContext;

import org.quartz.SchedulerException;

/**
 * @Author: pengjunming
 * @Date:2019/9/17 10:23
 * @Description: Job的通用服务接口
 */
public interface JobService {

    /**
     * 创建一个job
     * @param context
     */
    void create(SchedulerContext context) throws SchedulerException;

    /**
     * 刷新一个存在的job
     * @param context
     */
    void refresh(SchedulerContext context) throws SchedulerException;

    /**
     * 挂起一个job
     * @param context
     */
    void pause(SchedulerContext context);

    /**
     * 恢复一个job
     * @param context
     */
    void resume(SchedulerContext context);

    /**
     * 删除一个job
     * @param context
     */
    void delete(SchedulerContext context) throws SchedulerException;
}
