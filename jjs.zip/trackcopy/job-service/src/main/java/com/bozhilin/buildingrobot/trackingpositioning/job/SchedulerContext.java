package com.bozhilin.buildingrobot.trackingpositioning.job;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.ResultCode;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.ServiceException;

import org.quartz.CronExpression;
import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;

import java.util.Map;
import java.util.regex.Pattern;

import lombok.Data;

/**
 * @Author: pengjunming
 * @Date:2019/9/17 10:35
 * @Description:
 */
@Data
public class SchedulerContext {
    //校验正整数的正则表达式
    private Pattern validIntervalMatcher = Pattern.compile("^[1-9]\\d*$");

    private Trigger trigger;

    private String name;

    private String group;

    private TriggerType triggerType;

    private String expression;

    private Class<? extends Job> jobClz;

    private Map<String, String> params;

    public SchedulerContext(String name, String group) {
        this.name = name;
        this.group = group;
    }

    public SchedulerContext(String name, String group, TriggerType triggerType, String expression) {
        this.name = name;
        this.group = group;
        this.triggerType = triggerType;
        this.expression = expression;
    }

    public SchedulerContext(String name, String group, Class jobClz, TriggerType triggerType, String expression) {
        this.name = name;
        this.group = group;
        this.triggerType = triggerType;
        this.expression = expression;
        this.jobClz = jobClz;
    }

    public SchedulerContext(String name, String group, Class jobClz, TriggerType triggerType, String expression,
                            Map<String, String> params) {
        this.name = name;
        this.group = group;
        this.triggerType = triggerType;
        this.expression = expression;
        this.jobClz = jobClz;
        this.params = params;
    }

    public TriggerKey getTriggerKey() {
        return new TriggerKey(this.name, this.group);
    }

    public Trigger getTrigger() {
        if (this.triggerType == TriggerType.CRON) {
            if (this.expression == null || !CronExpression.isValidExpression(this.expression)) {
                throw new ServiceException(ResultCode.VALIDATE_FAILED);
            }
            return
                    TriggerBuilder.newTrigger().withIdentity(name, group)
                            .withSchedule(CronScheduleBuilder.cronSchedule(this.expression)).build();
        }
        if(!validIntervalMatcher.matcher(this.expression).matches()){
            throw new ServiceException(ResultCode.VALIDATE_FAILED);
        }

        return TriggerBuilder.newTrigger().withIdentity(name, group)
                .withSchedule(SimpleScheduleBuilder.repeatSecondlyForever(Integer.parseInt(this.expression))).build();
    }

    public JobDetail getJobDetail() {
        JobBuilder jobBuilder = JobBuilder.newJob(jobClz)
                .withIdentity(name, group);
        if (params != null && params.size() > 0) {
            params.forEach((k, v) -> jobBuilder.usingJobData(k, v));
        }
        return jobBuilder.build();
    }

    public JobKey getJobKey() {
        return new JobKey(this.name, this.group);
    }
}
