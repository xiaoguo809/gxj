package com.bozhilin.buildingrobot.trackingpositioning.job.service.impl;


import com.bozhilin.buildingrobot.trackingpositioning.job.SchedulerContext;
import com.bozhilin.buildingrobot.trackingpositioning.job.service.JobService;

import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * @Author: pengjunming
 * @Date:2019/9/17 14:25
 * @Description:
 */
@Slf4j
@Component
public class JobServiceImpl implements JobService {

    @Autowired
    private Scheduler scheduler;

    @Override
    public void create(SchedulerContext context) throws SchedulerException {
        JobDetail jobDetail = scheduler.getJobDetail(new JobKey(context.getName(), context.getGroup()));
        if(jobDetail == null){
            scheduler.scheduleJob(context.getJobDetail(), context.getTrigger());
            log.info("Created job [{}] success.", context.getName());
            return ;
        }
        log.warn("Job [{}] is exists.", context.getName());
    }

    @Override
    public void refresh(SchedulerContext context) throws SchedulerException {
        scheduler.rescheduleJob(context.getTriggerKey(), context.getTrigger());
        log.info("Refresh job [{}] success.", context.getName());
    }

    @Override
    public void pause(SchedulerContext context) {
        //TODO(pengjunming)
    }

    @Override
    public void resume(SchedulerContext context) {
        //TODO(pengjunming)
    }

    @Override
    public void delete(SchedulerContext context) throws SchedulerException {
        JobKey jobKey = context.getJobKey();
        JobDetail jobDetail = scheduler.getJobDetail(jobKey);
        if (jobDetail == null){
            log.warn("Job [{}] is not exists.", context.getName());
            return;
        }
        scheduler.deleteJob(jobKey);
        log.info("Deleted job [{}] success.", context.getName());
    }
}
