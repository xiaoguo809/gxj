package com.bozhilin.buildingrobot.trackingpositioning.job;

/**
 * @author :  pengjunming
 * @date :   10:54
 */
public enum TriggerType {
    SIMPLE,
    CRON
}
