package com.bozhilin.buildingrobot.trackingpositioning.job;

import org.springframework.scheduling.quartz.QuartzJobBean;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * @Author: pengjunming
 * @Date:2019/9/23 19:51
 * @Description:
 */
public abstract class BaseJob<T> extends QuartzJobBean {

    // 消息体类型
    private Class<T> modelClz;

    public BaseJob(){
        // 1获取子类的class(在创建子类对象的时候,会返回父类的构造方法)
        Class<? extends BaseJob> clazz = this.getClass();
        // 2获取当前类的带有泛型的父类类型
        ParameterizedType type = (ParameterizedType) clazz.getGenericSuperclass();
        // 3返回实际参数类型(泛型可以写多个)
        Type[] types = type.getActualTypeArguments();
        // 4 获取第一个参数(泛型的具体类)
        modelClz = (Class) types[0];
    }


    public SchedulerContext createScheduleContext(){
        return new SchedulerContext(getName(), getGroup(),
                modelClz, getTriggerType(), getExpression());
    }

    /**
     * 获取job对应的Group
     * @return
     */
    public abstract String getGroup();

    /**
     * 获取job对应的name
     * @return
     */
    public abstract String getName();

    /**
     * 获取表达式,可以是数字(代表时间间隔)，或者cron表达式
     * @return
     */
    public abstract String getExpression();

    /**
     * job的触发类型
     * @return
     */
    public abstract TriggerType getTriggerType();


}
