package com.bozhilin.buildingrobot.trackingpositioning.job;/**
 * @author :  pengjunming
 * @date :   9:36
 */

import org.quartz.Scheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

/**
 *@Author: pengjunming
 *@Date:2019/9/17 9:36
 *@Description:
 *
 */
@Configuration
public class SchedulerConfig {

    @Autowired
    private AutowireJobFactory  autowireJobFactory;

    @Bean
    public SchedulerFactoryBean schedulerFactoryBean(){
        SchedulerFactoryBean factory = new SchedulerFactoryBean();
        factory.setJobFactory(autowireJobFactory);
        return factory;
    }

    @Bean
    public Scheduler scheduler() {
        return schedulerFactoryBean().getScheduler();
    }
}
