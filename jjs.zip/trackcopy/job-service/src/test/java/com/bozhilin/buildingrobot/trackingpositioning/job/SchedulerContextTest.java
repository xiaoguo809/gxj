package com.bozhilin.buildingrobot.trackingpositioning.job;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.ResultCode;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.ServiceException;

import org.junit.Assert;
import org.junit.Test;
import org.quartz.CronScheduleBuilder;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;

/**
 * @Author: pengjunming
 * @Date:2019/9/19 10:54
 * @Description:
 */
public class SchedulerContextTest extends BaseTest {

    private static final String NAME = "name";
    private static final String GROUP = "group";
    private static final String VALID_CRON = "*/5 * * * * ?";
    private static final String INVALID_CRON = "*/61 * * * * ?";
    private static final String VALID_SIMPLE_EXPRESSION = "1";
    private static final String INVALID_SIMPLE_EXPRESSION = "-1";

    @Test
    public void testGetTriggerInCron() {
        SchedulerContext context = new SchedulerContext(NAME, GROUP, TriggerType.CRON, VALID_CRON);
        Trigger trigger = context.getTrigger();
        Assert.assertNotNull("Created trigger", trigger);
        Assert.assertNotNull("TriggerKey of created trigger", trigger.getKey());
        Assert.assertEquals("Name of trigger key", NAME, trigger.getKey().getName());
        Assert.assertEquals("Group of trigger key", GROUP, trigger.getKey().getGroup());
        Assert.assertNotNull("ScheduleBuilder of trigger", trigger.getScheduleBuilder());
        Assert.assertTrue("ScheduleBuilder is instanceof CronScheduleBuilder", trigger.getScheduleBuilder() instanceof CronScheduleBuilder);
    }

    @Test
    public void testGetTriggerFailedOnInvalidCron() {
        SchedulerContext context = new SchedulerContext(NAME, GROUP, TriggerType.CRON, INVALID_CRON);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        context.getTrigger();
    }

    @Test
    public void testGetTriggerInSimple() {
        SchedulerContext context = new SchedulerContext(NAME, GROUP, TriggerType.SIMPLE, VALID_SIMPLE_EXPRESSION);
        Trigger trigger = context.getTrigger();
        Assert.assertNotNull("Created trigger", trigger);
        Assert.assertNotNull("TriggerKey of created trigger", trigger.getKey());
        Assert.assertEquals("Name of trigger key", NAME, trigger.getKey().getName());
        Assert.assertEquals("Group of trigger key", GROUP, trigger.getKey().getGroup());
        Assert.assertNotNull("ScheduleBuilder of trigger", trigger.getScheduleBuilder());
        Assert.assertTrue("ScheduleBuilder is instanceof SimpleScheduleBuilder", trigger.getScheduleBuilder() instanceof SimpleScheduleBuilder);
    }

    @Test
    public void testGetTriggerFailedOnInvalidExpression() {
        SchedulerContext context = new SchedulerContext(NAME, GROUP, TriggerType.CRON, INVALID_CRON);
        thrown.expect(ServiceException.class);
        thrown.expectMessage(ResultCode.VALIDATE_FAILED.getMessage());
        context.getTrigger();
    }
}
