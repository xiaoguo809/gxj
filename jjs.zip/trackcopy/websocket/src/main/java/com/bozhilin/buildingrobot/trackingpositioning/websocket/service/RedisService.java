package com.bozhilin.buildingrobot.trackingpositioning.websocket.service;

import java.util.concurrent.TimeUnit;

/**
 * @Author pengjunming
 * @Date  2019/9/23 22:01
 * @Description Redis服务类，封装redisTemplate的操作
 **/
public interface RedisService {

    String get(String key);

    void set(String key, String value, long expireTime, TimeUnit seconds);

    void set(String key, String value);

    boolean processWhileLock(String key, int retryTimes, long intervalTime, Processor processor);

    void increment(String key);

    void decrement(String key);
}
