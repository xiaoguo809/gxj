package com.bozhilin.buildingrobot.trackingpositioning.websocket.service;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessage;

public interface NodeMessageService {
    int create(NodeMessage nodeCommand);
}
