package com.bozhilin.buildingrobot.trackingpositioning.websocket.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.mapper.NodeMessageMapper;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessage;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.service.NodeMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * NodeDefineService
 * Created by lupeihui on 2019/10/5
 */
@Service
public class NodeMessageServiceImpl implements NodeMessageService {
    @Autowired
    private NodeMessageMapper nodeMessageMapper;

    @Override
    public int create(NodeMessage nodeCommand) {
        return nodeMessageMapper.insert(nodeCommand);
    }
}
