package com.bozhilin.buildingrobot.trackingpositioning.websocket.model;/**
 * @author :  pengjunming
 * @date :   16:10
 */

import java.util.List;

import lombok.Data;

/**
 * @Author: pengjunming
 * @Date:2019/8/27 16:10
 * @Description:
 */
@Data
public class AreaInfoParam {

    /**
     * 指定的areaCode
     */
    private String areaCode;

    /**
     * 指定areaCode下的所有标签id
     */
    private List<LabelPrimaryKey> ids;

    /**
     * 推送的时间间隔信息。
     */
    private IntervalInfo intervalInfo;

    /**
     * 采样的数量
     */
    private Integer sampleAmount;

    @Data
    public static class LabelPrimaryKey {
        private String id;
    }

    @Data
    public static class IntervalInfo{

        private Integer interval;

        private DateType type;
    }

}
