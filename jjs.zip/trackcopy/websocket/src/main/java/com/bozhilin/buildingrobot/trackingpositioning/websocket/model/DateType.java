package com.bozhilin.buildingrobot.trackingpositioning.websocket.model;

public enum DateType {
    SECOND,
    MINUTE,
    HOUR,
    DAY
}
