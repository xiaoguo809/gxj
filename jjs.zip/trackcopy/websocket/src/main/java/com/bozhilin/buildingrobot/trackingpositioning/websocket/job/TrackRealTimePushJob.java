package com.bozhilin.buildingrobot.trackingpositioning.websocket.job;

import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackContext;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackSum;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.model.TagTrackResponse;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.server.WebSocketServer;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;

/**
 * @Author: pengjunming
 * @Date:2019/9/17 14:27
 * @Description:
 */
@Slf4j
public class TrackRealTimePushJob extends QuartzJobBean {

    public static final String TRACK_REAL_TIME_PUSH_GROUP = "TRACK_REAL_TIME_PUSH_GROUP";

    public static final String AREA_CODE_KEY_NAME = "AREA_CODE";

    @Autowired
    private TrackContext trackContext;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        JobDataMap map = context.getJobDetail().getJobDataMap();
        String areaCode = map.getString(AREA_CODE_KEY_NAME);
        Set<String> labels = stringRedisTemplate.opsForSet().members(trackContext.getAreaToLabelsKey(areaCode));
        if (CollectionUtils.isEmpty(labels)) {
            log.warn("No label mapping found associate with area:[{}]", areaCode);
            return;
        }
        // 查询所有展示中的区域
        List<TagTrackResponse> responses = new ArrayList<>();
        for (String label : labels) {
            String sampleAmount = stringRedisTemplate.opsForValue().get(trackContext.getAreaSampleAmoutKey(areaCode));
            // 按时间倒序取出所有记录
            Set<String> results = stringRedisTemplate.opsForZSet().reverseRange(trackContext.getLabelAllPayloadKey(areaCode, label), 0, -1);
            if (!CollectionUtils.isEmpty(results)) {
                //获取最新的那条记录
                String labelPerSecondPayloadKey = results.iterator().next();
                List<String> payloads = stringRedisTemplate.opsForList().range(labelPerSecondPayloadKey, 0, -1);
                // 移除标签所有每一秒的结果集
                stringRedisTemplate.execute(new RedisCallback<Boolean>() {
                    @Override
                    public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
                        connection.openPipeline();
                        for (String labelPerSecondKey : results) {
                            connection.del(labelPerSecondKey.getBytes());
                        }
                        connection.closePipeline();
                        return true;
                    }
                });
                //删除历史数据,数量为当前查询的结果集长度
                stringRedisTemplate.opsForZSet().removeRange(trackContext.getLabelAllPayloadKey(areaCode, label), 0, results.size() - 1);
                if (!StringUtil.isEmpty(sampleAmount)) {
                    payloads = filterBySampleAmout(payloads, Integer.valueOf(sampleAmount));
                }
                for (String payload : payloads) {
                    TrackSum track = JSON.parseObject(payload, TrackSum.class);
                    responses.add(new TagTrackResponse(track));
                }
            }
        }
        if (responses.size() > 0) {
            // 推送给该区域的订阅目的地
            WebSocketServer.sendInfo(areaCode, JSON.toJSONString(responses));
        }
    }

    /**
     * 对结果集进行采样
     */
    private List<String> filterBySampleAmout(List<String> payloads, Integer sampleAmount) {
        int size = payloads.size();
        if (size <= sampleAmount) {
            return payloads;
        }
        int interval = size / sampleAmount;
        List<String> filteredResult = new ArrayList<>(sampleAmount);
        for (int i = 0; i < sampleAmount; i++) {
            int index = i * interval + i;
            if (index >= size) {
                index = size - 1;
            }
            filteredResult.add(payloads.get(index));
        }
        return filteredResult;
    }
}
