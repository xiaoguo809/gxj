package com.bozhilin.buildingrobot.trackingpositioning.websocket.controller;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.CommonResult;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.ResultCode;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;

import com.bozhilin.buildingrobot.trackingpositioning.websocket.model.AreaInfoParam;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.server.UpWebSocketServer;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.service.TrackWebSocketService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import lombok.extern.slf4j.Slf4j;


/**
 * @Author: pengjunming
 * @Date:2019/9/23 10:22
 * @Description:
 */

@Controller
@Slf4j
public class WebSocketController {

    @Autowired
    private TrackWebSocketService trackWebSocketService;

    @ResponseBody
    @PostMapping("/area/ids")
    public CommonResult subscribe(@RequestBody AreaInfoParam body) {
        if (StringUtil.isEmpty(body.getAreaCode())) {
            log.warn("Parameter [areaCode] should not be empty.");
            return CommonResult.failed(ResultCode.VALIDATE_FAILED);
        }
        trackWebSocketService.refreshAreaLabelMapping(body);
        return CommonResult.success(null);
    }


    @ResponseBody
    @RequestMapping("/socket/push/{sid}")
    public CommonResult pushToWeb(@PathVariable String sid, String message) {
        try {
            UpWebSocketServer.sendInfo(sid, message);
        } catch (Exception e) {
            e.printStackTrace();
            return CommonResult.failed(sid + "#" + e.getMessage());
        }
        return CommonResult.success(sid);
    }

}
