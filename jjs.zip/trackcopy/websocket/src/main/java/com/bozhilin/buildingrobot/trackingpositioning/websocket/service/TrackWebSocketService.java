package com.bozhilin.buildingrobot.trackingpositioning.websocket.service;


import com.bozhilin.buildingrobot.trackingpositioning.websocket.model.AreaInfoParam;

/**
 * @Author: pengjunming
 * @Date:2019/9/17 16:51
 * @Description:
 */
public interface TrackWebSocketService {

    /**
     * 刷新区域跟标签的映射关系
     * @param param
     */
    void refreshAreaLabelMapping(AreaInfoParam param);

    /**
     * 删除区域跟标签的映射关系
     * @param areaCode
     */
    void removeAreaLabelMapping(String areaCode);
}
