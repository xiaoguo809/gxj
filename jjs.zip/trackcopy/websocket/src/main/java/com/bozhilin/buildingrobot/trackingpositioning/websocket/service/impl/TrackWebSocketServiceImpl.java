package com.bozhilin.buildingrobot.trackingpositioning.websocket.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackContext;
import com.bozhilin.buildingrobot.trackingpositioning.job.SchedulerContext;
import com.bozhilin.buildingrobot.trackingpositioning.job.TriggerType;
import com.bozhilin.buildingrobot.trackingpositioning.job.service.JobService;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.job.TrackRealTimePushJob;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.model.AreaInfoParam;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.service.TrackWebSocketService;

import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;

/**
 * @Author: pengjunming
 * @Date:2019/9/17 17:06
 * @Description:
 */
@Service
@Slf4j
public class TrackWebSocketServiceImpl implements TrackWebSocketService {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private TrackContext context;

    @Autowired
    private JobService jobService;

    @Override
    public void refreshAreaLabelMapping(AreaInfoParam param) {
        // 设置
        if (!CollectionUtils.isEmpty(param.getIds())) {
            List<AreaInfoParam.LabelPrimaryKey> ids = param.getIds();
            // 删除历史数据
            removeAreaLabelMapping(param.getAreaCode());
            // 重新设置新的值
            redisTemplate.execute(new RedisCallback<Boolean>() {
                @Override
                public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
                    connection.openPipeline();
                    String areaToLabelsKey = context.getAreaToLabelsKey(param.getAreaCode());
                    for (AreaInfoParam.LabelPrimaryKey key : ids) {
                        connection.hSet(context.getLabelToArea().getBytes(), key.getId().getBytes(), param.getAreaCode().getBytes());
                        connection.sAdd(areaToLabelsKey.getBytes(), key.getId().getBytes());
                    }
                    connection.closePipeline();
                    return true;
                }
            });
        }
        // 刷新定时器间隔
        if (param.getIntervalInfo() != null) {
            long seconds = computeSeconds(param.getIntervalInfo());
            SchedulerContext schedulerContext = new SchedulerContext(param.getAreaCode(), TrackRealTimePushJob.TRACK_REAL_TIME_PUSH_GROUP,
                    TriggerType.SIMPLE, String.valueOf(seconds));
            try {
                jobService.refresh(schedulerContext);
                log.info("Refresh job [{}] with interval [{}]s success.", param.getAreaCode(), seconds);
            } catch (SchedulerException e) {
                log.error("Refresh job [{}] with interval [{}]s failed.", param.getAreaCode(), seconds, e);
                //TODO(pengjunming) 处理异常情况
            }
        }
        // 设置该区域的每个标签的采样数据量
        if (param.getSampleAmount() != null && param.getSampleAmount() > 0) {
            redisTemplate.opsForValue().set(context.getAreaSampleAmoutKey(param.getAreaCode()), String.valueOf(param.getSampleAmount()));
        }
    }

    private long computeSeconds(AreaInfoParam.IntervalInfo intervalInfo) {
        long interval = intervalInfo.getInterval();
        switch (intervalInfo.getType()) {
            case SECOND:
                return interval;
            case MINUTE:
                return interval * 60;
            case HOUR:
                return interval * 3600;
            case DAY:
                return interval * 3600 * 24;
            default:
                return interval;
        }
    }

    @Override
    public void removeAreaLabelMapping(String areaCode) {
        Set<String> oldDataSet = redisTemplate.opsForSet().members(context.getAreaToLabelsKey(areaCode));
        if (!CollectionUtils.isEmpty(oldDataSet)) {
            redisTemplate.execute(new RedisCallback<Boolean>() {
                @Override
                public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
                    connection.openPipeline();
                    for (String oldData : oldDataSet) {
                        connection.hDel(context.getLabelToArea().getBytes(), oldData.getBytes());
                    }
                    connection.closePipeline();
                    return true;
                }
            });
        }
        redisTemplate.delete(context.getAreaToLabelsKey(areaCode));
    }

}
