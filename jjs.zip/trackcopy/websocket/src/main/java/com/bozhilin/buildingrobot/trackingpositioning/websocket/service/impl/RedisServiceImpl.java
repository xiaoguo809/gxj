package com.bozhilin.buildingrobot.trackingpositioning.websocket.service.impl;

import com.bozhilin.buildingrobot.trackingpositioning.websocket.service.Processor;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.service.RedisService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * @Author: pengjunming
 * @Date:2019/9/23 22:01
 * @Description:
 */
@Service
public class RedisServiceImpl implements RedisService {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Override
    public String get(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    @Override
    public void set(String key, String value, long expireTime, TimeUnit timeUnit) {
        redisTemplate.opsForValue().set(key, value, expireTime, timeUnit);
    }

    @Override
    public void set(String key, String value) {
        redisTemplate.opsForValue().set(key, value);
    }

    @Override
    public boolean processWhileLock(String key, int retryTimes, long intervalTime, Processor processor) {
        return false;
    }

    @Override
    public void increment(String key) {
        redisTemplate.opsForValue().increment(key);
    }

    @Override
    public void decrement(String key) {
        redisTemplate.opsForValue().decrement(key);
    }
}
