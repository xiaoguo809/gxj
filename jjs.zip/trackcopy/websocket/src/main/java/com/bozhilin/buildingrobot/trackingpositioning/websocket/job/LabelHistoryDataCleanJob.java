package com.bozhilin.buildingrobot.trackingpositioning.websocket.job;

import com.bozhilin.buildingrobot.trackingpositioning.common.model.TrackContext;
import com.bozhilin.buildingrobot.trackingpositioning.job.BaseJob;
import com.bozhilin.buildingrobot.trackingpositioning.job.TriggerType;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Set;

import lombok.extern.slf4j.Slf4j;

/**
 * @Author: pengjunming
 * @Date:2019/9/18 9:55
 * @Description: 实时轨迹历史数据清理job
 */
@Slf4j
@Component("labelHistoryDataCleanJob")
public class LabelHistoryDataCleanJob extends BaseJob<LabelHistoryDataCleanJob> {

    public static final String GROUP = "LABEL_HIS_CLEAN_GROUP";

    public static final String NAME = "LABEL_HIS_CLEAN";

    @Value("${quartz.cron.label-clean}")
    private String corn;

    @Value("${redis.track.label.limit-amount}")
    private long limitAmount;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private TrackContext trackContext;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        Set<String> serverLabelMaps = stringRedisTemplate.opsForSet().members(trackContext.getAllLabelsKey());
        for (String serverLabelMap : serverLabelMaps) {
            String[] serverLabelArr = serverLabelMap.split(":");
            if(serverLabelArr.length != 2){
                continue;
            }
            String labelAllPayloadKey = trackContext.getLabelAllPayloadKey(serverLabelArr[0], serverLabelArr[1]);
            long size = stringRedisTemplate.opsForZSet().zCard(labelAllPayloadKey);
            // 当数据大于限制后，就开始数据清理
            if (size > limitAmount) {
                log.info("Cache:[{}] size:[{}] is greater than limit:[{}], ready to clean.", labelAllPayloadKey, size, limitAmount);
                Set<String> results = stringRedisTemplate.opsForZSet().range(labelAllPayloadKey, 0, limitAmount - 1);
                if (!CollectionUtils.isEmpty(results)) {
                    stringRedisTemplate.execute(new RedisCallback<Boolean>() {
                        @Override
                        public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
                            connection.openPipeline();
                            for (String key : results) {
                                connection.del(key.getBytes());
                            }
                            connection.closePipeline();
                            return true;
                        }
                    });
                }
                stringRedisTemplate.opsForZSet().removeRange(labelAllPayloadKey, 0, limitAmount - 1);
            }
        }
    }

    @Override
    public String getGroup() {
        return GROUP;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getExpression() {
        return corn;
    }

    @Override
    public TriggerType getTriggerType() {
        return TriggerType.CRON;
    }
}
