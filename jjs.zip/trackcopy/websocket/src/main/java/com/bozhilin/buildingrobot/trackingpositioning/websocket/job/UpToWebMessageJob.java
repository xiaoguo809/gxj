package com.bozhilin.buildingrobot.trackingpositioning.websocket.job;


import com.alibaba.fastjson.JSON;
import com.bozhilin.buildingrobot.trackingpositioning.common.model.NodeMessage;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;
import com.bozhilin.buildingrobot.trackingpositioning.job.BaseJob;
import com.bozhilin.buildingrobot.trackingpositioning.job.TriggerType;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.server.UpWebSocketServer;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.service.NodeMessageService;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * @Author: pengjunming
 * @Date:2019/9/18 9:55
 * @Description: 上行消息传递
 */
@Slf4j
@Component("upToWebMessageJob")
public class UpToWebMessageJob extends BaseJob<UpToWebMessageJob> {

    public static final String GROUP = "UP_MESSAGE_GROUP";

    public static final String NAME = "UP_MESSAGE";

    @Value("${quartz.cron.up-message}")
    private String corn;


    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private NodeMessageService nodeMessageService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        String upMessage = stringRedisTemplate.opsForList().leftPop("upMessage");
        if (!StringUtil.isEmpty(upMessage)) {
            NodeMessage nodeMessage = JSON.parseObject(upMessage, NodeMessage.class);
            nodeMessageService.create(nodeMessage);
            String sid = nodeMessage.getNodeId().toString();
            UpWebSocketServer.sendInfo(sid, upMessage);
        }
    }

    @Override
    public String getGroup() {
        return GROUP;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getExpression() {
        return corn;
    }

    @Override
    public TriggerType getTriggerType() {
        return TriggerType.CRON;
    }
}
