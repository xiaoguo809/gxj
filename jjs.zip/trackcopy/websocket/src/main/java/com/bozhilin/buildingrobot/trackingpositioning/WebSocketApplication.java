package com.bozhilin.buildingrobot.trackingpositioning.websocket;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author: pengjunming
 * @Date:2019/9/23 10:18
 * @Description:
 */

@SpringBootApplication(scanBasePackages = {"com.bozhilin.buildingrobot.trackingpositioning.job",
        "com.bozhilin.buildingrobot.trackingpositioning.common",
        "com.bozhilin.buildingrobot.trackingpositioning.websocket"})

@MapperScan("com.bozhilin.buildingrobot.trackingpositioning.common.mapper")
public class WebSocketApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebSocketApplication.class, args);
    }
}
