package com.bozhilin.buildingrobot.trackingpositioning.websocket.server;

import com.bozhilin.buildingrobot.trackingpositioning.common.util.BeanUtils;
import com.bozhilin.buildingrobot.trackingpositioning.common.util.StringUtil;
import com.bozhilin.buildingrobot.trackingpositioning.job.SchedulerContext;
import com.bozhilin.buildingrobot.trackingpositioning.job.TriggerType;
import com.bozhilin.buildingrobot.trackingpositioning.job.service.JobService;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.job.TrackRealTimePushJob;
import com.bozhilin.buildingrobot.trackingpositioning.websocket.service.RedisService;

import org.quartz.SchedulerException;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import lombok.extern.slf4j.Slf4j;

@ServerEndpoint(value = "/websocket/track/realtime/{sid}")
@Component
@Slf4j
public class WebSocketServer {

    private static final String COUNTER = "track:server:online";

    private static final String LOCK = "LOCK";

    // key为sid,value为sid对应的所有WebSocketServer实例
    private static final ConcurrentHashMap<String, CopyOnWriteArraySet<WebSocketServer>> activeSessions = new ConcurrentHashMap<>();

    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Session session;

    //接收sid
    private String sid = "";

    /**
     * 连接建立成功调用的方法
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("sid") String sid) {
        this.session = session;
        this.sid = sid;
        cacheSession(sid);
        addOnlineCount();           //在线数加1
        log.debug("有新窗口开始监听:[{}],当前在线客户端数为:[{}]", sid, getOnlineCount());
        createRealTimePushJob(sid);
    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        CopyOnWriteArraySet<WebSocketServer> webSocketSet = activeSessions.get(this.sid);
        if (!CollectionUtils.isEmpty(webSocketSet)) {
            webSocketSet.remove(this);  //从set中删除
            if (webSocketSet.size() == 0) {
                deleteRealTimePushJob(this.sid);
            }
        }
        subOnlineCount();           //在线数减1
        log.debug("有一连接关闭！当前在线客户端数为:[{}]", getOnlineCount());
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        log.debug("收到来[{}} 的信息:[{}]", sid, message);
        //TODO
    }

    /**
     *
     */
    @OnError
    public void onError(Session session, Throwable error) {
        log.debug("发生错误", error);
    }

    /**
     * 实现服务器主动推送
     */
    public void sendMessage(String message) throws IOException {
        this.session.getBasicRemote().sendText(message);
    }


    /**
     * 群发自定义消息
     */
    public static void sendInfo(@PathParam("sid") String sid, String message) {
        log.debug("推送消息到窗口:[{}]，推送内容:[{}]", sid, message);
        if (CollectionUtils.isEmpty(activeSessions.get(sid))) {
            log.warn("No active session exists.");
            return;
        }
        for (WebSocketServer server : activeSessions.get(sid)) {
            try {
                server.sendMessage(message);
            } catch (IOException e) {
                continue;
            }
        }

    }

    private synchronized String getOnlineCount() {
        if (StringUtil.isEmpty(getRedisService().get(COUNTER))) {
            return "0";
        }
        return getRedisService().get(COUNTER);
    }

    private synchronized void addOnlineCount() {
        if (StringUtil.isEmpty(getRedisService().get(COUNTER))) {
            getRedisService().set(COUNTER, "1");
            return;
        }
        getRedisService().increment(COUNTER);
    }

    private synchronized void subOnlineCount() {
        if (StringUtil.isEmpty(getRedisService().get(COUNTER))) {
            return;
        }
        getRedisService().decrement(COUNTER);
    }

    /**
     * 创建指定的areaCode的实时推送job
     */
    private void createRealTimePushJob(String areaCode) {
        Map<String, String> param = new HashMap();
        param.put(TrackRealTimePushJob.AREA_CODE_KEY_NAME, areaCode);
        SchedulerContext schedulerContext = new SchedulerContext(areaCode, TrackRealTimePushJob.TRACK_REAL_TIME_PUSH_GROUP,
                TrackRealTimePushJob.class, TriggerType.SIMPLE, "1", param);
        try {
            getJobService().create(schedulerContext);
        } catch (SchedulerException e) {
            log.error("Create real time push job [{}] failed.", areaCode, e);
            //TODO(pengjunming) 处理创建job异常的情况
        }
    }

    /**
     * 删除指定的areaCode的实时推送job
     */
    private void deleteRealTimePushJob(String sid) {
        try {
            getJobService().delete(new SchedulerContext(sid, TrackRealTimePushJob.TRACK_REAL_TIME_PUSH_GROUP));
        } catch (SchedulerException e) {
            log.error("Delete real time push job [{}] failed.", sid);
            //TODO(pengjunming) 处理删除job异常的情况
        }
    }

    private void cacheSession(String sid) {
        CopyOnWriteArraySet<WebSocketServer> webSocketSet = activeSessions.get(sid);
        if (webSocketSet == null) {
            synchronized (LOCK) {
                if (webSocketSet == null) {
                    webSocketSet = new CopyOnWriteArraySet<>();
                    webSocketSet.add(this);
                    activeSessions.put(sid, webSocketSet);
                }
            }
        } else {
            // 同一个sid可能对应多个session
            webSocketSet.add(this);
        }
    }

    private JobService getJobService() {
        return BeanUtils.getBean(JobService.class);
    }

    private RedisService getRedisService() {
        return BeanUtils.getBean(RedisService.class);
    }
}
